//! Download manager: persistent queue/records, per-queue and global limits,
//! bandwidth limiters, one-shot queue schedules and the post-completion action.
//! All public methods are synchronous and non-blocking; downloads run as tasks
//! on the supplied tokio runtime.
use crate::download::{cleanup_partials, run_download, EngineConfig, DlError, Job, Outcome, Progress, ProxyChoice, Signal};
use crate::ratelimit::RateLimiter;
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, HashMap};
use std::path::{Path, PathBuf};
use std::sync::atomic::Ordering;
use std::sync::{Arc, Mutex};
use std::time::{Duration, SystemTime, UNIX_EPOCH};
use tokio::runtime::Handle;
use tokio::sync::{watch, Notify};

#[derive(Serialize, Deserialize, Clone, Copy, PartialEq, Eq, Debug)]
#[serde(rename_all = "lowercase")]
pub enum Status {
    Queued,
    Running,
    Paused,
    Completed,
    Failed,
    Cancelled,
}

#[derive(Serialize, Deserialize, Clone, Copy, PartialEq, Eq, Debug, Default)]
#[serde(rename_all = "lowercase")]
pub enum PostAction {
    #[default]
    None,
    Exit,
    Shutdown,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct Record {
    pub id: u64,
    pub url: String,
    pub dest_dir: String,
    pub filename: Option<String>,
    pub queue: String,
    pub status: Status,
    pub expected_sha256: Option<String>,
    pub max_conns: Option<u32>,
    #[serde(default)]
    pub referer: Option<String>,
    pub final_path: Option<String>,
    pub sha256: Option<String>,
    pub error: Option<String>,
    pub added_at: i64,
    pub finished_at: Option<i64>,
}

#[derive(Serialize, Clone, Debug)]
pub struct SegInfo {
    pub start: u64,
    pub end: u64,
    pub done: u64,
}

#[derive(Serialize, Clone, Debug)]
pub struct Info {
    #[serde(flatten)]
    pub rec: Record,
    pub downloaded: u64,
    pub total: u64,
    pub conns: u32,
    pub retries: u32,
    pub segmented: bool,
    pub segments: Vec<SegInfo>,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct QueueRec {
    pub name: String,
    pub max_active: usize,
    pub speed_limit: u64,
    pub running: bool,
    pub start_at: Option<i64>,
    pub stop_at: Option<i64>,
    /// Runs once when every file of THIS queue finished without failures. Never applies to `default`
    /// (that is where ordinary one-off downloads live).
    #[serde(default)]
    pub post_action: PostAction,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct Settings {
    pub global_speed_limit: u64,
    pub max_conns: Option<u32>,
    pub max_total_active: usize,
    #[serde(default)]
    pub proxy: ProxySettings,
}

/// mode: "system" | "none" | "manual"; kind (manual only): "http" | "socks5".
#[derive(Serialize, Deserialize, Clone, Debug, PartialEq)]
pub struct ProxySettings {
    pub mode: String,
    pub kind: String,
    pub host: String,
    pub port: u16,
    pub username: String,
    /// Kept in manager.json (plain text, like the rest of the file); never returned by `settings.get`.
    pub password: String,
}

impl Default for ProxySettings {
    fn default() -> Self {
        ProxySettings { mode: "system".into(), kind: "http".into(), host: String::new(), port: 0, username: String::new(), password: String::new() }
    }
}

impl ProxySettings {
    pub fn validate(&self) -> Result<(), String> {
        match self.mode.as_str() {
            "system" | "none" => Ok(()),
            "manual" => {
                if !matches!(self.kind.as_str(), "http" | "socks5") {
                    return Err("proxy kind must be http or socks5".into());
                }
                if self.host.is_empty() || self.host.len() > 253 || self.host.chars().any(|c| c.is_whitespace() || matches!(c, '/' | '@' | '\\' | '?' | '#')) {
                    return Err("proxy host is empty or invalid".into());
                }
                if self.port == 0 {
                    return Err("proxy port must be 1..=65535".into());
                }
                self.url().map(|_| ())
            }
            _ => Err("proxy mode must be system, none or manual".into()),
        }
    }

    /// socks5h = the proxy resolves names, which is what you want behind a filtered network.
    pub fn url(&self) -> Result<String, String> {
        let scheme = if self.kind == "socks5" { "socks5h" } else { "http" };
        let mut u = reqwest::Url::parse(&format!("{scheme}://{}:{}", self.host, self.port)).map_err(|e| format!("invalid proxy address: {e}"))?;
        if !self.username.is_empty() {
            u.set_username(&self.username).map_err(|_| "invalid proxy username".to_string())?;
            if !self.password.is_empty() {
                u.set_password(Some(&self.password)).map_err(|_| "invalid proxy password".to_string())?;
            }
        }
        Ok(u.to_string())
    }

    pub fn choice(&self) -> ProxyChoice {
        match self.mode.as_str() {
            "none" => ProxyChoice::None,
            "manual" => self.url().map(ProxyChoice::Url).unwrap_or(ProxyChoice::Default),
            _ => ProxyChoice::Default,
        }
    }
}

/// Partial update from `settings.set`; `None` keeps the stored value.
#[derive(Default)]
pub struct ProxyUpdate {
    pub mode: Option<String>,
    pub kind: Option<String>,
    pub host: Option<String>,
    pub port: Option<u16>,
    pub username: Option<String>,
    pub password: Option<String>,
}

impl Default for Settings {
    fn default() -> Self {
        Settings { global_speed_limit: 0, max_conns: None, max_total_active: 4, proxy: ProxySettings::default() }
    }
}

#[derive(Serialize, Deserialize, Default)]
struct Store {
    #[serde(default)]
    next_id: u64,
    #[serde(default)]
    items: Vec<Record>,
    #[serde(default)]
    queues: Vec<QueueRec>,
    #[serde(default)]
    settings: Settings,
}

pub struct AddRequest {
    pub url: String,
    pub dest_dir: PathBuf,
    pub filename: Option<String>,
    pub queue: Option<String>,
    pub sha256: Option<String>,
    pub max_conns: Option<u32>,
    pub start: bool,
    /// Sent as the Referer header (many media hosts refuse requests without it). Must be an http(s) URL.
    pub referer: Option<String>,
}

#[derive(Default)]
pub struct QueueUpdate {
    pub max_active: Option<usize>,
    pub speed_limit: Option<u64>,
    pub start_at: Option<Option<i64>>,
    pub stop_at: Option<Option<i64>>,
    pub post_action: Option<PostAction>,
}

struct Item {
    rec: Record,
    progress: Arc<Progress>,
    ctrl: Option<watch::Sender<Signal>>,
    requeue_on_pause: bool,
}

struct Queue {
    rec: QueueRec,
    limiter: Arc<RateLimiter>,
    // Per-queue batch tracking for the post-action (not persisted).
    completed_in_batch: bool,
    batch_failed: bool,
}

impl Queue {
    fn new(rec: QueueRec) -> Queue {
        let limiter = Arc::new(RateLimiter::new(rec.speed_limit));
        Queue { rec, limiter, completed_in_batch: false, batch_failed: false }
    }
}

const DEFAULT_QUEUE: &str = "default";

struct Inner {
    next_id: u64,
    items: BTreeMap<u64, Item>,
    queues: BTreeMap<String, Queue>,
    settings: Settings,
}

pub type ActionRunner = Arc<dyn Fn(PostAction) + Send + Sync>;

pub struct Manager {
    inner: Mutex<Inner>,
    cfg: EngineConfig,
    rt: Handle,
    store: Option<PathBuf>,
    global: Arc<RateLimiter>,
    wake: Notify,
    runner: ActionRunner,
}

pub fn now_secs() -> i64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs() as i64).unwrap_or(0)
}

fn valid_queue_name(n: &str) -> bool {
    !n.is_empty() && n.len() <= 48 && n.chars().all(|c| c.is_alphanumeric() || c == ' ' || c == '_' || c == '-')
}

impl Manager {
    pub fn new(rt: Handle, cfg: EngineConfig, store: Option<PathBuf>, runner: ActionRunner) -> Arc<Manager> {
        let loaded: Store = store
            .as_ref()
            .and_then(|p| std::fs::read(p).ok())
            .and_then(|b| serde_json::from_slice(&b).ok())
            .unwrap_or_default();
        let mut inner = Inner {
            next_id: loaded.next_id.max(1),
            items: BTreeMap::new(),
            queues: BTreeMap::new(),
            settings: loaded.settings.clone(),
        };
        for mut q in loaded.queues {
            if q.name == DEFAULT_QUEUE {
                q.post_action = PostAction::None;
            }
            inner.queues.insert(q.name.clone(), Queue::new(q));
        }
        inner.queues.entry(DEFAULT_QUEUE.into()).or_insert_with(|| {
            Queue::new(QueueRec {
                name: DEFAULT_QUEUE.into(),
                max_active: 3,
                speed_limit: 0,
                running: true,
                start_at: None,
                stop_at: None,
                post_action: PostAction::None,
            })
        });
        for mut r in loaded.items {
            if matches!(r.status, Status::Running | Status::Queued) {
                // Closed while active: resume from partial state, or stay Paused so a cold start never downloads by itself.
                r.status = if cfg.resume_on_start { Status::Queued } else { Status::Paused };
            }
            inner.next_id = inner.next_id.max(r.id + 1);
            inner.items.insert(r.id, Item { rec: r, progress: Progress::new(), ctrl: None, requeue_on_pause: false });
        }
        let m = Arc::new(Manager {
            global: Arc::new(RateLimiter::new(inner.settings.global_speed_limit)),
            inner: Mutex::new(inner),
            cfg,
            rt: rt.clone(),
            store,
            wake: Notify::new(),
            runner,
        });
        {
            let mut g = m.inner.lock().unwrap();
            m.pump_locked(&mut g);
        }
        let s = m.clone();
        rt.spawn(async move { scheduler(s).await });
        m
    }

    // ----- persistence -----
    fn save_locked(&self, g: &Inner) {
        let Some(path) = &self.store else { return };
        let st = Store {
            next_id: g.next_id,
            items: g.items.values().map(|i| i.rec.clone()).collect(),
            queues: g.queues.values().map(|q| q.rec.clone()).collect(),
            settings: g.settings.clone(),
        };
        if let Ok(json) = serde_json::to_vec_pretty(&st) {
            let mut tmp = path.clone().into_os_string();
            tmp.push(".tmp");
            let tmp = PathBuf::from(tmp);
            if let Some(parent) = path.parent() {
                let _ = std::fs::create_dir_all(parent);
            }
            if std::fs::write(&tmp, json).is_ok() {
                let _ = std::fs::rename(&tmp, path);
            }
        }
    }

    // ----- scheduling core -----
    fn pump_locked(self: &Arc<Self>, g: &mut Inner) {
        let mut per_queue: HashMap<String, usize> = HashMap::new();
        let mut total = 0usize;
        for i in g.items.values().filter(|i| i.rec.status == Status::Running) {
            *per_queue.entry(i.rec.queue.clone()).or_default() += 1;
            total += 1;
        }
        let mut to_start = Vec::new();
        for (id, i) in g.items.iter().filter(|(_, i)| i.rec.status == Status::Queued) {
            let Some(q) = g.queues.get(&i.rec.queue) else { continue };
            let n = per_queue.entry(i.rec.queue.clone()).or_default();
            if !q.rec.running || *n >= q.rec.max_active || total >= g.settings.max_total_active {
                continue;
            }
            *n += 1;
            total += 1;
            to_start.push(*id);
        }
        for id in to_start {
            self.start_item(g, id);
        }
    }

    fn start_item(self: &Arc<Self>, g: &mut Inner, id: u64) {
        let default_conns = g.settings.max_conns;
        let proxy = g.settings.proxy.choice();
        let qlimiter = g.queues.get(&g.items[&id].rec.queue).map(|q| q.limiter.clone());
        let item = g.items.get_mut(&id).unwrap();
        let (tx, rx) = watch::channel(Signal::Run);
        let progress = Progress::new();
        item.rec.status = Status::Running;
        item.rec.error = None;
        item.ctrl = Some(tx);
        item.progress = progress.clone();
        item.requeue_on_pause = false;
        let mut limiters = vec![self.global.clone()];
        limiters.extend(qlimiter);
        let job = Job {
            url: item.rec.url.clone(),
            dest_dir: PathBuf::from(&item.rec.dest_dir),
            filename: item.rec.filename.clone(),
            expected_sha256: item.rec.expected_sha256.clone(),
            max_conns: item.rec.max_conns.or(default_conns),
            limiters,
            referer: item.rec.referer.clone(),
            proxy,
        };
        let (this, cfg) = (self.clone(), self.cfg.clone());
        self.rt.spawn(async move {
            let r = run_download(&cfg, &job, progress, rx).await;
            this.finish(id, r);
        });
    }

    fn finish(self: &Arc<Self>, id: u64, result: Result<Outcome, DlError>) {
        let action = {
            let mut g = self.inner.lock().unwrap();
            let mut completed = false;
            let mut failed = false;
            let mut qname = None;
            if let Some(item) = g.items.get_mut(&id) {
                qname = Some(item.rec.queue.clone());
                item.ctrl = None;
                if let Some(f) = item.progress.filename.lock().unwrap().clone() {
                    item.rec.filename = Some(f);
                }
                match result {
                    Ok(Outcome::Completed { path, sha256, .. }) => {
                        item.rec.status = Status::Completed;
                        item.rec.final_path = Some(path.to_string_lossy().into_owned());
                        item.rec.sha256 = Some(sha256);
                        item.rec.finished_at = Some(now_secs());
                        completed = true;
                    }
                    Ok(Outcome::Paused) => {
                        item.rec.status = if item.requeue_on_pause { Status::Queued } else { Status::Paused };
                    }
                    Ok(Outcome::Cancelled) => {
                        item.rec.status = Status::Cancelled;
                        // A cancel can land before the engine knew the file name (e.g. during the probe).
                        if let Some(f) = &item.rec.filename {
                            cleanup_partials(Path::new(&item.rec.dest_dir), f);
                        }
                    }
                    Err(e) => {
                        item.rec.status = Status::Failed;
                        item.rec.error = Some(e.to_string());
                        item.rec.finished_at = Some(now_secs());
                        failed = true;
                    }
                }
            }
            if let Some(q) = qname.as_ref().and_then(|n| g.queues.get_mut(n)) {
                q.completed_in_batch |= completed;
                q.batch_failed |= failed;
            }
            self.pump_locked(&mut g);
            let action = qname.and_then(|n| self.take_post_action(&mut g, &n));
            self.save_locked(&g);
            action
        };
        if let Some(a) = action {
            (self.runner)(a);
        }
    }

    /// A queue's armed post-action fires once, only when nothing of that queue is queued/running, at least one
    /// of its downloads completed, and none failed in this batch. The `default` queue never fires one.
    fn take_post_action(&self, g: &mut Inner, queue: &str) -> Option<PostAction> {
        if queue == DEFAULT_QUEUE {
            return None;
        }
        let q = g.queues.get(queue)?;
        if q.rec.post_action == PostAction::None || !q.completed_in_batch || q.batch_failed {
            return None;
        }
        if g.items.values().any(|i| i.rec.queue == queue && matches!(i.rec.status, Status::Running | Status::Queued)) {
            return None;
        }
        let q = g.queues.get_mut(queue)?;
        let a = q.rec.post_action;
        q.rec.post_action = PostAction::None;
        q.completed_in_batch = false;
        Some(a)
    }

    // ----- public API -----
    pub fn add(self: &Arc<Self>, req: AddRequest) -> Result<u64, String> {
        let url = reqwest::Url::parse(&req.url).map_err(|e| format!("invalid URL: {e}"))?;
        if !matches!(url.scheme(), "http" | "https") || url.host_str().is_none() {
            return Err("only http/https URLs with a host are supported".into());
        }
        if !req.dest_dir.is_absolute() {
            return Err("dest_dir must be an absolute path".into());
        }
        if let Some(s) = &req.sha256 {
            if s.len() != 64 || !s.bytes().all(|b| b.is_ascii_hexdigit()) {
                return Err("sha256 must be 64 hex characters".into());
            }
        }
        if let Some(c) = req.max_conns {
            if !(1..=32).contains(&c) {
                return Err("max_conns must be 1..=32".into());
            }
        }
        let referer = match &req.referer {
            None => None,
            Some(r) => {
                let u = reqwest::Url::parse(r).map_err(|e| format!("invalid referer: {e}"))?;
                if !matches!(u.scheme(), "http" | "https") {
                    return Err("referer must be an http(s) URL".into());
                }
                Some(u.to_string())
            }
        };
        let queue = req.queue.unwrap_or_else(|| "default".into());
        let mut g = self.inner.lock().unwrap();
        if !g.queues.contains_key(&queue) {
            return Err(format!("unknown queue `{queue}`"));
        }
        let id = g.next_id;
        g.next_id += 1;
        let rec = Record {
            id,
            url: req.url,
            dest_dir: req.dest_dir.to_string_lossy().into_owned(),
            filename: req.filename.map(|f| pdm_core::filename::sanitize_filename(&f)),
            queue,
            status: if req.start { Status::Queued } else { Status::Paused },
            expected_sha256: req.sha256,
            max_conns: req.max_conns,
            referer,
            final_path: None,
            sha256: None,
            error: None,
            added_at: now_secs(),
            finished_at: None,
        };
        g.items.insert(id, Item { rec, progress: Progress::new(), ctrl: None, requeue_on_pause: false });
        self.pump_locked(&mut g);
        self.save_locked(&g);
        Ok(id)
    }

    pub fn list(&self) -> Vec<Info> {
        let g = self.inner.lock().unwrap();
        g.items
            .values()
            .map(|i| {
                let ranges = i.progress.seg_ranges.lock().unwrap().clone();
                let done = i.progress.seg_done.lock().unwrap().clone();
                let segments = match done {
                    Some(d) => ranges
                        .iter()
                        .zip(d.iter())
                        .map(|(r, x)| SegInfo { start: r.0, end: r.1, done: x.load(Ordering::SeqCst) })
                        .collect(),
                    None => Vec::new(),
                };
                Info {
                rec: i.rec.clone(),
                downloaded: i.progress.downloaded.load(Ordering::SeqCst),
                total: i.progress.total.load(Ordering::SeqCst),
                conns: i.progress.conns.load(Ordering::SeqCst),
                retries: i.progress.retries.load(Ordering::SeqCst),
                segmented: i.progress.segmented.load(Ordering::SeqCst),
                segments,
                }
            })
            .collect()
    }

    pub fn pause(self: &Arc<Self>, id: u64) -> Result<(), String> {
        let mut g = self.inner.lock().unwrap();
        let item = g.items.get_mut(&id).ok_or("no such download")?;
        match item.rec.status {
            Status::Running => {
                item.requeue_on_pause = false;
                if let Some(tx) = &item.ctrl {
                    let _ = tx.send(Signal::Pause);
                }
            }
            Status::Queued => item.rec.status = Status::Paused,
            _ => return Err("download is not running or queued".into()),
        }
        self.save_locked(&g);
        Ok(())
    }

    pub fn resume(self: &Arc<Self>, id: u64) -> Result<(), String> {
        let mut g = self.inner.lock().unwrap();
        let item = g.items.get_mut(&id).ok_or("no such download")?;
        let qname = item.rec.queue.clone();
        match item.rec.status {
            Status::Paused | Status::Failed | Status::Cancelled => {
                item.rec.status = Status::Queued;
                item.rec.error = None;
            }
            _ => return Err("download cannot be resumed from its current state".into()),
        }
        if let Some(q) = g.queues.get_mut(&qname) {
            q.batch_failed = false;
        }
        self.pump_locked(&mut g);
        self.save_locked(&g);
        Ok(())
    }

    pub fn cancel(self: &Arc<Self>, id: u64) -> Result<(), String> {
        let mut g = self.inner.lock().unwrap();
        let item = g.items.get_mut(&id).ok_or("no such download")?;
        match item.rec.status {
            Status::Running => {
                if let Some(tx) = &item.ctrl {
                    let _ = tx.send(Signal::Cancel);
                }
            }
            Status::Queued | Status::Paused | Status::Failed => {
                if let Some(f) = &item.rec.filename {
                    cleanup_partials(Path::new(&item.rec.dest_dir), f);
                }
                item.rec.status = Status::Cancelled;
            }
            _ => return Err("download already finished".into()),
        }
        self.save_locked(&g);
        Ok(())
    }

    pub fn remove(self: &Arc<Self>, id: u64) -> Result<(), String> {
        let mut g = self.inner.lock().unwrap();
        match g.items.get(&id).map(|i| i.rec.status) {
            None => Err("no such download".into()),
            Some(Status::Running) => Err("cancel or pause the download first".into()),
            Some(_) => {
                g.items.remove(&id); // history only: the downloaded file is never deleted
                self.save_locked(&g);
                Ok(())
            }
        }
    }

    pub fn list_queues(&self) -> Vec<QueueRec> {
        self.inner.lock().unwrap().queues.values().map(|q| q.rec.clone()).collect()
    }

    pub fn set_queue(self: &Arc<Self>, name: &str, u: QueueUpdate) -> Result<(), String> {
        if !valid_queue_name(name) {
            return Err("invalid queue name".into());
        }
        if matches!(u.max_active, Some(0)) || matches!(u.max_active, Some(n) if n > 16) {
            return Err("max_active must be 1..=16".into());
        }
        if name == DEFAULT_QUEUE && matches!(u.post_action, Some(p) if p != PostAction::None) {
            return Err("the default queue cannot have an after-completion action; create a queue for that".into());
        }
        let mut g = self.inner.lock().unwrap();
        let q = g.queues.entry(name.to_string()).or_insert_with(|| {
            Queue::new(QueueRec {
                name: name.to_string(),
                max_active: 2,
                speed_limit: 0,
                running: true,
                start_at: None,
                stop_at: None,
                post_action: PostAction::None,
            })
        });
        if let Some(n) = u.max_active {
            q.rec.max_active = n;
        }
        if let Some(s) = u.speed_limit {
            q.rec.speed_limit = s;
            q.limiter.set_rate(s);
        }
        if let Some(s) = u.start_at {
            q.rec.start_at = s;
        }
        if let Some(s) = u.stop_at {
            q.rec.stop_at = s;
        }
        if let Some(p) = u.post_action {
            q.rec.post_action = p;
            q.batch_failed = false;
            q.completed_in_batch = false;
        }
        self.pump_locked(&mut g);
        self.save_locked(&g);
        drop(g);
        self.wake.notify_one();
        Ok(())
    }

    pub fn start_queue(self: &Arc<Self>, name: &str) -> Result<(), String> {
        let mut g = self.inner.lock().unwrap();
        g.queues.get_mut(name).ok_or("unknown queue")?.rec.running = true;
        self.pump_locked(&mut g);
        self.save_locked(&g);
        Ok(())
    }

    pub fn stop_queue(self: &Arc<Self>, name: &str) -> Result<(), String> {
        let mut g = self.inner.lock().unwrap();
        g.queues.get_mut(name).ok_or("unknown queue")?.rec.running = false;
        Self::pause_running_to_queued(&mut g, name);
        self.save_locked(&g);
        Ok(())
    }

    fn pause_running_to_queued(g: &mut Inner, name: &str) {
        for i in g.items.values_mut().filter(|i| i.rec.queue == name && i.rec.status == Status::Running) {
            i.requeue_on_pause = true;
            if let Some(tx) = &i.ctrl {
                let _ = tx.send(Signal::Pause);
            }
        }
    }

    pub fn settings(&self) -> Settings {
        self.inner.lock().unwrap().settings.clone()
    }

    pub fn update_settings(
        self: &Arc<Self>,
        speed: Option<u64>,
        max_conns: Option<u32>,
        max_total: Option<usize>,
    ) -> Result<(), String> {
        if matches!(max_conns, Some(c) if !(1..=32).contains(&c)) {
            return Err("max_conns must be 1..=32".into());
        }
        if matches!(max_total, Some(n) if !(1..=32).contains(&n)) {
            return Err("max_total_active must be 1..=32".into());
        }
        let mut g = self.inner.lock().unwrap();
        if let Some(s) = speed {
            g.settings.global_speed_limit = s;
            self.global.set_rate(s);
        }
        if let Some(c) = max_conns {
            g.settings.max_conns = Some(c);
        }
        if let Some(n) = max_total {
            g.settings.max_total_active = n;
        }
        self.pump_locked(&mut g);
        self.save_locked(&g);
        Ok(())
    }

    /// Applies to downloads started or resumed afterwards; running ones keep their connection.
    pub fn set_proxy(self: &Arc<Self>, u: ProxyUpdate) -> Result<(), String> {
        let mut g = self.inner.lock().unwrap();
        let mut p = g.settings.proxy.clone();
        if let Some(v) = u.mode { p.mode = v; }
        if let Some(v) = u.kind { p.kind = v; }
        if let Some(v) = u.host { p.host = v.trim().to_string(); }
        if let Some(v) = u.port { p.port = v; }
        if let Some(v) = u.username {
            if v.is_empty() {
                p.password.clear(); // removing the user name removes the password too
            }
            p.username = v;
        }
        if let Some(v) = u.password { p.password = v; }
        p.validate()?;
        g.settings.proxy = p;
        self.save_locked(&g);
        Ok(())
    }

    /// Apply due one-shot queue schedules. `now` is injected for tests.
    pub fn tick_schedules(self: &Arc<Self>, now: i64) {
        let mut g = self.inner.lock().unwrap();
        let mut stops = Vec::new();
        for q in g.queues.values_mut() {
            if matches!(q.rec.start_at, Some(t) if t <= now) {
                q.rec.running = true;
                q.rec.start_at = None;
            }
            if matches!(q.rec.stop_at, Some(t) if t <= now) {
                q.rec.running = false;
                q.rec.stop_at = None;
                stops.push(q.rec.name.clone());
            }
        }
        for n in stops {
            Self::pause_running_to_queued(&mut g, &n);
        }
        self.pump_locked(&mut g);
        self.save_locked(&g);
    }

    fn next_schedule(&self) -> Option<i64> {
        let g = self.inner.lock().unwrap();
        g.queues.values().flat_map(|q| [q.rec.start_at, q.rec.stop_at]).flatten().min()
    }
}

async fn scheduler(m: Arc<Manager>) {
    loop {
        let now = now_secs();
        match m.next_schedule() {
            Some(t) if t <= now => m.tick_schedules(now),
            Some(t) => {
                tokio::select! {
                    _ = tokio::time::sleep(Duration::from_secs((t - now) as u64)) => {}
                    _ = m.wake.notified() => {}
                }
            }
            None => m.wake.notified().await, // nothing scheduled: no timer at all
        }
    }
}

/// Real post-completion action runner for Windows. `Exit` is delegated to the caller.
pub fn system_shutdown() {
    #[cfg(windows)]
    {
        // 60 s grace period; the user can abort with `shutdown /a`.
        let _ = std::process::Command::new("shutdown").args(["/s", "/t", "60", "/c", "PDM: downloads finished"]).spawn();
    }
}
