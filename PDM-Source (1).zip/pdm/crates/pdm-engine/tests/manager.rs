//! Manager tests: queue limits, persistence/restart, schedules, post-action.
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};
use pdm_engine::download::EngineConfig;
use pdm_engine::fixture::*;
use pdm_engine::manager::*;

fn cfg() -> EngineConfig {
    EngineConfig {
        min_segment: 64 * 1024,
        backoff_base_ms: 5,
        backoff_max_ms: 50,
        state_save_interval: Duration::from_millis(50),
        use_system_proxy: false,
        ..EngineConfig::default()
    }
}

fn noop() -> ActionRunner {
    Arc::new(|_| {})
}

fn add(m: &Arc<Manager>, url: String, dir: &std::path::Path, queue: Option<&str>, start: bool) -> u64 {
    m.add(AddRequest { url, dest_dir: dir.to_path_buf(), filename: None, queue: queue.map(String::from), sha256: None, max_conns: None, start, referer: None }).unwrap()
}

async fn wait_for(m: &Arc<Manager>, what: &str, f: impl Fn(&[Info]) -> bool) {
    let t = Instant::now();
    while t.elapsed() < Duration::from_secs(30) {
        if f(&m.list()) {
            return;
        }
        tokio::time::sleep(Duration::from_millis(20)).await;
    }
    panic!("timed out waiting for: {what}; state: {:?}", m.list().iter().map(|i| (i.rec.id, i.rec.status)).collect::<Vec<_>>());
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn queue_never_exceeds_max_active_and_all_complete() {
    let fx = Fixture::start().await;
    for i in 0..5 {
        let mut b = Behavior::new(test_data(300_000, 100 + i));
        b.chunk_delay_ms = 15;
        fx.add(&format!("/f{i}.bin"), b);
    }
    let dir = temp_dir("mq");
    let m = Manager::new(tokio::runtime::Handle::current(), cfg(), None, noop());
    m.set_queue("movies", QueueUpdate { max_active: Some(2), ..Default::default() }).unwrap();
    for i in 0..5 {
        add(&m, fx.url(&format!("/f{i}.bin")), &dir, Some("movies"), true);
    }
    let mut max_seen = 0;
    let t = Instant::now();
    loop {
        let l = m.list();
        let running = l.iter().filter(|i| i.rec.status == Status::Running).count();
        max_seen = max_seen.max(running);
        assert!(running <= 2, "queue limit exceeded: {running}");
        if l.iter().all(|i| i.rec.status == Status::Completed) {
            break;
        }
        assert!(t.elapsed() < Duration::from_secs(30), "timeout");
        tokio::time::sleep(Duration::from_millis(5)).await;
    }
    assert!(max_seen >= 2, "queue never ran two at once");
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn stopped_queue_holds_items_until_started() {
    let fx = Fixture::start().await;
    fx.add("/a.bin", Behavior::new(test_data(100_000, 1)));
    let dir = temp_dir("qs");
    let m = Manager::new(tokio::runtime::Handle::current(), cfg(), None, noop());
    m.set_queue("later", QueueUpdate::default()).unwrap();
    m.stop_queue("later").unwrap();
    let id = add(&m, fx.url("/a.bin"), &dir, Some("later"), true);
    tokio::time::sleep(Duration::from_millis(300)).await;
    assert_eq!(m.list()[0].rec.status, Status::Queued);
    assert!(fx.requests_for("/a.bin").is_empty());
    m.start_queue("later").unwrap();
    wait_for(&m, "completion", |l| l.iter().any(|i| i.rec.id == id && i.rec.status == Status::Completed)).await;
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn records_survive_restart_and_unfinished_work_resumes() {
    let data = test_data(3 << 20, 7);
    let fx = Fixture::start().await;
    let mut b = Behavior::new(data.clone());
    b.chunk_delay_ms = 10;
    fx.add("/r.bin", b);
    let dir = temp_dir("restart");
    let store = dir.join("manager.json");
    let m = Manager::new(tokio::runtime::Handle::current(), cfg(), Some(store.clone()), noop());
    let id = add(&m, fx.url("/r.bin"), &dir, None, true);
    tokio::time::sleep(Duration::from_millis(400)).await;
    assert_eq!(m.list()[0].rec.status, Status::Running);
    m.pause(id).unwrap();
    wait_for(&m, "paused", |l| l[0].rec.status == Status::Paused).await;
    // A fresh manager (as after an application restart) reloads records from disk.
    let m2 = Manager::new(tokio::runtime::Handle::current(), cfg(), Some(store), noop());
    let l = m2.list();
    assert_eq!(l.len(), 1);
    assert_eq!(l[0].rec.id, id);
    assert_eq!(l[0].rec.status, Status::Paused);
    m2.resume(id).unwrap();
    wait_for(&m2, "resumed completion", |l| l.iter().all(|i| i.rec.status == Status::Completed)).await;
    let info = &m2.list()[0];
    assert_eq!(info.rec.sha256.as_deref(), Some(sha256_hex_of(&data).as_str()));
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn cold_start_without_resume_keeps_unfinished_downloads_paused() {
    let fx = Fixture::start().await;
    let mut b = Behavior::new(test_data(3 << 20, 9));
    b.chunk_delay_ms = 10;
    fx.add("/p.bin", b);
    let dir = temp_dir("noresume");
    let store = dir.join("manager.json");
    let m = Manager::new(tokio::runtime::Handle::current(), cfg(), Some(store.clone()), noop());
    let id = add(&m, fx.url("/p.bin"), &dir, None, true);
    tokio::time::sleep(Duration::from_millis(400)).await; // record saved while still active
    let m2 = Manager::new(tokio::runtime::Handle::current(), EngineConfig { resume_on_start: false, ..cfg() }, Some(store), noop());
    assert_eq!(m2.list()[0].rec.status, Status::Paused);
    tokio::time::sleep(Duration::from_millis(300)).await;
    assert_eq!(m2.list()[0].rec.status, Status::Paused, "nothing may start by itself");
    m.pause(id).unwrap();
}

fn sha256_hex_of(d: &[u8]) -> String {
    pdm_engine::download::sha256_hex(d)
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn pause_resume_cancel_via_manager() {
    let fx = Fixture::start().await;
    let mut b = Behavior::new(test_data(4 << 20, 8));
    b.chunk_delay_ms = 10;
    fx.add("/p.bin", b);
    let dir = temp_dir("mpr");
    let m = Manager::new(tokio::runtime::Handle::current(), cfg(), None, noop());
    let id = add(&m, fx.url("/p.bin"), &dir, None, true);
    wait_for(&m, "some bytes", |l| l[0].downloaded > 0).await;
    m.pause(id).unwrap();
    wait_for(&m, "paused", |l| l[0].rec.status == Status::Paused).await;
    m.resume(id).unwrap();
    wait_for(&m, "running again", |l| l[0].rec.status == Status::Running).await;
    m.cancel(id).unwrap();
    wait_for(&m, "cancelled", |l| l[0].rec.status == Status::Cancelled).await;
    assert_eq!(std::fs::read_dir(&dir).unwrap().count(), 0, "partial files must be removed");
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn failed_download_reports_error() {
    let fx = Fixture::start().await;
    let dir = temp_dir("mf");
    let m = Manager::new(tokio::runtime::Handle::current(), cfg(), None, noop());
    add(&m, fx.url("/nope"), &dir, None, true);
    wait_for(&m, "failed", |l| l[0].rec.status == Status::Failed).await;
    assert!(m.list()[0].rec.error.as_deref().unwrap().contains("404"));
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn schedule_start_and_stop_with_injected_clock() {
    let fx = Fixture::start().await;
    let mut b = Behavior::new(test_data(4 << 20, 9));
    b.chunk_delay_ms = 10;
    fx.add("/s.bin", b);
    let dir = temp_dir("sched");
    let m = Manager::new(tokio::runtime::Handle::current(), cfg(), None, noop());
    // Far-future times so the real scheduler task never fires; ticks use an injected clock.
    let base = now_secs() + 1_000_000;
    m.set_queue("night", QueueUpdate { start_at: Some(Some(base)), stop_at: Some(Some(base + 1000)), ..Default::default() }).unwrap();
    m.stop_queue("night").unwrap();
    let id = add(&m, fx.url("/s.bin"), &dir, Some("night"), true);
    m.tick_schedules(base - 1);
    tokio::time::sleep(Duration::from_millis(100)).await;
    assert_eq!(m.list()[0].rec.status, Status::Queued);
    m.tick_schedules(base);
    wait_for(&m, "started by schedule", |l| l[0].rec.status == Status::Running).await;
    m.tick_schedules(base + 1000);
    wait_for(&m, "stopped by schedule and re-queued", |l| l[0].rec.status == Status::Queued).await;
    let q = m.list_queues().into_iter().find(|q| q.name == "night").unwrap();
    assert!(!q.running && q.start_at.is_none() && q.stop_at.is_none());
    m.cancel(id).unwrap();
}

fn recorder() -> (Arc<Mutex<Vec<PostAction>>>, ActionRunner) {
    let calls: Arc<Mutex<Vec<PostAction>>> = Arc::new(Mutex::new(vec![]));
    let c2 = calls.clone();
    (calls, Arc::new(move |a| c2.lock().unwrap().push(a)))
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn queue_post_action_fires_once_after_the_queue_finishes() {
    let fx = Fixture::start().await;
    for i in 0..2 {
        let mut b = Behavior::new(test_data(200_000, 30 + i));
        b.chunk_delay_ms = 10;
        fx.add(&format!("/x{i}.bin"), b);
    }
    let (calls, runner) = recorder();
    let dir = temp_dir("post");
    let m = Manager::new(tokio::runtime::Handle::current(), cfg(), None, runner);
    m.set_queue("night", QueueUpdate { post_action: Some(PostAction::Shutdown), ..Default::default() }).unwrap();
    add(&m, fx.url("/x0.bin"), &dir, Some("night"), true);
    add(&m, fx.url("/x1.bin"), &dir, Some("night"), true);
    wait_for(&m, "both done", |l| l.iter().all(|i| i.rec.status == Status::Completed)).await;
    tokio::time::sleep(Duration::from_millis(200)).await;
    assert_eq!(*calls.lock().unwrap(), vec![PostAction::Shutdown]);
    let q = m.list_queues().into_iter().find(|q| q.name == "night").unwrap();
    assert_eq!(q.post_action, PostAction::None, "action must disarm after firing");
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn queue_post_action_does_not_fire_when_a_download_failed() {
    let fx = Fixture::start().await;
    fx.add("/ok.bin", Behavior::new(test_data(100_000, 40)));
    let (calls, runner) = recorder();
    let dir = temp_dir("postfail");
    let m = Manager::new(tokio::runtime::Handle::current(), cfg(), None, runner);
    m.set_queue("night", QueueUpdate { post_action: Some(PostAction::Shutdown), ..Default::default() }).unwrap();
    add(&m, fx.url("/ok.bin"), &dir, Some("night"), true);
    add(&m, fx.url("/missing"), &dir, Some("night"), true);
    wait_for(&m, "all settled", |l| l.iter().all(|i| matches!(i.rec.status, Status::Completed | Status::Failed))).await;
    tokio::time::sleep(Duration::from_millis(200)).await;
    assert!(calls.lock().unwrap().is_empty());
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn ordinary_downloads_and_other_queues_never_trigger_a_queue_action() {
    let fx = Fixture::start().await;
    fx.add("/plain.bin", Behavior::new(test_data(100_000, 41)));
    let (calls, runner) = recorder();
    let dir = temp_dir("postplain");
    let m = Manager::new(tokio::runtime::Handle::current(), cfg(), None, runner);
    // Armed on "night", but only a plain (default-queue) download runs.
    m.set_queue("night", QueueUpdate { post_action: Some(PostAction::Shutdown), ..Default::default() }).unwrap();
    add(&m, fx.url("/plain.bin"), &dir, None, true);
    wait_for(&m, "plain done", |l| l.iter().all(|i| i.rec.status == Status::Completed)).await;
    tokio::time::sleep(Duration::from_millis(200)).await;
    assert!(calls.lock().unwrap().is_empty());
    // The armed action is still waiting on its own queue.
    let q = m.list_queues().into_iter().find(|q| q.name == "night").unwrap();
    assert_eq!(q.post_action, PostAction::Shutdown);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn default_queue_rejects_a_post_action() {
    let m = Manager::new(tokio::runtime::Handle::current(), cfg(), None, noop());
    assert!(m.set_queue("default", QueueUpdate { post_action: Some(PostAction::Exit), ..Default::default() }).is_err());
    assert!(m.set_queue("default", QueueUpdate { post_action: Some(PostAction::None), ..Default::default() }).is_ok());
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn global_speed_limit_applies_to_manager_downloads() {
    let fx = Fixture::start().await;
    fx.add("/l.bin", Behavior::new(test_data(512 << 10, 50)));
    let dir = temp_dir("mlimit");
    let m = Manager::new(tokio::runtime::Handle::current(), cfg(), None, noop());
    m.update_settings(Some(256 * 1024), None, None).unwrap();
    let t = Instant::now();
    add(&m, fx.url("/l.bin"), &dir, None, true);
    wait_for(&m, "done", |l| l[0].rec.status == Status::Completed).await;
    assert!(t.elapsed() >= Duration::from_millis(800), "{:?}", t.elapsed());
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn add_validates_input() {
    let m = Manager::new(tokio::runtime::Handle::current(), cfg(), None, noop());
    let d = temp_dir("val");
    let bad = |url: &str, dir: std::path::PathBuf, q: Option<&str>| {
        m.add(AddRequest { url: url.into(), dest_dir: dir, filename: None, queue: q.map(String::from), sha256: None, max_conns: None, start: false, referer: None })
    };
    assert!(bad("ftp://x/y", d.clone(), None).is_err());
    assert!(bad("file:///etc/passwd", d.clone(), None).is_err());
    assert!(bad("not a url", d.clone(), None).is_err());
    assert!(bad("http://x/y", "relative/dir".into(), None).is_err());
    assert!(bad("http://x/y", d.clone(), Some("nope")).is_err());
    assert!(bad("http://x/y", d, None).is_ok());
}

#[test]
fn proxy_settings_build_urls_and_reject_bad_input() {
    use pdm_engine::manager::ProxySettings;
    let mut p = ProxySettings { mode: "manual".into(), kind: "socks5".into(), host: "127.0.0.1".into(), port: 1080, ..Default::default() };
    p.validate().unwrap();
    assert_eq!(p.url().unwrap(), "socks5h://127.0.0.1:1080");
    p.kind = "http".into();
    p.username = "u s".into();
    p.password = "p@ss".into();
    let u = p.url().unwrap();
    assert!(u.starts_with("http://") && u.contains("127.0.0.1:1080") && !u.contains("p@ss"), "credentials must be percent-encoded: {u}");
    for bad in [
        ProxySettings { host: String::new(), ..p.clone() },
        ProxySettings { port: 0, ..p.clone() },
        ProxySettings { host: "a/b".into(), ..p.clone() },
        ProxySettings { kind: "ftp".into(), ..p.clone() },
        ProxySettings { mode: "pac".into(), ..p.clone() },
    ] {
        assert!(bad.validate().is_err(), "{bad:?}");
    }
    assert!(ProxySettings::default().validate().is_ok());
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn add_rejects_non_http_referer() {
    let dir = temp_dir("referer");
    let m = Manager::new(tokio::runtime::Handle::current(), cfg(), None, noop());
    let mk = |r: &str| AddRequest { url: "http://127.0.0.1:9/x.bin".into(), dest_dir: dir.clone(), filename: None, queue: None, sha256: None, max_conns: None, start: false, referer: Some(r.into()) };
    assert!(m.add(mk("javascript:alert(1)")).is_err());
    assert!(m.add(mk("not a url")).is_err());
    assert!(m.add(mk("https://example.com/page?a=b")).is_ok());
}
