const HOST = "com.pdm.host";

// Resolves {ok, added, error}; never rejects, so callers only branch on ok.
function sendToPdm(urls, referer) {
  return new Promise((resolve) => {
    chrome.runtime.sendNativeMessage(HOST, { action: "add", urls, referer }, (r) => {
      const err = chrome.runtime.lastError;
      resolve(err ? { ok: false, error: err.message } : r || { ok: false, error: "no reply" });
    });
  });
}

function flash(tabId, ok) {
  chrome.action.setBadgeBackgroundColor({ color: ok ? "#2DD4BF" : "#EF4444" });
  chrome.action.setBadgeText({ text: ok ? "OK" : "!" });
  setTimeout(() => chrome.action.setBadgeText({ text: "" }), 2500);
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    const all = ["page", "selection", "link", "image", "video", "audio"];
    chrome.contextMenus.create({ id: "pdm", title: "PDM Integration Module", contexts: all });
    chrome.contextMenus.create({ id: "pdm-one", parentId: "pdm", title: "Download with PDM", contexts: ["link", "image", "video", "audio"] });
    chrome.contextMenus.create({ id: "pdm-all", parentId: "pdm", title: "Download all links with PDM", contexts: ["page", "selection", "link", "image", "video", "audio"] });
  });
});

// Runs inside each frame of the page (activeTab grants access after the menu click).
// Collects what IDM lists: links, media, images (incl. lazy/srcset), scripts, styles, frames and
// everything the page actually loaded (Resource Timing: CSS backgrounds, fonts, XHR/media files).
function collectLinks() {
  const sel = getSelection();
  const onlySel = !!sel && !sel.isCollapsed;
  const seen = new Map();
  const add = (el, raw, text) => {
    if (!raw || (onlySel && el && !sel.containsNode(el, true))) return;
    let url;
    try { url = new URL(raw, document.baseURI).href; } catch { return; }
    if (!/^https?:/i.test(url) || seen.has(url)) return;
    seen.set(url, (text || "").trim().replace(/\s+/g, " ").slice(0, 200));
  };
  const srcset = (el, v) => String(v || "").split(",").forEach((c) => add(el, c.trim().split(/\s+/)[0], el.alt || ""));
  const scan = (root) => {
    for (const el of root.querySelectorAll("*")) {
      const t = el.localName;
      if (t === "a" || t === "area") add(el, el.getAttribute("href"), el.textContent || el.title);
      else if (t === "link") add(el, el.getAttribute("href"), el.rel);
      else if (t === "script" || t === "iframe" || t === "embed" || t === "audio" || t === "video" || t === "source" || t === "track" || t === "img" || t === "input") add(el, el.getAttribute("src"), el.alt || "");
      else if (t === "object") add(el, el.getAttribute("data"), "");
      if (t === "img" || t === "source") {
        for (const k of ["data-src", "data-lazy-src", "data-original", "data-full"]) add(el, el.getAttribute(k), el.alt || "");
        srcset(el, el.getAttribute("srcset") || el.getAttribute("data-srcset"));
      }
      if (t === "video") add(el, el.getAttribute("poster"), "");
      const st = el.getAttribute("style");
      if (st && st.includes("url(")) for (const m of st.matchAll(/url\(\s*["']?([^"')]+)/g)) add(el, m[1], "");
      if (el.shadowRoot) scan(el.shadowRoot);
    }
  };
  scan(document);
  if (!onlySel) for (const e of performance.getEntriesByType("resource")) add(null, e.name, "");
  return [...seen].map(([url, text]) => ({ url, text }));
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "pdm-one") {
    const url = info.linkUrl || info.srcUrl;
    if (url) flash(tab && tab.id, (await sendToPdm([url], info.pageUrl)).ok);
  } else if (info.menuItemId === "pdm-all" && tab) {
    let res = [];
    try {
      res = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: collectLinks });
    } catch {
      res = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: collectLinks });
    }
    const merged = new Map();
    for (const r of res) for (const l of r.result || []) if (!merged.has(l.url)) merged.set(l.url, l);
    await chrome.storage.session.set({ grab: { links: [...merged.values()], page: tab.url || "" } });
    chrome.windows.create({ url: "grabber.html", type: "popup", width: 1000, height: 680 });
  }
});

// Optional IDM-style capture. Off by default: PDM sends no cookies/referrer, so logged-in downloads would fail.
chrome.downloads.onCreated.addListener(async (item) => {
  const { intercept } = await chrome.storage.local.get({ intercept: false });
  const url = item.finalUrl || item.url;
  if (!intercept || item.byExtensionId || !/^https?:/i.test(url)) return;
  if ((await sendToPdm([url], item.referrer)).ok) {
    chrome.downloads.cancel(item.id, () => chrome.downloads.erase({ id: item.id }));
  }
});

// ---- video capture: remember media files a tab loads, for the on-page "Download this video" button ----
// The listener does only string checks before touching storage, so ordinary page traffic stays cheap.
// HLS playlists (.m3u8) are kept and expanded into their quality variants when the menu opens.
// DASH, blob/MSE streams and YouTube's chunked videoplayback URLs are not single files and are skipped.
const mediaKey = (tabId) => "media" + tabId;
const HLS_RE = /\.m3u8(\?|#|$)/i;
const SEGMENT_RE = /\.(ts|m4s|cmfv|cmfa|aac)(\?|#|$)/i; // pieces of a stream, not a file
const MEDIA_EXT_RE = /\.(mp4|m4v|webm|mkv|mov|flv|3gp|mp3|m4a|ogg|opus|flac|wav)(\?|#|$)/i;
let mediaQueue = Promise.resolve(); // storage read-modify-write must not interleave

async function noteMedia(d) {
  if (d.tabId < 0 || (d.statusCode !== 200 && d.statusCode !== 206)) return;
  if (d.url.includes("/videoplayback") || SEGMENT_RE.test(d.url)) return;
  const h = (n) => ((d.responseHeaders || []).find((x) => x.name.toLowerCase() === n) || {}).value || "";
  const mime = h("content-type").split(";")[0].trim().toLowerCase();
  if (/dash\+xml/.test(mime) || /\.mpd(\?|#|$)/i.test(d.url) || mime === "video/mp2t") return;
  const hls = /mpegurl/.test(mime) || HLS_RE.test(d.url);
  const media = /^(audio|video)\//.test(mime) || (mime === "application/octet-stream" && MEDIA_EXT_RE.test(d.url));
  if (!hls && !media) return;
  const total = /\/(\d+)\s*$/.exec(h("content-range")); // a 206's content-length is only the chunk
  const size = hls ? 0 : total ? Number(total[1]) : Number(h("content-length")) || 0;
  if (!hls && size && size < 50000) return; // sound effects, ad pings
  const key = mediaKey(d.tabId);
  const list = (await chrome.storage.session.get(key))[key] || [];
  const old = list.find((m) => m.url === d.url);
  if (old) {
    old.size = size || old.size;
  } else {
    list.push({ url: d.url, mime, size, hls });
    if (list.length > 30) list.shift();
  }
  await chrome.storage.session.set({ [key]: list });
}

chrome.webRequest.onHeadersReceived.addListener(
  (d) => { mediaQueue = mediaQueue.then(() => noteMedia(d)).catch(() => {}); },
  { urls: ["<all_urls>"], types: ["media", "xmlhttprequest", "other"] },
  ["responseHeaders"]
);
chrome.tabs.onRemoved.addListener((id) => chrome.storage.session.remove(mediaKey(id)));
chrome.tabs.onUpdated.addListener((id, info) => { if (info.status === "loading" && info.url) chrome.storage.session.remove(mediaKey(id)); });

// ---- HLS: read a playlist and list its qualities (same rules as the engine: no encryption, no live) ----
function attrs(s) {
  const out = {};
  for (const m of s.matchAll(/([A-Z0-9-]+)=("[^"]*"|[^,]*)/g)) out[m[1]] = m[2].replace(/^"|"$/g, "");
  return out;
}

function parseM3u8(text, base) {
  const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (!lines.length || !lines[0].startsWith("#EXTM3U")) return { error: "not an HLS playlist" };
  const variants = [];
  let pending = null, ended = false, segments = 0, dur = 0, map = false, nextDur = 0;
  for (const l of lines) {
    if (l.startsWith("#EXT-X-STREAM-INF:")) {
      const a = attrs(l.slice(18));
      pending = { bw: Number(a.BANDWIDTH) || 0, h: Number((a.RESOLUTION || "").split(/x/i)[1]) || 0 };
    } else if (l.startsWith("#EXT-X-KEY:")) {
      const m = attrs(l.slice(11)).METHOD || "NONE";
      if (m !== "NONE") return { error: "encrypted (" + m + ") is not supported" };
    } else if (l.startsWith("#EXT-X-MAP:")) {
      map = true;
    } else if (l.startsWith("#EXT-X-BYTERANGE")) {
      return { error: "byte-range streams are not supported" };
    } else if (l.startsWith("#EXTINF:")) {
      nextDur = parseFloat(l.slice(8)) || 0;
    } else if (l.startsWith("#EXT-X-ENDLIST")) {
      ended = true;
    } else if (!l.startsWith("#")) {
      let u;
      try { u = new URL(l, base).href; } catch { continue; }
      if (pending) { variants.push({ url: u, ...pending }); pending = null; }
      else { segments++; dur += nextDur; nextDur = 0; }
    }
  }
  if (variants.length) return { variants };
  if (!segments) return { error: "playlist has no segments" };
  if (!ended) return { error: "live streams are not supported" };
  return { dur, ext: map ? "mp4" : "ts" };
}

async function hlsItems(url) {
  try {
    const r = await fetch(url, { credentials: "include", cache: "no-store", signal: AbortSignal.timeout(8000) });
    if (!r.ok) return [{ url, hls: true, error: "playlist answered HTTP " + r.status }];
    const p = parseM3u8((await r.text()).slice(0, 4000000), url);
    if (p.error) return [{ url, hls: true, error: p.error }];
    if (p.variants) return p.variants.map((v) => ({ url: v.url, hls: true, h: v.h, bw: v.bw, ext: "ts" }));
    return [{ url, hls: true, dur: p.dur, ext: p.ext }];
  } catch {
    return [{ url, hls: true, error: "playlist could not be read" }];
  }
}

async function buildList(tabId, domUrls) {
  const key = mediaKey(tabId);
  const known = new Map(((await chrome.storage.session.get(key))[key] || []).map((m) => [m.url, m]));
  for (const u of domUrls) if (!known.has(u)) known.set(u, { url: u, mime: "", size: 0, hls: HLS_RE.test(u) });
  const out = new Map();
  await Promise.all([...known.values()].map(async (it) => {
    for (const x of it.hls ? await hlsItems(it.url) : [it]) if (!out.has(x.url)) out.set(x.url, x);
  }));
  return [...out.values()];
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg) return;
  if (msg.type === "send") {
    sendToPdm(msg.urls, msg.referer).then(reply);
    return true; // async reply
  }
  if (msg.type === "media-list" && sender.tab) {
    buildList(sender.tab.id, Array.isArray(msg.dom) ? msg.dom.slice(0, 20) : []).then((list) => reply({ list }), () => reply({ list: [] }));
    return true;
  }
});
