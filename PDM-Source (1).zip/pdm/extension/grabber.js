const $ = (id) => document.getElementById(id);
let links = [];
let page = "";

const nameOf = (u) => { try { return decodeURIComponent(new URL(u).pathname.split("/").filter(Boolean).pop() || new URL(u).hostname); } catch { return u; } };
const extOf = (n) => (n.includes(".") ? n.split(".").pop().slice(0, 8).toLowerCase() : "");

const MAX_ROWS = 3000; // keep the window responsive on huge pages; use the filter to narrow down
const PAGE_EXT = new Set(["html", "htm", "php", "asp", "aspx", "jsp", ""]);

function render() {
  const q = $("filter").value.trim().toLowerCase().replace(/^\./, "");
  const hide = $("nohtml").checked;
  const frag = document.createDocumentFragment();
  let shown = 0;
  for (const l of links) {
    const name = nameOf(l.url), ext = extOf(name);
    if (hide && PAGE_EXT.has(ext)) continue;
    if (q && !(name + " " + l.url + " " + l.text).toLowerCase().includes(q)) continue;
    if (shown++ >= MAX_ROWS) break;
    const tr = document.createElement("tr");
    tr.dataset.url = l.url;
    // textContent only: link text and URLs come from the page and are untrusted.
    for (const [i, v] of [[0, null], [1, name], [2, ext], [3, l.url], [4, l.text]]) {
      const td = document.createElement("td");
      if (i === 0) { const c = document.createElement("input"); c.type = "checkbox"; c.checked = !!l.on; c.onchange = () => { l.on = c.checked; count(); }; td.append(c); }
      else { td.textContent = v; td.title = v; }
      tr.append(td);
    }
    frag.append(tr);
  }
  $("rows").replaceChildren(frag);
  count();
}

function count() {
  const n = links.filter((l) => l.on).length;
  $("count").textContent = `${n} selected of ${links.length}`;
  $("ok").disabled = n === 0;
}

let timer;
$("filter").oninput = () => { clearTimeout(timer); timer = setTimeout(render, 150); };
$("nohtml").onchange = render;
$("all").onchange = (e) => {
  const shown = new Set([...$("rows").children].map((tr) => tr.dataset.url));
  links.forEach((l) => { if (shown.has(l.url)) l.on = e.target.checked; });
  render();
};
$("cancel").onclick = () => window.close();
$("ok").onclick = async () => {
  $("ok").disabled = true;
  const r = await chrome.runtime.sendMessage({ type: "send", referer: page, urls: links.filter((l) => l.on).map((l) => l.url) });
  if (r && r.ok) window.close();
  else { $("msg").textContent = "PDM: " + ((r && r.error) || "failed"); $("ok").disabled = false; }
};

chrome.storage.session.get("grab").then(({ grab }) => {
  page = (grab && grab.page) || "";
  links = ((grab && grab.links) || []).map((l) => ({ ...l, on: false }));
  render();
  if (!links.length) $("msg").textContent = "No links found on this page.";
});
