import 'dart:ui' show AppExitResponse;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'pages.dart';
import 'state.dart';
import 'ui.dart';

final navKey = GlobalKey<NavigatorState>();

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // A failing widget shows its error instead of the default grey box, so bug reports carry the cause.
  ErrorWidget.builder = (d) => Padding(padding: const EdgeInsets.all(8), child: Text(d.exceptionAsString(), style: const TextStyle(color: Color(0xFFEF4444), fontSize: 11)));
  // Release builds paint a build error as a big gray box; show the message instead.
  ErrorWidget.builder = (d) => Padding(padding: const EdgeInsets.all(8), child: Text('UI error: ${d.exceptionAsString()}', style: const TextStyle(color: Color(0xFFEF4444), fontSize: 11)));
  app.loadPrefs();
  app.start();
  // Closing PDM must not leave an invisible engine downloading: ask, then stop it.
  AppLifecycleListener(onExitRequested: () async {
    final active = app.downloads.where((d) => d.status == 'running' || d.status == 'queued').length;
    final ctx = navKey.currentContext;
    if (active > 0 && ctx != null) {
      final r = await showDialog<String>(
        context: ctx,
        builder: (c) => AlertDialog(
          title: Text('$active download${active == 1 ? '' : 's'} in progress'),
          content: const Text('Stop them and quit, or keep downloading in the background? The background engine keeps using your internet until you finish them or reopen PDM and quit.'),
          actions: [
            PBtn('Cancel', onTap: () => Navigator.pop(c, 'cancel')),
            PBtn('Keep downloading', onTap: () => Navigator.pop(c, 'keep')),
            PBtn('Stop and quit', primary: true, onTap: () => Navigator.pop(c, 'quit')),
          ],
        ),
      );
      if (r == null || r == 'cancel') return AppExitResponse.cancel;
      if (r == 'keep') return AppExitResponse.exit;
    }
    try {
      await app.ipc.call('app.shutdown');
    } catch (_) {} // engine already gone
    return AppExitResponse.exit;
  });
  runApp(const PdmApp());
}

class PdmApp extends StatelessWidget {
  const PdmApp({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: app,
        builder: (_, __) {
          final t = app.theme;
          return MaterialApp(
            title: 'PDM',
            navigatorKey: navKey,
            debugShowCheckedModeBanner: false,
            theme: app.themeData,
            // The gradient (Aurora/Ocean) or flat colour sits behind every page.
            builder: (_, child) => AnimatedContainer(
              duration: const Duration(milliseconds: 350),
              decoration: BoxDecoration(
                color: t.gradient == null ? t.bg : null,
                gradient: t.gradient == null ? null : LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: t.gradient!),
              ),
              child: child,
            ),
            home: const Shell(),
          );
        },
      );
}

class Shell extends StatelessWidget {
  const Shell({super.key});

  static const _nav = [
    (Icons.download_rounded, 'Downloads'),
    (Icons.schedule_rounded, 'Queues'),
    (Icons.settings_rounded, 'Settings'),
  ];

  @override
  Widget build(BuildContext context) {
    // Not const on purpose: a const page would be skipped when AppState notifies.
    return ListenableBuilder(
      listenable: app,
      builder: (_, __) {
        final pages = [DownloadsPage(), QueuesPage(), SettingsPage()];
        return Scaffold(
          body: Row(children: [
            _Sidebar(),
            Expanded(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 260),
                transitionBuilder: (w, a) => FadeTransition(opacity: a, child: SlideTransition(position: Tween(begin: const Offset(0, 0.02), end: Offset.zero).animate(a), child: w)),
                child: KeyedSubtree(key: ValueKey(app.page), child: pages[app.page]),
              ),
            ),
          ]),
        );
      },
    );
  }
}

class _Sidebar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final a = accentOf(context);
    final active = app.downloads.where((d) => d.status == 'running').length;
    return Container(
      width: 224,
      padding: const EdgeInsets.fromLTRB(14, 22, 14, 16),
      decoration: BoxDecoration(color: surfaceOf(context).withAlpha(200), border: Border(right: BorderSide(color: borderOf(context)))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), gradient: LinearGradient(colors: [a, Color.lerp(a, Colors.white, 0.35)!]), boxShadow: [BoxShadow(color: a.withAlpha(90), blurRadius: 14)]),
            child: Icon(Icons.arrow_downward_rounded, color: Theme.of(context).colorScheme.onPrimary),
          ),
          const SizedBox(width: 12),
          const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('PDM', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: 1)),
            Text('Pervert Download Manager', style: TextStyle(fontSize: 9.5)),
          ]),
        ]),
        const SizedBox(height: 26),
        for (var i = 0; i < Shell._nav.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Hover(
              onTap: () => app.setPage(i),
              builder: (h) {
                final on = app.page == i;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    color: on ? a.withAlpha(44) : (h ? surface2Of(context) : Colors.transparent),
                    border: Border.all(color: on ? a.withAlpha(120) : Colors.transparent),
                  ),
                  child: Row(children: [
                    Icon(Shell._nav[i].$1, size: 20, color: on ? a : dimOf(context)),
                    const SizedBox(width: 12),
                    Expanded(child: Text(Shell._nav[i].$2, style: TextStyle(fontWeight: FontWeight.w600, color: on ? a : null))),
                    if (i == 0 && active > 0) Chip2('$active', a),
                  ]),
                );
              },
            ),
          ),
        const Spacer(),
        Panel(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              AnimatedContainer(duration: const Duration(milliseconds: 300), width: 9, height: 9, decoration: BoxDecoration(shape: BoxShape.circle, color: app.connected ? const Color(0xFF22C55E) : const Color(0xFFEF4444))),
              const SizedBox(width: 8),
              Text(app.connected ? 'Engine connected' : 'Engine offline', style: const TextStyle(fontSize: 12)),
            ]),
            const SizedBox(height: 8),
            Sparkline(app.speedHist, a),
            const SizedBox(height: 4),
            Text('${humanSize(app.totalSpeed)}/s', style: const TextStyle(fontWeight: FontWeight.w700)),
          ]),
        ),
      ]),
    );
  }
}

// ---- Downloads page ---------------------------------------------------------------------------
class DownloadsPage extends StatelessWidget {
  DownloadsPage({super.key});

  static final _filters = [('all', 'All'), ('active', 'Active'), ('queued', 'Queued'), ('completed', 'Completed'), ('failed', 'Failed')];

  int _count(String f) => app.downloads.where((d) {
        return switch (f) {
          'active' => d.status == 'running' || d.status == 'paused',
          'queued' => d.status == 'queued',
          'completed' => d.status == 'completed',
          'failed' => d.status == 'failed' || d.status == 'cancelled',
          _ => true,
        };
      }).length;

  @override
  Widget build(BuildContext context) {
    final rows = app.visible;
    Dl? sel;
    for (final d in app.downloads) {
      if (d.id == app.selected) sel = d;
    }
    return Padding(
      padding: const EdgeInsets.fromLTRB(26, 22, 22, 18),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Text('Downloads', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
          const Spacer(),
          SizedBox(
            width: 260,
            child: TextField(
              onChanged: app.setSearch,
              decoration: InputDecoration(hintText: 'Search downloads', prefixIcon: const Icon(Icons.search_rounded, size: 20), isDense: true, contentPadding: const EdgeInsets.symmetric(vertical: 12), border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none)),
            ),
          ),
          const SizedBox(width: 12),
          PBtn('Add download', icon: Icons.add_rounded, primary: true, onTap: () => showAddDialog(context)),
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert_rounded),
            onSelected: (v) async {
              final done = (Dl d) => d.status == 'completed';
              final bad = (Dl d) => d.status == 'failed' || d.status == 'cancelled';
              final e = switch (v) {
                'pause' => await app.bulk('downloads.pause', (d) => d.status == 'running' || d.status == 'queued'),
                'resume' => await app.bulk('downloads.resume', (d) => d.status == 'paused'),
                'done' => await app.bulk('downloads.remove', done),
                'bad' => await app.bulk('downloads.remove', bad),
                _ => await app.bulk('downloads.remove', (d) => done(d) || bad(d)),
              };
              if (e != null && context.mounted) toast(context, e);
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'pause', child: Text('Pause all')),
              PopupMenuItem(value: 'resume', child: Text('Resume all paused')),
              PopupMenuDivider(),
              PopupMenuItem(value: 'done', child: Text('Clear completed')),
              PopupMenuItem(value: 'bad', child: Text('Clear failed and cancelled')),
              PopupMenuItem(value: 'all', child: Text('Clear all finished')),
            ],
          ),
        ]),
        const SizedBox(height: 14),
        Wrap(spacing: 8, children: [for (final f in _filters) Pill('${f.$2}  ${_count(f.$1)}', app.filter == f.$1, () => app.setFilter(f.$1))]),
        const SizedBox(height: 14),
        Expanded(
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(child: Panel(padding: EdgeInsets.zero, child: rows.isEmpty ? _Empty() : _Table(rows))),
            AnimatedSize(
              duration: const Duration(milliseconds: 260),
              curve: Curves.easeOutCubic,
              alignment: Alignment.centerLeft,
              child: sel == null ? const SizedBox(width: 0) : Padding(padding: const EdgeInsets.only(left: 14), child: SizedBox(width: 340, child: _Details(sel))),
            ),
          ]),
        ),
      ]),
    );
  }
}

class _Empty extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(app.connected ? Icons.cloud_download_outlined : Icons.power_off_rounded, size: 54, color: dimOf(context)),
          const SizedBox(height: 12),
          Text(app.connected ? 'No downloads here yet' : 'Starting the PDM engine…', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          Text(app.connected ? 'Click “Add download” or use the browser extension.' : 'If this stays, make sure pdmd.exe is next to pdm.exe.', style: TextStyle(color: dimOf(context))),
        ]),
      );
}

Widget _cell(int flex, Widget w) => Expanded(flex: flex, child: Padding(padding: const EdgeInsets.symmetric(horizontal: 6), child: w));

/// Clickable column title; the arrow shows the active sort and its direction.
class _Head extends StatelessWidget {
  final String label, sortKey;
  const _Head(this.label, this.sortKey);
  @override
  Widget build(BuildContext context) {
    final on = app.sortKey == sortKey;
    final c = on ? accentOf(context) : dimOf(context);
    return Hover(
      onTap: () => app.setSort(sortKey),
      builder: (h) => Row(mainAxisSize: MainAxisSize.min, children: [
        Flexible(child: Text(label, overflow: TextOverflow.ellipsis, style: TextStyle(color: h ? accentOf(context) : c, fontSize: 12, fontWeight: FontWeight.w700))),
        if (on) Icon(app.sortAsc ? Icons.arrow_upward_rounded : Icons.arrow_downward_rounded, size: 14, color: c),
      ]),
    );
  }
}

class _Table extends StatelessWidget {
  final List<Dl> rows;
  const _Table(this.rows);
  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (context, box) {
        final wide = box.maxWidth > 980; // queue and date columns only when there is room
        return Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(46, 14, 12, 8),
            child: Row(children: [
              _cell(5, const _Head('NAME', 'name')),
              if (wide) _cell(2, const _Head('QUEUE', 'queue')),
              _cell(2, const _Head('SIZE', 'size')),
              _cell(2, const _Head('STATUS', 'status')),
              _cell(4, const _Head('PROGRESS', 'progress')),
              _cell(2, const _Head('SPEED', 'speed')),
              _cell(2, const _Head('LEFT', 'left')),
              if (wide) _cell(3, const _Head('LAST TRY', 'date')),
              const SizedBox(width: 120),
            ]),
          ),
          Divider(height: 1, color: borderOf(context)),
          Expanded(child: ListView.builder(itemCount: rows.length, itemBuilder: (_, i) => _Row(rows[i], i, wide))),
        ]);
      });
}

class _Row extends StatelessWidget {
  final Dl d;
  final int index;
  final bool wide;
  const _Row(this.d, this.index, this.wide);

  static IconData _icon(String n) {
    final e = n.contains('.') ? n.split('.').last.toLowerCase() : '';
    if (const {'mp3', 'flac', 'm4a', 'wav', 'ogg', 'opus', 'aac'}.contains(e)) return Icons.music_note_rounded;
    if (const {'mp4', 'mkv', 'avi', 'mov', 'webm', 'ts', 'flv'}.contains(e)) return Icons.movie_rounded;
    if (const {'zip', 'rar', '7z', 'gz', 'tar'}.contains(e)) return Icons.archive_rounded;
    if (const {'jpg', 'jpeg', 'png', 'gif', 'webp'}.contains(e)) return Icons.image_rounded;
    if (const {'exe', 'msi'}.contains(e)) return Icons.settings_applications_rounded;
    if (e == 'pdf') return Icons.picture_as_pdf_rounded;
    return Icons.insert_drive_file_rounded;
  }

  Future<void> _menu(BuildContext context, Offset p) async {
    final done = d.status == 'completed';
    final overlay = Overlay.of(context).context.findRenderObject()! as RenderBox;
    final v = await showMenu<String>(
      context: context,
      position: RelativeRect.fromRect(Rect.fromPoints(p, p), Offset.zero & overlay.size),
      items: [
        if (done) const PopupMenuItem(value: 'file', child: Text('Open file')),
        if (d.status == 'running' || d.status == 'queued') const PopupMenuItem(value: 'pause', child: Text('Pause')),
        if (d.status == 'paused' || d.status == 'failed' || d.status == 'cancelled') const PopupMenuItem(value: 'resume', child: Text('Resume')),
        const PopupMenuItem(value: 'folder', child: Text('Open folder')),
        const PopupMenuItem(value: 'copy', child: Text('Copy URL')),
        if (d.active) const PopupMenuItem(value: 'cancel', child: Text('Cancel and delete partial data')),
        const PopupMenuItem(value: 'remove', child: Text('Remove from list')),
      ],
    );
    if (v == null) return;
    switch (v) {
      case 'pause' || 'resume' || 'cancel' || 'remove':
        final e = await app.act('downloads.$v', {'id': d.id});
        if (e != null && context.mounted) toast(context, e);
      case 'file':
        openPath(d.finalPath ?? '');
      case 'folder':
        d.finalPath != null ? openPath(d.finalPath!, select: true) : openPath(d.dir);
      case 'copy':
        Clipboard.setData(ClipboardData(text: d.url));
    }
  }

  @override
  Widget build(BuildContext context) {
    final sel = app.selected == d.id;
    final c = statusColor(d.status);
    final a = accentOf(context);
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 250 + (index > 8 ? 8 : index) * 40),
      builder: (_, v, child) => Opacity(opacity: v, child: Transform.translate(offset: Offset(0, 8 * (1 - v)), child: child)),
      child: Hover(
        onTap: () => app.select(sel ? null : d.id),
        onSecondary: (p) => _menu(context, p),
        builder: (h) => AnimatedContainer(
          duration: const Duration(milliseconds: 140),
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
          decoration: BoxDecoration(color: sel ? a.withAlpha(34) : (h ? surface2Of(context).withAlpha(160) : Colors.transparent), border: Border(left: BorderSide(color: sel ? a : Colors.transparent, width: 3))),
          child: Row(children: [
            Container(width: 34, height: 34, decoration: BoxDecoration(color: a.withAlpha(30), borderRadius: BorderRadius.circular(10)), child: Icon(_icon(d.name), size: 19, color: a)),
            const SizedBox(width: 6),
            _cell(5, Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(d.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)), Text(d.url, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11, color: dimOf(context)))])),
            if (wide) _cell(2, Text(d.queue, maxLines: 1, overflow: TextOverflow.ellipsis)),
            _cell(2, Text(humanSize(d.total))),
            _cell(2, Align(alignment: Alignment.centerLeft, child: Chip2(d.status[0].toUpperCase() + d.status.substring(1), c))),
            _cell(4, Row(children: [Expanded(child: Bar(d.total > 0 || d.status == 'completed' ? d.progress : (d.status == 'running' ? null : 0), color: c)), const SizedBox(width: 8), SizedBox(width: 38, child: Text('${(d.progress * 100).round()}%', style: const TextStyle(fontSize: 12)))])),
            _cell(2, Text(d.status == 'running' ? '${humanSize(d.speed)}/s' : '--')),
            _cell(2, Text(d.status == 'running' ? humanEta(d.eta) : '--')),
            if (wide) _cell(3, Text(fmtDate(d.date), style: TextStyle(fontSize: 12, color: dimOf(context)))),
            SizedBox(
              width: 120,
              child: Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                if (d.status == 'running' || d.status == 'queued') IBtn(Icons.pause_rounded, 'Pause', () => app.act('downloads.pause', {'id': d.id})),
                if (d.status == 'paused' || d.status == 'failed' || d.status == 'cancelled') IBtn(Icons.play_arrow_rounded, 'Resume', () => app.act('downloads.resume', {'id': d.id})),
                if (d.status == 'completed') IBtn(Icons.open_in_new_rounded, 'Open file', () => openPath(d.finalPath ?? '')),
                if (d.status == 'completed') IBtn(Icons.folder_open_rounded, 'Show in folder', () => openPath(d.finalPath ?? d.dir, select: d.finalPath != null)),
                IBtn(Icons.close_rounded, 'Remove', () => app.act('downloads.remove', {'id': d.id}), color: const Color(0xFFEF4444)),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}

class _Details extends StatelessWidget {
  final Dl d;
  const _Details(this.d);
  @override
  Widget build(BuildContext context) {
    final c = statusColor(d.status);
    Widget kv(String k, String v) => Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Row(children: [Expanded(child: Text(k, style: TextStyle(color: dimOf(context)))), Text(v, style: const TextStyle(fontWeight: FontWeight.w600))]));
    Widget head(String t) => Padding(padding: const EdgeInsets.only(top: 14, bottom: 4), child: Text(t, style: TextStyle(color: dimOf(context), fontSize: 11, fontWeight: FontWeight.w700)));
    final done = d.status == 'completed';
    return Panel(
      child: SingleChildScrollView(
        // The desktop scrollbar draws over the content; keep text clear of it.
        child: Padding(
          padding: const EdgeInsets.only(right: 14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Expanded(child: Text(d.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))), IBtn(Icons.close_rounded, 'Close', () => app.select(null))]),
            const SizedBox(height: 8),
            Chip2(d.status.toUpperCase(), c),
            const SizedBox(height: 12),
            Wrap(spacing: 8, runSpacing: 8, children: [
              if (done) PBtn('Run', icon: Icons.play_arrow_rounded, primary: true, onTap: () => openPath(d.finalPath ?? '')),
              if (d.status == 'running' || d.status == 'queued') PBtn('Pause', icon: Icons.pause_rounded, onTap: () => app.act('downloads.pause', {'id': d.id})),
              if (d.status == 'paused' || d.status == 'failed' || d.status == 'cancelled') PBtn('Resume', icon: Icons.play_arrow_rounded, primary: true, onTap: () => app.act('downloads.resume', {'id': d.id})),
              PBtn('Folder', icon: Icons.folder_open_rounded, onTap: () => openPath(d.finalPath ?? d.dir, select: d.finalPath != null)),
            ]),
            const SizedBox(height: 14),
            Bar(d.total > 0 || done ? d.progress : null, height: 12, color: c),
            const SizedBox(height: 14),
            kv('Downloaded', '${humanSize(d.downloaded)} / ${humanSize(d.total)}'),
            kv('Speed', d.status == 'running' ? '${humanSize(d.speed)}/s' : '--'),
            kv('Time left', d.status == 'running' ? humanEta(d.eta) : '--'),
            kv('Connections', '${d.conns}${d.segmented ? '' : ' (single stream)'}'),
            kv('Retries', '${d.retries}'),
            kv('Queue', d.queue),
            kv('Last try', fmtDate(d.date)),
            if (d.error != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(d.error!, style: const TextStyle(color: Color(0xFFEF4444)))),
            head('SPEED'),
            Sparkline(app.histOf(d.id), c, height: 70),
            if (d.segs.isNotEmpty) ...[head('CONNECTIONS'), SegmentBars(d.segs, c)],
            head('URL'),
            SelectableText(d.url, style: const TextStyle(fontSize: 12)),
            head('SAVED TO'),
            SelectableText(d.finalPath ?? d.dir, style: const TextStyle(fontSize: 12)),
          ]),
        ),
      ),
    );
  }
}

// ---- Add download dialog ---------------------------------------------------------------------
Future<void> showAddDialog(BuildContext context) => showDialog<void>(context: context, builder: (_) => const _AddDialog());

class _AddDialog extends StatefulWidget {
  const _AddDialog();
  @override
  State<_AddDialog> createState() => _AddDialogState();
}

class _AddDialogState extends State<_AddDialog> {
  final url = TextEditingController(), dir = TextEditingController(text: app.downloadDir), sha = TextEditingController(), conns = TextEditingController();
  String queue = 'default';
  bool start = true;
  String? error;
  bool busy = false;

  Future<void> submit() async {
    final urls = url.text.split(RegExp(r'\s+')).where((s) => s.isNotEmpty).toList();
    final shaT = sha.text.trim();
    String? err;
    if (urls.isEmpty || urls.any((u) => !RegExp(r'^https?://\S+$', caseSensitive: false).hasMatch(u))) {
      err = 'Enter valid http:// or https:// URLs (one per line).';
    } else if (!RegExp(r'^([A-Za-z]:\\|\\\\)').hasMatch(dir.text.trim())) {
      err = 'Choose an absolute destination folder.';
    } else if (shaT.isNotEmpty && !RegExp(r'^[0-9a-fA-F]{64}$').hasMatch(shaT)) {
      err = 'Checksum must be 64 hexadecimal characters.';
    }
    if (err != null) return setState(() => error = err);
    setState(() => busy = true);
    final n = int.tryParse(conns.text.trim()) ?? 0;
    for (final u in urls) {
      final e = await app.act('downloads.add', {
        'url': u,
        'dest_dir': dir.text.trim(),
        'queue': queue,
        'start': start,
        if (shaT.isNotEmpty && urls.length == 1) 'sha256': shaT,
        if (n > 0) 'max_conns': n,
      });
      if (e != null) {
        if (mounted) setState(() { error = e; busy = false; });
        return;
      }
    }
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final names = app.queues.isEmpty ? ['default'] : [for (final q in app.queues) q['name'] as String];
    return Dialog(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 560),
        child: Padding(
          padding: const EdgeInsets.all(26),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Add download', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 18),
            TextField(controller: url, autofocus: true, minLines: 1, maxLines: 4, decoration: const InputDecoration(labelText: 'URL (one per line)', hintText: 'https://example.com/file.zip')),
            const SizedBox(height: 12),
            TextField(controller: dir, decoration: const InputDecoration(labelText: 'Save to')),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: DropdownButtonFormField<String>(initialValue: names.contains(queue) ? queue : names.first, decoration: const InputDecoration(labelText: 'Queue'), items: [for (final n in names) DropdownMenuItem(value: n, child: Text(n))], onChanged: (v) => queue = v ?? 'default')),
              const SizedBox(width: 12),
              Expanded(child: TextField(controller: conns, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Connections', hintText: 'Default'))),
            ]),
            const SizedBox(height: 12),
            TextField(controller: sha, decoration: const InputDecoration(labelText: 'SHA-256 (optional, single URL only)')),
            const SizedBox(height: 6),
            SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Start immediately'), value: start, onChanged: (v) => setState(() => start = v)),
            if (error != null) Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(error!, style: const TextStyle(color: Color(0xFFEF4444)))),
            Row(mainAxisAlignment: MainAxisAlignment.end, children: [
              PBtn('Cancel', onTap: () => Navigator.pop(context)),
              const SizedBox(width: 10),
              PBtn(busy ? 'Adding…' : 'Add', primary: true, onTap: busy ? null : submit),
            ]),
          ]),
        ),
      ),
    );
  }
}
