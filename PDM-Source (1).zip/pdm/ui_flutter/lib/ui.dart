import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';


Color accentOf(BuildContext c) => Theme.of(c).colorScheme.primary;
Color dimOf(BuildContext c) => Theme.of(c).colorScheme.onSurfaceVariant;
Color borderOf(BuildContext c) => Theme.of(c).colorScheme.outline;
Color surfaceOf(BuildContext c) => Theme.of(c).colorScheme.surface;
Color surface2Of(BuildContext c) => Theme.of(c).colorScheme.surfaceContainerHighest;

/// Mouse-hover wrapper with a builder, so widgets can animate on hover.
class Hover extends StatefulWidget {
  final Widget Function(bool hovered) builder;
  final VoidCallback? onTap;
  final void Function(Offset globalPos)? onSecondary;
  const Hover({super.key, required this.builder, this.onTap, this.onSecondary});
  @override
  State<Hover> createState() => _HoverState();
}

class _HoverState extends State<Hover> {
  bool h = false;
  @override
  Widget build(BuildContext context) => MouseRegion(
        onEnter: (_) => setState(() => h = true),
        onExit: (_) => setState(() => h = false),
        cursor: widget.onTap == null ? MouseCursor.defer : SystemMouseCursors.click,
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: widget.onTap,
          onSecondaryTapDown: widget.onSecondary == null ? null : (d) => widget.onSecondary!(d.globalPosition),
          child: widget.builder(h),
        ),
      );
}

/// Primary (gradient fill) or ghost (outlined) button with hover glow.
class PBtn extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onTap;
  final bool primary, danger;
  const PBtn(this.label, {super.key, this.icon, this.onTap, this.primary = false, this.danger = false});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final base = danger ? const Color(0xFFEF4444) : cs.primary;
    final off = onTap == null;
    return Hover(
      onTap: onTap,
      builder: (h) => AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: primary && !off ? LinearGradient(colors: [base, Color.lerp(base, Colors.white, h ? 0.25 : 0.1)!]) : null,
          color: primary ? (off ? cs.outline : null) : (h && !off ? base.withAlpha(30) : Colors.transparent),
          border: primary ? null : Border.all(color: h && !off ? base : cs.outline),
          boxShadow: primary && h && !off ? [BoxShadow(color: base.withAlpha(90), blurRadius: 16, offset: const Offset(0, 4))] : const [],
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          if (icon != null) ...[Icon(icon, size: 18, color: primary ? cs.onPrimary : (off ? cs.onSurfaceVariant : (danger ? base : cs.onSurface))), const SizedBox(width: 8)],
          Text(label, style: TextStyle(fontWeight: FontWeight.w600, color: primary ? cs.onPrimary : (off ? cs.onSurfaceVariant : (danger && h ? base : cs.onSurface)))),
        ]),
      ),
    );
  }
}

class IBtn extends StatelessWidget {
  final IconData icon;
  final String tip;
  final VoidCallback? onTap;
  final Color? color;
  const IBtn(this.icon, this.tip, this.onTap, {super.key, this.color});
  @override
  Widget build(BuildContext context) => Tooltip(
        message: tip,
        child: Hover(
          onTap: onTap,
          builder: (h) => AnimatedContainer(
            duration: const Duration(milliseconds: 140),
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(color: h ? (color ?? accentOf(context)).withAlpha(36) : Colors.transparent, borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, size: 19, color: onTap == null ? dimOf(context) : (h ? (color ?? accentOf(context)) : null)),
          ),
        ),
      );
}

class Panel extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  const Panel({super.key, required this.child, this.padding = const EdgeInsets.all(18)});
  @override
  Widget build(BuildContext context) => Container(
        padding: padding,
        decoration: BoxDecoration(
          color: surfaceOf(context).withAlpha(230),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: borderOf(context)),
        ),
        child: child,
      );
}

/// Animated progress bar. value null = indeterminate.
class Bar extends StatelessWidget {
  final double? value;
  final double height;
  final Color? color;
  const Bar(this.value, {super.key, this.height = 8, this.color});
  @override
  Widget build(BuildContext context) {
    final c = color ?? accentOf(context);
    return ClipRRect(
      borderRadius: BorderRadius.circular(height),
      child: SizedBox(
        height: height,
        child: value == null
            ? LinearProgressIndicator(minHeight: height, color: c, backgroundColor: borderOf(context))
            : TweenAnimationBuilder<double>(
                tween: Tween(end: value!.clamp(0, 1).toDouble()),
                duration: const Duration(milliseconds: 450),
                curve: Curves.easeOutCubic,
                builder: (_, v, __) => Stack(fit: StackFit.expand, children: [
                  Container(color: borderOf(context)),
                  FractionallySizedBox(
                    widthFactor: v,
                    alignment: Alignment.centerLeft,
                    child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(colors: [c, Color.lerp(c, Colors.white, 0.35)!]))),
                  ),
                ]),
              ),
      ),
    );
  }
}

class Chip2 extends StatelessWidget {
  final String text;
  final Color color;
  const Chip2(this.text, this.color, {super.key});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
        decoration: BoxDecoration(color: color.withAlpha(38), borderRadius: BorderRadius.circular(20)),
        child: Text(text, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: color)),
      );
}

Color statusColor(String s) => switch (s) {
      'running' => const Color(0xFF3B82F6),
      'completed' => const Color(0xFF22C55E),
      'failed' => const Color(0xFFEF4444),
      'paused' => const Color(0xFFF59E0B),
      _ => const Color(0xFF8E95A5),
    };

/// Selectable pill (filters, formats, qualities).
class Pill extends StatelessWidget {
  final String text;
  final bool on;
  final VoidCallback onTap;
  const Pill(this.text, this.on, this.onTap, {super.key});
  @override
  Widget build(BuildContext context) {
    final a = accentOf(context);
    return Hover(
      onTap: onTap,
      builder: (h) => AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        decoration: BoxDecoration(
          color: on ? a.withAlpha(46) : (h ? surface2Of(context) : Colors.transparent),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: on ? a : borderOf(context)),
        ),
        child: Text(text, style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13, color: on ? a : null)),
      ),
    );
  }
}

class Sparkline extends StatelessWidget {
  final List<double> data;
  final Color color;
  final double height;
  const Sparkline(this.data, this.color, {super.key, this.height = 44});
  @override
  Widget build(BuildContext context) => SizedBox(height: height, width: double.infinity, child: CustomPaint(painter: _SparkPainter(List.of(data), color)));
}

class _SparkPainter extends CustomPainter {
  final List<double> d;
  final Color c;
  _SparkPainter(this.d, this.c);
  @override
  void paint(Canvas canvas, Size s) {
    if (d.length < 2) return;
    final mx = math.max(d.reduce(math.max), 1.0);
    final line = Path();
    for (var i = 0; i < d.length; i++) {
      final x = s.width * i / (d.length - 1);
      final y = s.height - (d[i] / mx) * (s.height - 4) - 2;
      i == 0 ? line.moveTo(x, y) : line.lineTo(x, y);
    }
    final fill = Path.from(line)
      ..lineTo(s.width, s.height)
      ..lineTo(0, s.height)
      ..close();
    canvas.drawPath(fill, Paint()..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [c.withAlpha(90), c.withAlpha(0)]).createShader(Offset.zero & s));
    canvas.drawPath(line, Paint()..color = c..style = PaintingStyle.stroke..strokeWidth = 2..strokeJoin = StrokeJoin.round);
  }

  @override
  bool shouldRepaint(_SparkPainter o) => true;
}

/// One thin bar per connection, filled by how much of that range is done.
class SegmentBars extends StatelessWidget {
  final List<List<int>> segs;
  final Color color;
  const SegmentBars(this.segs, this.color, {super.key});
  @override
  Widget build(BuildContext context) => Column(children: [
        for (final s in segs)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 2),
            child: Bar(s[1] >= s[0] ? (s[2] / (s[1] - s[0] + 1)) : 0, height: 5, color: color),
          ),
      ]);
}

Future<void> openPath(String p, {bool select = false}) async {
  if (p.isEmpty) return;
  if (select) {
    await Process.run('explorer.exe', ['/select,', p]);
  } else {
    await Process.run('explorer.exe', [p]);
  }
}

void toast(BuildContext c, String m) =>
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m), behavior: SnackBarBehavior.floating, width: 420, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))));
