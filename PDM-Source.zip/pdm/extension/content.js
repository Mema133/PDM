// "Download this video" button (IDM-style). Cheap by design: no MutationObserver and no polling; work happens
// only on throttled mouse moves and when a media element starts playing. Pages that have no <video> cost
// one empty collection lookup per 200 ms of mouse movement.
(() => {
  if (window.__pdmVideo) return;
  window.__pdmVideo = true;
  const MIN_W = 200, MIN_H = 110;
  let host, root, btn, label, menu, target = null, hideTimer = 0, menuOpen = false, lastMove = 0, resetTimer = 0;

  const CSS = `
    :host { all: initial; }
    .wrap { font: 13px "Segoe UI", system-ui, sans-serif; color: #E6E8EE; }
    button { all: unset; cursor: pointer; display: inline-flex; gap: 8px; align-items: center; padding: 7px 14px; border-radius: 10px;
      background: linear-gradient(135deg, #5B9DFF, #7C8CFF); color: #fff; font-weight: 600; box-shadow: 0 4px 14px rgba(0,0,0,.45); }
    button:hover { filter: brightness(1.12); }
    .menu { margin-top: 6px; min-width: 340px; max-width: min(620px, 92vw); max-height: 60vh; overflow: auto; background: #1C1F26; border: 1px solid #2E333F;
      border-radius: 12px; padding: 6px; box-shadow: 0 10px 30px rgba(0,0,0,.55); }
    .row { display: flex; gap: 10px; padding: 8px 10px; border-radius: 8px; cursor: pointer; align-items: baseline; }
    .row:hover { background: #252932; }
    .row.dim { cursor: default; color: #8E95A5; white-space: normal; }
    .row.dim:hover { background: none; }
    .n { color: #8E95A5; } .t { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; } .m { color: #8FB8FF; white-space: nowrap; }
    .all { font-weight: 600; border-bottom: 1px solid #2E333F; border-radius: 8px 8px 0 0; margin-bottom: 4px; }
  `;

  function ui() {
    if (host) return;
    host = document.createElement("div");
    host.style.cssText = "all:initial;position:fixed;z-index:2147483647;display:none;";
    root = host.attachShadow({ mode: "closed" });
    const sheet = new CSSStyleSheet(); // constructable sheets are not subject to the page's inline-style CSP
    sheet.replaceSync(CSS);
    root.adoptedStyleSheets = [sheet];
    const wrap = document.createElement("div");
    wrap.className = "wrap";
    btn = document.createElement("button");
    label = document.createElement("span");
    btn.append("\u2B07", label);
    menu = document.createElement("div");
    menu.className = "menu";
    menu.hidden = true;
    wrap.append(btn, menu);
    root.append(wrap);
    btn.addEventListener("click", (e) => { e.stopPropagation(); menuOpen ? closeMenu() : openMenu(); });
    host.addEventListener("mouseenter", () => clearTimeout(hideTimer));
    host.addEventListener("mouseleave", () => scheduleHide(900));
    setLabel(false);
  }

  const isAudio = () => target && target.localName === "audio";
  function setLabel(text) { label.textContent = text || (isAudio() ? "Download this audio" : "Download this video"); }

  function place(left, top) {
    const parent = document.fullscreenElement || document.documentElement;
    if (host.parentNode !== parent) parent.append(host);
    host.style.left = Math.max(4, Math.min(left, innerWidth - 200)) + "px";
    host.style.top = Math.max(4, Math.min(top, innerHeight - 40)) + "px";
    host.style.display = "block";
  }

  function show(el, r) {
    if (menuOpen) return;
    ui();
    clearTimeout(hideTimer);
    target = el;
    if (!resetTimer) setLabel(false);
    r ? place(r.left + 8, r.top + 8) : place(innerWidth - 230, 12);
  }

  function scheduleHide(ms) {
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => { if (!menuOpen && host) host.style.display = "none"; }, ms);
  }

  function closeMenu() {
    menuOpen = false;
    if (menu) menu.hidden = true;
    scheduleHide(1200);
  }

  // ---- gathering candidates: the page's media elements plus files the browser saw loading (background.js) ----
  const MIME_LABEL = { "video/mp4": "MP4", "video/webm": "WEBM", "video/x-matroska": "MKV", "video/quicktime": "MOV", "video/x-flv": "FLV", "video/3gpp": "3GP",
    "audio/mpeg": "MP3", "audio/mp3": "MP3", "audio/mp4": "M4A", "audio/x-m4a": "M4A", "audio/aac": "AAC", "audio/ogg": "OGG", "audio/opus": "OPUS",
    "audio/flac": "FLAC", "audio/wav": "WAV", "audio/x-wav": "WAV" };
  const YT_EXT = { "video/mp4": "mp4", "video/webm": "webm", "audio/mp4": "m4a", "audio/webm": "webm" };
  const PAGE_EXT = new Set(["php", "asp", "aspx", "jsp", "cgi", "html", "htm", "do", "action", "ashx"]);
  const extOf = (u) => { try { const m = /\.([a-z0-9]{2,5})$/i.exec(new URL(u).pathname); return m ? m[1].toLowerCase() : ""; } catch { return ""; } };
  // The server's Content-Type beats the URL: "video.php" served as video/mp4 is an MP4.
  function typeLabel(it) {
    if (it.hls) return (it.ext || "ts").toUpperCase();
    const m = MIME_LABEL[(it.mime || "").toLowerCase()];
    if (m) return m;
    const e = extOf(it.url);
    if (e && !PAGE_EXT.has(e)) return e.toUpperCase();
    const sub = (it.mime || "").split("/")[1];
    return sub ? sub.replace(/^x-/, "").toUpperCase() : "MEDIA";
  }
  const hlsTarget = (it) => { if (!it.hls) return it.url; const u = new URL(it.url); u.hash = "pdm-hls"; return u.href; }; // tells the engine it is HLS
  const fmtTime = (s) => (s >= 3600 ? Math.floor(s / 3600) + ":" : "") + String(Math.floor((s % 3600) / 60)).padStart(2, "0") + ":" + String(Math.floor(s % 60)).padStart(2, "0");
  const fmtSize = (b) => (b >= 1073741824 ? (b / 1073741824).toFixed(2) + " GB" : b >= 1048576 ? (b / 1048576).toFixed(1) + " MB" : Math.round(b / 1024) + " KB");

  function collect(sniffed) {
    const map = new Map();
    const put = (url, info) => {
      if (!/^https?:/i.test(url || "")) return; // blob:/data: streams cannot be fetched by PDM
      const o = map.get(url) || { url };
      for (const k in info) if (info[k]) o[k] = info[k];
      map.set(url, o);
    };
    for (const el of document.querySelectorAll("video,audio")) {
      const dims = { h: el.videoHeight, d: isFinite(el.duration) ? el.duration : 0 };
      put(el.currentSrc, dims);
      put(el.src, el.src === el.currentSrc ? dims : {});
      for (const s of el.querySelectorAll("source[src]")) put(s.src, s.src === el.currentSrc ? dims : {});
    }
    for (const s of sniffed) put(s.url, s);
    return [...map.values()].sort((a, b) => (b.h || 0) - (a.h || 0) || (b.size || 0) - (a.size || 0));
  }

  function row(cls, children, onClick) {
    const r = document.createElement("div");
    r.className = "row " + cls;
    for (const [c, text] of children) { const s = document.createElement("span"); s.className = c; s.textContent = text; r.append(s); }
    if (onClick) r.addEventListener("click", (e) => { e.stopPropagation(); onClick(); });
    menu.append(r);
  }

  function render(items) {
    menu.textContent = "";
    if (!items.length) {
      row("dim", [["t", "No downloadable file found yet. Let the video play for a few seconds and try again. Some players stream in a way PDM cannot save (DRM, DASH, encrypted or live HLS)."]]);
      return;
    }
    const title = (document.title || location.hostname).replace(/\s+/g, " ").trim();
    const ok = items.filter((i) => !i.error);
    if (ok.length > 1) row("all", [["t", "Download all"]], () => send(ok));
    items.forEach((it, i) => {
      if (it.error) return row("dim", [["n", i + 1 + "."], ["t", title + " \u2014 " + it.error]]);
      const bits = [typeLabel(it) + " file"]; // title text is untrusted: textContent only
      if (it.h) bits.push(it.h + "p");
      if (it.bw) bits.push(Math.round(it.bw / 1000) + " kbps");
      else if (it.size && it.d) bits.push(Math.round((it.size * 8) / it.d / 1000) + " kbps");
      if (it.only) bits.push(it.only);
      if (it.size) bits.push(fmtSize(it.size));
      else if (it.dur) bits.push(fmtTime(it.dur));
      row("", [["n", i + 1 + "."], ["t", title], ["m", bits.join(", ")]], () => send([it]));
    });
  }

  async function openMenu() {
    menuOpen = true;
    menu.hidden = false;
    menu.textContent = "";
    row("dim", [["t", "Looking for files\u2026"]]);
    let sniffed = [];
    const dom = [];
    for (const el of document.querySelectorAll("video,audio")) for (const u of [el.currentSrc, el.src]) if (/^https?:/i.test(u || "") && !dom.includes(u)) dom.push(u);
    try {
      sniffed = ((await chrome.runtime.sendMessage({ type: "media-list", dom })) || {}).list || [];
    } catch {} // extension was reloaded: fall back to what the page itself exposes
    render(collect(sniffed));
  }

  async function send(items) {
    const urls = items.map(hlsTarget);
    // YouTube streams are all called "videoplayback": name the file after the page instead.
    const one = items.length === 1 && items[0].yt ? items[0] : null;
    const name = one && YT_EXT[one.mime]
      ? (document.title || "video").replace(/ - YouTube$/, "").replace(/[\\/:*?"<>|\s]+/g, " ").trim().slice(0, 120) + (one.only === "audio only" ? " (audio)" : "") + "." + YT_EXT[one.mime]
      : undefined;
    closeMenu();
    setLabel("Sending\u2026");
    let r;
    try {
      r = await chrome.runtime.sendMessage({ type: "send", urls, referer: location.href, name });
    } catch (e) {
      r = { ok: false, error: String(e) };
    }
    setLabel(r && r.ok ? "Sent to PDM \u2714" : "PDM: " + ((r && r.error) || "failed"));
    clearTimeout(resetTimer);
    resetTimer = setTimeout(() => { resetTimer = 0; setLabel(false); }, 2500);
  }

  // ---- when to show the button ----
  addEventListener("mousemove", (e) => {
    const now = performance.now();
    if (now - lastMove < 200) return;
    lastMove = now;
    if (menuOpen || (host && e.composedPath().includes(host))) return;
    for (const v of document.getElementsByTagName("video")) { // live collection: empty on most pages
      const r = v.getBoundingClientRect();
      if (r.width >= MIN_W && r.height >= MIN_H && e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom) {
        return show(v, r);
      }
    }
    for (const a of document.getElementsByTagName("audio")) { // music players hide their <audio>: corner button while it plays
      if (!a.paused && !a.ended) return show(a, null);
    }
    if (host && host.style.display !== "none") scheduleHide(900);
  }, { passive: true, capture: true });

  // "play" does not bubble, so listen in the capture phase. Audio and hidden players get a corner button.
  document.addEventListener("play", (e) => {
    const el = e.target;
    if (!el || (el.localName !== "video" && el.localName !== "audio") || innerWidth < 160 || innerHeight < 60) return;
    const r = el.getBoundingClientRect();
    show(el, el.localName === "video" && r.width >= MIN_W && r.height >= MIN_H ? r : null);
    scheduleHide(4000);
  }, true);

  document.addEventListener("click", (e) => { if (menuOpen && host && !e.composedPath().includes(host)) closeMenu(); }, true);
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && menuOpen) closeMenu(); }, true);
})();
