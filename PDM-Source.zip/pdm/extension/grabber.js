const $ = (id) => document.getElementById(id);
let links = [];
let page = "";

const nameOf = (u) => { try { return decodeURIComponent(new URL(u).pathname.split("/").filter(Boolean).pop() || new URL(u).hostname); } catch { return u; } };
const hasPath = (u) => { try { return new URL(u).pathname.split("/").some(Boolean); } catch { return false; } };
const extOf = (n) => (n.includes(".") ? n.split(".").pop().slice(0, 8).toLowerCase() : "");

// What the server says about each file. This page has the extension's origin, so with host permissions it can read
// headers cross-origin (a content script could not). Nothing is guessed: no answer shows as "Unknown", a failure as its reason.
const MIME_NAME = { "application/zip": "ZIP archive", "application/x-zip-compressed": "ZIP archive", "application/pdf": "PDF document", "application/x-7z-compressed": "7-Zip archive",
  "application/vnd.rar": "RAR archive", "application/x-rar-compressed": "RAR archive", "application/gzip": "GZip archive", "application/json": "JSON", "application/javascript": "JavaScript",
  "text/javascript": "JavaScript", "text/css": "Stylesheet", "text/html": "Web page", "application/x-msdownload": "Windows program", "application/vnd.microsoft.portable-executable": "Windows program",
  "application/octet-stream": "Binary file", "font/woff2": "Font", "font/woff": "Font", "application/vnd.apple.mpegurl": "HLS playlist", "application/x-mpegurl": "HLS playlist", "application/dash+xml": "DASH manifest" };
const typeName = (m) => MIME_NAME[m] || (/^image\//.test(m) ? "Image" : /^video\//.test(m) ? "Video" : /^audio\//.test(m) ? "Audio" : /^font\//.test(m) ? "Font" : /^text\//.test(m) ? "Text" : m);
const fmtSize = (b) => (b >= 1073741824 ? (b / 1073741824).toFixed(2) + " GB" : b >= 1048576 ? (b / 1048576).toFixed(1) + " MB" : b >= 1024 ? Math.round(b / 1024) + " KB" : b + " B");
const EXT_OF_MIME = { "video/mp4": "mp4", "video/webm": "webm", "audio/mpeg": "mp3", "audio/mp4": "m4a", "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp", "image/gif": "gif", "application/pdf": "pdf", "application/zip": "zip" };

function dispName(h) { // Content-Disposition filename*= / filename=
  const star = /filename\*\s*=\s*[^']*'[^']*'([^;]+)/i.exec(h || "");
  if (star) try { return decodeURIComponent(star[1].trim()); } catch {}
  const m = /filename\s*=\s*"?([^";]+)"?/i.exec(h || "");
  return m ? m[1].trim() : "";
}

async function probe(l) {
  const ask = async (init) => {
    const r = await fetch(l.url, { credentials: "include", cache: "no-store", signal: AbortSignal.timeout(10000), ...init });
    const stop = () => r.body && r.body.cancel().catch(() => {});
    const out = { status: r.status, mime: (r.headers.get("content-type") || "").split(";")[0].trim().toLowerCase(), disp: r.headers.get("content-disposition") || "", len: r.headers.get("content-length"), range: r.headers.get("content-range") };
    stop(); // headers are enough: never read the body
    return out;
  };
  try {
    let o = await ask({ method: "HEAD" });
    if (o.status >= 400 || (!o.len && !o.mime)) o = await ask({ headers: { Range: "bytes=0-0" } }); // some servers refuse HEAD
    if (o.status >= 400) return { error: "HTTP " + o.status };
    const total = /\/(\d+)\s*$/.exec(o.range || "");
    const size = total ? Number(total[1]) : o.status === 206 ? 0 : Number(o.len) || 0;
    return { mime: o.mime, size, file: dispName(o.disp) };
  } catch (e) {
    return { error: e && e.name === "TimeoutError" ? "timed out" : "unreachable" };
  }
}

let active = 0, failed = 0, done = 0;
const waiting = [];
function pump() {
  while (active < 6 && waiting.length) {
    const l = waiting.shift();
    active++;
    probe(l).then((info) => { l.info = info; if (info.error) failed++; done++; fill(l); }).finally(() => { active--; pump(); showProbe(); });
  }
}
function want(l) { if (!l.info && !l.queued) { l.queued = true; waiting.push(l); pump(); } }
function showProbe() { $("probe").textContent = active || waiting.length ? `reading file info… ${done}` : failed ? `${failed} file(s) gave no info (see the Size column)` : ""; }

// Fills the Ext / Type / Size cells of a row from l.info (or says why there is nothing).
function fill(l) {
  const tr = rowOf.get(l.url);
  if (!tr) return;
  const i = l.info, [, , ext, type, size] = tr.children;
  const set = (td, text, cls, tip) => { td.textContent = text; td.className = cls || ""; td.title = tip || text; };
  if (!i) return [type, size].forEach((td) => set(td, "…", "unk", "reading headers"));
  if (i.error) {
    set(ext, hasPath(l.url) ? extOf(nameOf(l.url)) || "Unknown" : "Unknown", "unk");
    set(type, "Unknown", "err", i.error);
    return set(size, "Unknown", "err", "Could not read the size: " + i.error);
  }
  const name = i.file || nameOf(l.url);
  set(ext, extOf(name) || EXT_OF_MIME[i.mime] || "Unknown", extOf(name) || EXT_OF_MIME[i.mime] ? "" : "unk");
  set(type, i.mime ? typeName(i.mime) : "Unknown", i.mime ? "" : "unk", i.mime || "The server sent no Content-Type");
  set(size, i.size ? fmtSize(i.size) : "Unknown", i.size ? "" : "unk", i.size ? i.size + " bytes" : "The server did not report a size");
  if (i.file) tr.children[1].textContent = i.file;
}

const rowOf = new Map();
const seen = new IntersectionObserver((es) => es.forEach((e) => {
  if (!e.isIntersecting) return;
  seen.unobserve(e.target);
  const l = links.find((x) => x.url === e.target.dataset.url);
  if (l) want(l);
}), { rootMargin: "200px" });

const MAX_ROWS = 3000; // keep the window responsive on huge pages; use the filter to narrow down
const PAGE_EXT = new Set(["html", "htm", "php", "asp", "aspx", "jsp", ""]);

function render() {
  rowOf.clear();
  seen.disconnect();
  const q = $("filter").value.trim().toLowerCase().replace(/^\./, "");
  const hide = $("nohtml").checked;
  const frag = document.createDocumentFragment();
  let shown = 0;
  for (const l of links) {
    const name = nameOf(l.url), ext = hasPath(l.url) ? extOf(name) : ""; // "example.com" is a host, not a .com file
    if (hide && PAGE_EXT.has(ext)) continue;
    if (q && !(name + " " + l.url + " " + l.text).toLowerCase().includes(q)) continue;
    if (shown++ >= MAX_ROWS) break;
    const tr = document.createElement("tr");
    tr.dataset.url = l.url;
    // textContent only: link text and URLs come from the page and are untrusted.
    for (const [i, v] of [[0, null], [1, name], [2, ext], [3, ""], [4, ""], [5, l.url], [6, l.text]]) {
      const td = document.createElement("td");
      if (i === 0) { const c = document.createElement("input"); c.type = "checkbox"; c.checked = !!l.on; c.onchange = () => { l.on = c.checked; count(); }; td.append(c); }
      else { td.textContent = v; td.title = v; }
      tr.append(td);
    }
    frag.append(tr);
    rowOf.set(l.url, tr);
    l.info ? fill(l) : (fill(l), seen.observe(tr)); // asked for only when the row scrolls into view
  }
  $("rows").replaceChildren(frag);
  count();
}

function count() {
  const n = links.filter((l) => l.on).length;
  $("count").textContent = `${n} selected of ${links.length}`;
  $("ok").disabled = n === 0;
}

let timer;
$("filter").oninput = () => { clearTimeout(timer); timer = setTimeout(render, 150); };
$("nohtml").onchange = render;
$("all").onchange = (e) => {
  const shown = new Set([...$("rows").children].map((tr) => tr.dataset.url));
  links.forEach((l) => { if (shown.has(l.url)) l.on = e.target.checked; });
  render();
};
$("cancel").onclick = () => window.close();
$("ok").onclick = async () => {
  $("ok").disabled = true;
  const r = await chrome.runtime.sendMessage({ type: "send", referer: page, urls: links.filter((l) => l.on).map((l) => l.url) });
  if (r && r.ok) window.close();
  else { $("msg").textContent = "PDM: " + ((r && r.error) || "failed"); $("ok").disabled = false; }
};

chrome.storage.session.get("grab").then(({ grab }) => {
  page = (grab && grab.page) || "";
  links = ((grab && grab.links) || []).map((l) => ({ ...l, on: false }));
  render();
  if (!links.length) $("msg").textContent = "No links found on this page.";
});
