# Pervert Download Manager (PDM)

Native Windows download manager: Flutter (Dart) UI + Rust engine, Chrome/Edge/Brave extension via Native Messaging. Proxy: none / system / manual HTTP or SOCKS5.

**State: nothing here has been compiled or run by the author** (the sandbox has no Rust, Flutter or Windows). Read `docs/VERIFICATION_REPORT.md`; build with `scripts\build.ps1` and report errors.

Layout:

- `crates/pdm-proto`: IPC framing and envelope validation (no I/O). The wire protocol is unchanged from XDM.
- `crates/pdm-engine`: `pdmd` daemon: sessions, named-pipe server, segmented downloads, queues.
- `crates/pdm-core`: range planner/validator and filename sanitiser.
- `crates/pdm-host`: `pdm-host.exe`, the Native Messaging bridge (browser stdin/stdout <-> pdmd pipe). `pdm-host.exe --install` registers it for Chrome, Edge and Brave (HKCU).
- `ui_flutter/`: Flutter Windows UI (`pdm.exe`): Downloads, Queues and scheduler, Settings (themes, connections, proxy), six themes.
- `extension/`: MV3 extension: "Download with PDM", "Download all links with PDM" (link grabber window), IDM-style "Download this video" button over page videos/audio (direct files and unencrypted HLS), optional download capture.
- `proto/golden/`, `tools/`, `scripts/`, `docs/`: as before.

Data lives in `%APPDATA%\PDM`; the pipe is `\\.\pipe\pdm-v1-<USERNAME>` (`PDM_PIPE_NAME` overrides).

Browser downloads carry the browser's cookies and referer, so logged-in and token-protected files work.

YouTube and other page-URL videos use yt-dlp + ffmpeg + deno. They are **not** part of the build: when you open such a download PDM offers a "Download tools" button that fetches them from their official release pages into `%APPDATA%\PDM\tools` (yt-dlp then updates itself at start). Spotify and other DRM streams cannot be saved.

No Electron, Tauri, CEF, WebEngine or WebView in the app: enforced by `tools/check_no_webengine.py`. (The extension runs inside the user's own browser.)
