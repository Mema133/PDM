//! Conservative filename sanitiser for Windows destinations.

const MAX_LEN: usize = 200;

fn is_reserved(stem: &str) -> bool {
    let u = stem.to_ascii_uppercase();
    matches!(u.as_str(), "CON" | "PRN" | "AUX" | "NUL")
        || (u.len() == 4
            && (u.starts_with("COM") || u.starts_with("LPT"))
            && matches!(u.as_bytes()[3], b'1'..=b'9'))
}

/// Never returns an empty string, a path separator, a reserved device name,
/// or a name ending in dot/space.
pub fn sanitize_filename(raw: &str) -> String {
    let last = raw.rsplit(|c| c == '/' || c == '\\').next().unwrap_or("");
    let mut s: String = last
        .chars()
        .filter(|c| !c.is_control())
        .map(|c| if "<>:\"/\\|?*".contains(c) { '_' } else { c })
        .collect();
    s = s.trim_start().trim_end_matches(|c| c == '.' || c == ' ').to_string();
    if s.chars().count() > MAX_LEN {
        s = s.chars().take(MAX_LEN).collect::<String>();
        s = s.trim_end_matches(|c| c == '.' || c == ' ').to_string();
    }
    if s.is_empty() || s.chars().all(|c| c == '.') {
        return "download".to_string();
    }
    let stem = s.split('.').next().unwrap_or("");
    if is_reserved(stem) {
        s.insert(0, '_');
    }
    s
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn strips_paths_and_traversal() {
        assert_eq!(sanitize_filename("../../etc/passwd"), "passwd");
        assert_eq!(sanitize_filename(r"..\..\windows\system32\evil.dll"), "evil.dll");
        assert_eq!(sanitize_filename("/"), "download");
        assert_eq!(sanitize_filename(".."), "download");
    }

    #[test]
    fn replaces_illegal_chars_and_trims() {
        assert_eq!(sanitize_filename("a<b>c:d\"e|f?g*h.txt"), "a_b_c_d_e_f_g_h.txt");
        assert_eq!(sanitize_filename("name. . "), "name");
        assert_eq!(sanitize_filename("  lead.txt"), "lead.txt");
        assert_eq!(sanitize_filename("tab\there\n.txt"), "tabhere.txt");
    }

    #[test]
    fn reserved_names() {
        assert_eq!(sanitize_filename("CON"), "_CON");
        assert_eq!(sanitize_filename("nul.txt"), "_nul.txt");
        assert_eq!(sanitize_filename("com1.tar.gz"), "_com1.tar.gz");
        assert_eq!(sanitize_filename("LPT9"), "_LPT9");
        assert_eq!(sanitize_filename("COM0"), "COM0");
        assert_eq!(sanitize_filename("console.txt"), "console.txt");
    }

    #[test]
    fn empty_and_long() {
        assert_eq!(sanitize_filename(""), "download");
        assert_eq!(sanitize_filename("???"), "___");
        let long = "a".repeat(500);
        assert_eq!(sanitize_filename(&long).len(), 200);
    }
}

/// Extension for a media Content-Type, or None when the type says nothing useful.
fn media_ext(content_type: &str) -> Option<&'static str> {
    let t = content_type.split(';').next().unwrap_or("").trim().to_ascii_lowercase();
    Some(match t.as_str() {
        "video/mp4" => "mp4",
        "video/webm" => "webm",
        "video/x-matroska" => "mkv",
        "video/quicktime" => "mov",
        "video/mp2t" => "ts",
        "video/x-flv" => "flv",
        "video/3gpp" => "3gp",
        "audio/mpeg" | "audio/mp3" => "mp3",
        "audio/mp4" | "audio/x-m4a" => "m4a",
        "audio/aac" => "aac",
        "audio/ogg" => "ogg",
        "audio/opus" => "opus",
        "audio/flac" => "flac",
        "audio/wav" | "audio/x-wav" => "wav",
        _ => return None,
    })
}

/// `video.php` served as video/mp4 should be saved as `video.mp4`. Only names that have no extension or a
/// dynamic-page extension are changed; a real extension (even a different one) is left alone.
pub fn ensure_media_ext(name: &str, content_type: &str) -> String {
    let Some(want) = media_ext(content_type) else { return name.to_string() };
    let ext = name.rsplit_once('.').map(|(_, e)| e.to_ascii_lowercase());
    match ext.as_deref() {
        Some(e) if e == want => name.to_string(),
        Some("php" | "asp" | "aspx" | "jsp" | "cgi" | "html" | "htm" | "do" | "action" | "ashx") => {
            format!("{}.{want}", name.rsplit_once('.').map(|(s, _)| s).unwrap_or(name))
        }
        None => format!("{name}.{want}"),
        Some(_) => name.to_string(),
    }
}

#[cfg(test)]
mod ext_tests {
    use super::ensure_media_ext;

    #[test]
    fn dynamic_page_names_get_the_media_extension() {
        assert_eq!(ensure_media_ext("video.php", "video/mp4"), "video.mp4");
        assert_eq!(ensure_media_ext("get", "audio/mpeg; charset=x"), "get.mp3");
        assert_eq!(ensure_media_ext("clip.mp4", "video/mp4"), "clip.mp4");
        assert_eq!(ensure_media_ext("clip.bin", "video/mp4"), "clip.bin"); // real extension kept
        assert_eq!(ensure_media_ext("a.php", "text/html"), "a.php");
        assert_eq!(ensure_media_ext("a.php", "application/octet-stream"), "a.php");
    }
}
