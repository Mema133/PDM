//! Pure, I/O-free building blocks for the download engine (groundwork for
//! Milestones 2-3): range planning/validation and filename sanitising.
pub mod filename;
pub mod ranges;
