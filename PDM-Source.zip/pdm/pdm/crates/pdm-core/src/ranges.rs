//! Byte-range planning and response validation for segmented downloads.
//! All ranges are inclusive (HTTP semantics): `start..=end`.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ByteRange {
    pub start: u64,
    pub end: u64,
}

impl ByteRange {
    pub fn len(&self) -> u64 {
        self.end - self.start + 1
    }
    pub fn is_empty(&self) -> bool {
        false
    }
}

/// Split `total` bytes into at most `max_conns` contiguous, non-overlapping
/// segments, each at least `min_segment` bytes (except when total is smaller).
pub fn plan_segments(total: u64, max_conns: u32, min_segment: u64) -> Vec<ByteRange> {
    if total == 0 {
        return Vec::new();
    }
    let min_segment = min_segment.max(1);
    let by_size = (total / min_segment).max(1);
    let n = u64::from(max_conns.max(1)).min(by_size);
    let base = total / n;
    let rem = total % n;
    let mut out = Vec::with_capacity(n as usize);
    let mut start = 0u64;
    for i in 0..n {
        let len = base + u64::from(i < rem);
        out.push(ByteRange { start, end: start + len - 1 });
        start += len;
    }
    out
}

/// Work stealing: split the *unfetched* remainder of a slow worker's range in
/// half. Returns (keep, give_away); None if it is too small to split.
pub fn split_for_steal(remaining: ByteRange, min_segment: u64) -> Option<(ByteRange, ByteRange)> {
    let len = remaining.len();
    if len < min_segment.max(1).saturating_mul(2) {
        return None;
    }
    let mid = remaining.start + len / 2;
    Some((
        ByteRange { start: remaining.start, end: mid - 1 },
        ByteRange { start: mid, end: remaining.end },
    ))
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CoverError {
    Gap { at: u64 },
    Overlap { at: u64 },
    Invalid,
    BeyondTotal,
}

/// Verify that `ranges` cover `[0, total)` exactly once (any input order).
pub fn verify_exact_cover(total: u64, ranges: &[ByteRange]) -> Result<(), CoverError> {
    let mut sorted = ranges.to_vec();
    sorted.sort_by_key(|r| (r.start, r.end));
    let mut expected = 0u64;
    for r in sorted {
        if r.end < r.start {
            return Err(CoverError::Invalid);
        }
        if r.start > expected {
            return Err(CoverError::Gap { at: expected });
        }
        if r.start < expected {
            return Err(CoverError::Overlap { at: r.start });
        }
        expected = r.end.checked_add(1).ok_or(CoverError::BeyondTotal)?;
        if expected > total {
            return Err(CoverError::BeyondTotal);
        }
    }
    if expected < total {
        return Err(CoverError::Gap { at: expected });
    }
    Ok(())
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ContentRange {
    pub start: u64,
    pub end: u64,
    pub total: Option<u64>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RangeError {
    Malformed,
    WrongUnit,
    Mismatch,
    TotalMismatch,
}

fn digits(s: &str) -> Option<u64> {
    if s.is_empty() || !s.bytes().all(|b| b.is_ascii_digit()) {
        return None;
    }
    s.parse().ok()
}

/// Parse `bytes START-END/TOTAL` or `bytes START-END/*`.
pub fn parse_content_range(h: &str) -> Result<ContentRange, RangeError> {
    let (unit, rest) = h.trim().split_once(' ').ok_or(RangeError::Malformed)?;
    if !unit.eq_ignore_ascii_case("bytes") {
        return Err(RangeError::WrongUnit);
    }
    let (range, total) = rest.trim().split_once('/').ok_or(RangeError::Malformed)?;
    let (s, e) = range.split_once('-').ok_or(RangeError::Malformed)?;
    let start = digits(s).ok_or(RangeError::Malformed)?;
    let end = digits(e).ok_or(RangeError::Malformed)?;
    if end < start {
        return Err(RangeError::Malformed);
    }
    let total = if total == "*" {
        None
    } else {
        let t = digits(total).ok_or(RangeError::Malformed)?;
        if t <= end {
            return Err(RangeError::Malformed);
        }
        Some(t)
    };
    Ok(ContentRange { start, end, total })
}

/// A `206` response is acceptable only if its Content-Range matches exactly
/// the range requested and agrees with the size already known.
pub fn validate_content_range(
    requested: ByteRange,
    header: &str,
    known_total: Option<u64>,
) -> Result<ContentRange, RangeError> {
    let cr = parse_content_range(header)?;
    if cr.start != requested.start || cr.end != requested.end {
        return Err(RangeError::Mismatch);
    }
    if let (Some(a), Some(b)) = (cr.total, known_total) {
        if a != b {
            return Err(RangeError::TotalMismatch);
        }
    }
    Ok(cr)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn r(s: u64, e: u64) -> ByteRange {
        ByteRange { start: s, end: e }
    }

    #[test]
    fn plan_covers_exactly_for_many_sizes() {
        for total in [1u64, 2, 7, 8, 9, 1000, 1_048_576, 10_000_019] {
            for conns in [1u32, 2, 4, 8, 16, 32] {
                for min in [1u64, 1000, 1 << 20] {
                    let p = plan_segments(total, conns, min);
                    assert!(p.len() as u32 <= conns.max(1));
                    verify_exact_cover(total, &p).unwrap_or_else(|e| panic!("{total} {conns} {min}: {e:?}"));
                }
            }
        }
    }

    #[test]
    fn plan_respects_minimum_size() {
        let p = plan_segments(10 << 20, 8, 4 << 20);
        assert_eq!(p.len(), 2);
        assert!(p.iter().all(|s| s.len() >= 4 << 20));
        assert_eq!(plan_segments(100, 8, 1 << 20).len(), 1);
        assert!(plan_segments(0, 8, 1).is_empty());
    }

    #[test]
    fn steal_split_is_exact() {
        let (a, b) = split_for_steal(r(100, 299), 50).unwrap();
        assert_eq!(a, r(100, 199));
        assert_eq!(b, r(200, 299));
        assert!(split_for_steal(r(0, 98), 50).is_none());
        assert!(split_for_steal(r(0, 99), 50).is_some());
    }

    #[test]
    fn cover_detects_problems() {
        assert_eq!(verify_exact_cover(10, &[r(0, 4), r(6, 9)]), Err(CoverError::Gap { at: 5 }));
        assert_eq!(verify_exact_cover(10, &[r(0, 5), r(5, 9)]), Err(CoverError::Overlap { at: 5 }));
        assert_eq!(verify_exact_cover(10, &[r(0, 4)]), Err(CoverError::Gap { at: 5 }));
        assert_eq!(verify_exact_cover(10, &[r(0, 10)]), Err(CoverError::BeyondTotal));
        assert_eq!(verify_exact_cover(10, &[r(1, 9)]), Err(CoverError::Gap { at: 0 }));
        assert_eq!(verify_exact_cover(10, &[r(5, 9), r(0, 4)]), Ok(()));
        assert_eq!(verify_exact_cover(0, &[]), Ok(()));
        assert_eq!(verify_exact_cover(10, &[r(5, 3)]), Err(CoverError::Invalid));
        assert_eq!(verify_exact_cover(u64::MAX, &[r(0, u64::MAX)]), Err(CoverError::BeyondTotal));
    }

    #[test]
    fn content_range_parsing() {
        assert_eq!(parse_content_range("bytes 0-99/1000"), Ok(ContentRange { start: 0, end: 99, total: Some(1000) }));
        assert_eq!(parse_content_range("Bytes 5-5/*"), Ok(ContentRange { start: 5, end: 5, total: None }));
        for bad in ["", "bytes", "bytes 0-99", "bytes 99-0/1000", "bytes 0-99/50", "bytes 0-99/99",
                    "bytes -1-5/10", "bytes +1-5/10", "bytes a-b/c", "bytes 0-99/1000x", "bytes  /", "bytes 0--5/10"] {
            assert!(parse_content_range(bad).is_err(), "should reject {bad:?}");
        }
        assert_eq!(parse_content_range("items 0-1/5"), Err(RangeError::WrongUnit));
        assert_eq!(parse_content_range("bytes 18446744073709551616-1/2"), Err(RangeError::Malformed));
    }

    #[test]
    fn content_range_must_match_request() {
        let req = r(100, 199);
        assert!(validate_content_range(req, "bytes 100-199/1000", Some(1000)).is_ok());
        assert!(validate_content_range(req, "bytes 100-199/*", Some(1000)).is_ok());
        assert_eq!(validate_content_range(req, "bytes 0-99/1000", None), Err(RangeError::Mismatch));
        assert_eq!(validate_content_range(req, "bytes 100-150/1000", None), Err(RangeError::Mismatch));
        assert_eq!(validate_content_range(req, "bytes 100-199/2000", Some(1000)), Err(RangeError::TotalMismatch));
    }
}
