//! HTTP/HTTPS download engine: probing, single-stream fallback, genuine
//! concurrent HTTP Range downloads, retries, pause/cancel, integrity checks
//! and restart recovery. Uses the pdm-core planner/validator.
use crate::ratelimit::RateLimiter;
use reqwest::header::{
    HeaderMap, CONTENT_DISPOSITION, CONTENT_TYPE, CONTENT_LENGTH, CONTENT_RANGE, ETAG, IF_RANGE, LAST_MODIFIED, RANGE, RETRY_AFTER,
};
use reqwest::Client;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::fmt;
use std::fs::{self, File, OpenOptions};
use std::io::Read;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicU32, AtomicU64, Ordering};
use std::sync::{Arc, Mutex};
use std::time::{Duration, SystemTime, UNIX_EPOCH};
use tokio::sync::watch;
use tokio::task::JoinSet;
use pdm_core::filename::{ensure_media_ext, sanitize_filename};
use pdm_core::ranges::{plan_segments, validate_content_range, verify_exact_cover, ByteRange};

// ---------- public types ----------

#[derive(Clone, Debug)]
pub struct EngineConfig {
    pub max_conns: u32,
    pub min_segment: u64,
    pub max_retries: u32,
    pub backoff_base_ms: u64,
    pub backoff_max_ms: u64,
    pub connect_timeout: Duration,
    pub request_timeout: Duration,
    pub idle_timeout: Duration,
    pub state_save_interval: Duration,
    pub use_system_proxy: bool,
    pub user_agent: String,
    /// Restart downloads that were Running/Queued when the engine last stopped. Off in pdmd: nothing may use the network until the user asks.
    pub resume_on_start: bool,
}

impl Default for EngineConfig {
    fn default() -> Self {
        EngineConfig {
            max_conns: 4,
            min_segment: 1 << 20,
            max_retries: 5,
            backoff_base_ms: 500,
            backoff_max_ms: 30_000,
            connect_timeout: Duration::from_secs(15),
            request_timeout: Duration::from_secs(30),
            idle_timeout: Duration::from_secs(30),
            state_save_interval: Duration::from_secs(1),
            use_system_proxy: true,
            user_agent: format!("PDM/{}", env!("CARGO_PKG_VERSION")),
            resume_on_start: true,
        }
    }
}

/// Which proxy a download uses. `Default` keeps reqwest's behaviour (system proxy unless the config disables it).
#[derive(Clone, Debug, Default, PartialEq)]
pub enum ProxyChoice {
    #[default]
    Default,
    None,
    Url(String),
}

#[derive(Clone)]
pub struct Job {
    pub url: String,
    pub dest_dir: PathBuf,
    pub filename: Option<String>,
    pub expected_sha256: Option<String>,
    pub max_conns: Option<u32>,
    pub limiters: Vec<Arc<RateLimiter>>,
    pub referer: Option<String>,
    /// Sent as the Cookie header (the browser's session for this URL); validated when the download was added.
    pub cookie: Option<String>,
    pub proxy: ProxyChoice,
}

impl Job {
    pub fn new(url: impl Into<String>, dest_dir: impl Into<PathBuf>) -> Self {
        Job { url: url.into(), dest_dir: dest_dir.into(), filename: None, expected_sha256: None, max_conns: None, limiters: vec![], referer: None, cookie: None, proxy: ProxyChoice::Default }
    }
}

#[derive(Default)]
pub struct Progress {
    pub downloaded: AtomicU64,
    pub total: AtomicU64, // 0 = unknown
    pub conns: AtomicU32,
    pub retries: AtomicU32,
    pub segmented: AtomicBool,
    pub filename: Mutex<Option<String>>,
    /// Segment layout and live per-segment byte counters (segmented downloads only).
    pub seg_ranges: Mutex<Vec<(u64, u64)>>,
    pub seg_done: Mutex<Option<Arc<Vec<AtomicU64>>>>,
}

impl Progress {
    pub fn new() -> Arc<Progress> {
        Arc::new(Progress::default())
    }
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Signal {
    Run,
    Pause,
    Cancel,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Outcome {
    Completed { path: PathBuf, sha256: String, segmented: bool },
    Paused,
    Cancelled,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ErrKind {
    Http,
    Network,
    Timeout,
    BadResponse,
    ResourceChanged,
    RangeIgnored,
    Integrity,
    Io,
}

#[derive(Debug, Clone)]
pub struct DlError {
    pub kind: ErrKind,
    pub status: Option<u16>,
    pub msg: String,
    pub retriable: bool,
    pub retry_after: Option<Duration>,
}

impl DlError {
    pub(crate) fn new(kind: ErrKind, msg: impl Into<String>, retriable: bool) -> Self {
        DlError { kind, status: None, msg: msg.into(), retriable, retry_after: None }
    }
}

impl fmt::Display for DlError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{:?}: {}", self.kind, self.msg)
    }
}
impl std::error::Error for DlError {}

// ---------- persisted partial state ----------

#[derive(Serialize, Deserialize, Clone, Debug, PartialEq, Eq)]
pub struct SegState {
    pub start: u64,
    pub end: u64,
    /// Bytes completed from `start` (contiguous).
    pub done: u64,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct PartState {
    pub url: String,
    pub total: u64,
    pub etag: Option<String>,
    pub last_modified: Option<String>,
    pub filename: String,
    pub segments: Vec<SegState>,
}

impl PartState {
    fn valid(&self, total: u64) -> bool {
        if self.segments.is_empty() {
            return false;
        }
        let ranges: Vec<ByteRange> = self.segments.iter().map(|s| ByteRange { start: s.start, end: s.end }).collect();
        verify_exact_cover(total, &ranges).is_ok()
            && self.segments.iter().all(|s| s.end >= s.start && s.done <= s.end - s.start + 1)
    }
}

pub fn part_path(dir: &Path, name: &str) -> PathBuf {
    dir.join(format!("{name}.pdmpart"))
}
pub fn state_path(dir: &Path, name: &str) -> PathBuf {
    dir.join(format!("{name}.pdmpart.json"))
}
pub fn cleanup_partials(dir: &Path, name: &str) {
    let _ = fs::remove_file(part_path(dir, name));
    let _ = fs::remove_file(state_path(dir, name));
}
fn load_state(p: &Path) -> Option<PartState> {
    serde_json::from_slice(&fs::read(p).ok()?).ok()
}

// ---------- helpers ----------

pub fn hex(b: &[u8]) -> String {
    b.iter().map(|x| format!("{x:02x}")).collect()
}
pub fn sha256_hex(data: &[u8]) -> String {
    hex(&Sha256::digest(data))
}

pub(crate) fn io_err(e: std::io::Error) -> DlError {
    DlError::new(ErrKind::Io, e.to_string(), false)
}
pub(crate) fn net_err(e: reqwest::Error) -> DlError {
    let kind = if e.is_timeout() { ErrKind::Timeout } else { ErrKind::Network };
    DlError::new(kind, e.to_string(), !(e.is_builder() || e.is_redirect()))
}
pub(crate) fn timeout_err(what: &str) -> DlError {
    DlError::new(ErrKind::Timeout, format!("timed out: {what}"), true)
}
pub(crate) fn bad(msg: impl Into<String>) -> DlError {
    DlError::new(ErrKind::BadResponse, msg, false)
}

pub(crate) fn status_error(status: u16, headers: &HeaderMap) -> DlError {
    let retry_after = headers
        .get(RETRY_AFTER)
        .and_then(|v| v.to_str().ok())
        .and_then(|s| s.trim().parse::<u64>().ok())
        .map(Duration::from_secs);
    DlError {
        kind: ErrKind::Http,
        status: Some(status),
        msg: format!("HTTP {status}"),
        retriable: matches!(status, 408 | 429 | 500 | 502 | 503 | 504),
        retry_after,
    }
}

pub(crate) fn backoff(cfg: &EngineConfig, attempt: u32, retry_after: Option<Duration>) -> Duration {
    if let Some(ra) = retry_after {
        return ra.min(Duration::from_secs(300));
    }
    let shift = attempt.saturating_sub(1).min(16);
    let ms = cfg.backoff_base_ms.saturating_mul(1u64 << shift).min(cfg.backoff_max_ms);
    let nanos = SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.subsec_nanos() as u64).unwrap_or(0);
    Duration::from_millis(ms + nanos % (ms / 4 + 1))
}

/// Current control signal; a dropped sender counts as Cancel.
pub(crate) fn sig(ctrl: &watch::Receiver<Signal>) -> Signal {
    if ctrl.has_changed().is_err() {
        return Signal::Cancel;
    }
    *ctrl.borrow()
}

pub(crate) async fn sleep_or_signal(d: Duration, ctrl: &mut watch::Receiver<Signal>) {
    tokio::select! {
        _ = tokio::time::sleep(d) => {}
        _ = ctrl.changed() => {}
    }
}

pub(crate) fn stop_outcome(ctrl: &watch::Receiver<Signal>) -> Outcome {
    if sig(ctrl) == Signal::Cancel { Outcome::Cancelled } else { Outcome::Paused }
}

struct ConnGuard(Arc<Progress>);
impl ConnGuard {
    fn new(p: &Arc<Progress>) -> Self {
        p.conns.fetch_add(1, Ordering::SeqCst);
        ConnGuard(p.clone())
    }
}
impl Drop for ConnGuard {
    fn drop(&mut self) {
        self.0.conns.fetch_sub(1, Ordering::SeqCst);
    }
}

#[cfg(unix)]
fn write_all_at(f: &File, buf: &[u8], off: u64) -> std::io::Result<()> {
    use std::os::unix::fs::FileExt;
    f.write_all_at(buf, off)
}
#[cfg(windows)]
fn write_all_at(f: &File, mut buf: &[u8], mut off: u64) -> std::io::Result<()> {
    use std::os::windows::fs::FileExt;
    while !buf.is_empty() {
        let n = f.seek_write(buf, off)?;
        if n == 0 {
            return Err(std::io::Error::new(std::io::ErrorKind::WriteZero, "seek_write wrote 0 bytes"));
        }
        buf = &buf[n..];
        off += n as u64;
    }
    Ok(())
}

async fn write_at(file: &Arc<File>, off: u64, data: Vec<u8>) -> Result<(), DlError> {
    let f = file.clone();
    tokio::task::spawn_blocking(move || write_all_at(&f, &data, off))
        .await
        .map_err(|e| DlError::new(ErrKind::Io, format!("write task failed: {e}"), false))?
        .map_err(io_err)
}

pub(crate) fn percent_decode(s: &str) -> String {
    let b = s.as_bytes();
    let mut out = Vec::with_capacity(b.len());
    let mut i = 0;
    while i < b.len() {
        if b[i] == b'%' && i + 2 < b.len() {
            let v = std::str::from_utf8(&b[i + 1..i + 3]).ok().and_then(|h| u8::from_str_radix(h, 16).ok());
            if let Some(v) = v {
                out.push(v);
                i += 3;
                continue;
            }
        }
        out.push(b[i]);
        i += 1;
    }
    String::from_utf8_lossy(&out).into_owned()
}

fn content_disposition_name(v: &str) -> Option<String> {
    let mut plain = None;
    for part in v.split(';').map(str::trim) {
        let lower = part.to_ascii_lowercase();
        if lower.starts_with("filename*=") {
            let val = &part[10..];
            let enc = val.splitn(3, '\'').last().unwrap_or(val);
            return Some(percent_decode(enc.trim_matches('"')));
        } else if lower.starts_with("filename=") {
            plain = Some(part[9..].trim().trim_matches('"').to_string());
        }
    }
    plain
}

fn choose_filename(job: &Job, headers: &HeaderMap, url: &reqwest::Url) -> String {
    let raw = job
        .filename
        .clone()
        .or_else(|| headers.get(CONTENT_DISPOSITION).and_then(|v| v.to_str().ok()).and_then(content_disposition_name))
        .or_else(|| url.path_segments().and_then(|mut s| s.next_back()).map(percent_decode))
        .unwrap_or_default();
    let name = sanitize_filename(&raw);
    if job.filename.is_some() {
        return name; // an explicit name is never rewritten
    }
    match headers.get(CONTENT_TYPE).and_then(|v| v.to_str().ok()) {
        Some(ct) => ensure_media_ext(&name, ct),
        None => name,
    }
}

fn unique_path(dir: &Path, name: &str) -> PathBuf {
    let first = dir.join(name);
    if !first.exists() {
        return first;
    }
    let (stem, ext) = match name.rfind('.') {
        Some(i) if i > 0 => (&name[..i], &name[i..]),
        _ => (name, ""),
    };
    for n in 1..10_000u32 {
        let p = dir.join(format!("{stem} ({n}){ext}"));
        if !p.exists() {
            return p;
        }
    }
    dir.join(format!("{stem}-{}{ext}", SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_nanos()).unwrap_or(0)))
}

// ---------- probe ----------

struct Probe {
    total: Option<u64>,
    range_ok: bool,
    etag: Option<String>,
    last_modified: Option<String>,
    filename: String,
}

async fn probe_once(client: &Client, cfg: &EngineConfig, job: &Job) -> Result<Probe, DlError> {
    let req = get(client, &job.url, &job.referer, &job.cookie).header(RANGE, "bytes=0-0").send();
    let resp = match tokio::time::timeout(cfg.request_timeout, req).await {
        Ok(Ok(r)) => r,
        Ok(Err(e)) => return Err(net_err(e)),
        Err(_) => return Err(timeout_err("probe response headers")),
    };
    let status = resp.status().as_u16();
    let headers = resp.headers().clone();
    let url = resp.url().clone();
    let hdr = |k| headers.get(k).and_then(|v| v.to_str().ok()).map(str::to_owned);
    let (total, range_ok) = match status {
        206 => match hdr(CONTENT_RANGE).map(|h| validate_content_range(ByteRange { start: 0, end: 0 }, &h, None)) {
            Some(Ok(cr)) if cr.total.is_some() => (cr.total, true),
            _ => (None, false), // malformed Content-Range: do not trust ranges, fall back to one stream
        },
        200 => (hdr(CONTENT_LENGTH).and_then(|s| s.trim().parse::<u64>().ok()), false),
        416 if hdr(CONTENT_RANGE).as_deref() == Some("bytes */0") => (Some(0), false),
        s => return Err(status_error(s, &headers)),
    };
    let etag = hdr(ETAG).filter(|e| !e.starts_with("W/"));
    Ok(Probe { total, range_ok, etag, last_modified: hdr(LAST_MODIFIED), filename: choose_filename(job, &headers, &url) })
}

async fn probe(
    client: &Client,
    cfg: &EngineConfig,
    job: &Job,
    progress: &Progress,
    ctrl: &mut watch::Receiver<Signal>,
) -> Result<Option<Probe>, DlError> {
    let mut attempt = 0;
    loop {
        if sig(ctrl) != Signal::Run {
            return Ok(None);
        }
        match probe_once(client, cfg, job).await {
            Ok(p) => return Ok(Some(p)),
            Err(e) if e.retriable && attempt < cfg.max_retries => {
                attempt += 1;
                progress.retries.fetch_add(1, Ordering::SeqCst);
                sleep_or_signal(backoff(cfg, attempt, e.retry_after), ctrl).await;
            }
            Err(e) => return Err(e),
        }
    }
}

pub(crate) fn get(client: &Client, url: &str, referer: &Option<String>, cookie: &Option<String>) -> reqwest::RequestBuilder {
    let mut b = client.get(url);
    if let Some(r) = referer {
        b = b.header(reqwest::header::REFERER, r.as_str()); // validated as a URL when the download was added
    }
    if let Some(c) = cookie {
        b = b.header(reqwest::header::COOKIE, c.as_str()); // reqwest drops it on a redirect to another host
    }
    b
}

pub(crate) fn build_client(cfg: &EngineConfig, job: &Job) -> Result<Client, DlError> {
    let mut b = Client::builder()
        .connect_timeout(cfg.connect_timeout)
        .user_agent(cfg.user_agent.clone())
        .redirect(reqwest::redirect::Policy::limited(10));
    match &job.proxy {
        ProxyChoice::Default => {
            if !cfg.use_system_proxy {
                b = b.no_proxy();
            }
        }
        ProxyChoice::None => b = b.no_proxy(),
        ProxyChoice::Url(u) => {
            let p = reqwest::Proxy::all(u.as_str()).map_err(|e| DlError::new(ErrKind::Network, format!("bad proxy settings: {e}"), false))?;
            b = b.proxy(p);
        }
    }
    b.build().map_err(|e| DlError::new(ErrKind::Network, e.to_string(), false))
}

// ---------- entry point ----------

pub async fn run_download(
    cfg: &EngineConfig,
    job: &Job,
    progress: Arc<Progress>,
    mut ctrl: watch::Receiver<Signal>,
) -> Result<Outcome, DlError> {
    let client = build_client(cfg, job)?;
    fs::create_dir_all(&job.dest_dir).map_err(io_err)?;
    if crate::hls::is_hls(&job.url) {
        return crate::hls::run_hls(cfg, job, client, progress, ctrl).await;
    }
    let p = match probe(&client, cfg, job, &progress, &mut ctrl).await? {
        Some(p) => p,
        None => return Ok(stop_outcome(&ctrl)),
    };
    *progress.filename.lock().unwrap() = Some(p.filename.clone());
    match (p.range_ok, p.total) {
        (true, Some(total)) if total > 0 => segmented(cfg, job, client, progress, ctrl, p, total).await,
        _ => single_stream(cfg, job, client, progress, ctrl, p).await,
    }
}

// ---------- finalize ----------

pub(crate) async fn finalize(
    job: &Job,
    part: PathBuf,
    state: Option<PathBuf>,
    file: Arc<File>,
    filename: &str,
    expected_len: u64,
    segmented: bool,
) -> Result<Outcome, DlError> {
    let p = part.clone();
    let (len, sha) = tokio::task::spawn_blocking(move || -> std::io::Result<(u64, String)> {
        file.sync_all()?;
        let mut f = File::open(&p)?;
        let len = f.metadata()?.len();
        let mut h = Sha256::new();
        let mut buf = vec![0u8; 1 << 20];
        loop {
            let n = f.read(&mut buf)?;
            if n == 0 {
                break;
            }
            h.update(&buf[..n]);
        }
        Ok((len, hex(&h.finalize())))
    })
    .await
    .map_err(|e| DlError::new(ErrKind::Io, format!("hash task failed: {e}"), false))?
    .map_err(io_err)?;

    let discard = |why: String| {
        let _ = fs::remove_file(&part);
        if let Some(s) = &state {
            let _ = fs::remove_file(s);
        }
        DlError::new(ErrKind::Integrity, why, false)
    };
    if len != expected_len {
        return Err(discard(format!("file size {len} != expected {expected_len}")));
    }
    if let Some(want) = &job.expected_sha256 {
        if !want.eq_ignore_ascii_case(&sha) {
            return Err(discard(format!("SHA-256 mismatch: expected {want}, got {sha}")));
        }
    }
    let dest = unique_path(&job.dest_dir, filename);
    fs::rename(&part, &dest).map_err(io_err)?;
    if let Some(s) = &state {
        let _ = fs::remove_file(s);
    }
    Ok(Outcome::Completed { path: dest, sha256: sha, segmented })
}

// ---------- single stream ----------

enum StreamEnd {
    Complete(u64),
    Stopped,
}

async fn stream_once(
    cfg: &EngineConfig,
    job: &Job,
    client: &Client,
    progress: &Arc<Progress>,
    ctrl: &mut watch::Receiver<Signal>,
    file: &Arc<File>,
) -> Result<StreamEnd, DlError> {
    let _g = ConnGuard::new(progress);
    file.set_len(0).map_err(io_err)?;
    progress.downloaded.store(0, Ordering::SeqCst);
    let send = get(client, &job.url, &job.referer, &job.cookie).send();
    let mut resp = tokio::select! {
        r = tokio::time::timeout(cfg.request_timeout, send) => match r {
            Ok(Ok(resp)) => resp,
            Ok(Err(e)) => return Err(net_err(e)),
            Err(_) => return Err(timeout_err("response headers")),
        },
        _ = ctrl.changed() => return Ok(StreamEnd::Stopped),
    };
    let status = resp.status().as_u16();
    if status != 200 {
        return Err(status_error(status, resp.headers()));
    }
    let expected = resp.content_length();
    progress.total.store(expected.unwrap_or(0), Ordering::SeqCst);
    let mut off = 0u64;
    loop {
        let next = tokio::select! {
            r = tokio::time::timeout(cfg.idle_timeout, resp.chunk()) => r,
            _ = ctrl.changed() => return Ok(StreamEnd::Stopped),
        };
        match next {
            Err(_) => return Err(timeout_err("stalled stream")),
            Ok(Err(e)) => return Err(net_err(e)),
            Ok(Ok(None)) => {
                if let Some(t) = expected {
                    if off != t {
                        return Err(DlError::new(ErrKind::Network, "stream ended before Content-Length", true));
                    }
                }
                return Ok(StreamEnd::Complete(off));
            }
            Ok(Ok(Some(chunk))) => {
                let n = chunk.len() as u64;
                for l in &job.limiters {
                    l.acquire(n).await;
                }
                write_at(file, off, chunk.to_vec()).await?;
                off += n;
                progress.downloaded.fetch_add(n, Ordering::SeqCst);
            }
        }
    }
}

async fn single_stream(
    cfg: &EngineConfig,
    job: &Job,
    client: Client,
    progress: Arc<Progress>,
    mut ctrl: watch::Receiver<Signal>,
    p: Probe,
) -> Result<Outcome, DlError> {
    progress.segmented.store(false, Ordering::SeqCst);
    let part = part_path(&job.dest_dir, &p.filename);
    let st = state_path(&job.dest_dir, &p.filename);
    let _ = fs::remove_file(&st); // single-stream downloads are not resumable
    let file = Arc::new(
        OpenOptions::new().read(true).write(true).create(true).truncate(true).open(&part).map_err(io_err)?,
    );
    let mut attempt = 0u32;
    loop {
        if sig(&ctrl) != Signal::Run {
            let _ = fs::remove_file(&part);
            return Ok(stop_outcome(&ctrl));
        }
        match stream_once(cfg, job, &client, &progress, &mut ctrl, &file).await {
            Ok(StreamEnd::Complete(n)) => return finalize(job, part, None, file, &p.filename, n, false).await,
            Ok(StreamEnd::Stopped) => {
                let _ = fs::remove_file(&part);
                return Ok(stop_outcome(&ctrl));
            }
            Err(e) if e.retriable && attempt < cfg.max_retries => {
                attempt += 1;
                progress.retries.fetch_add(1, Ordering::SeqCst);
                sleep_or_signal(backoff(cfg, attempt, e.retry_after), &mut ctrl).await;
            }
            Err(e) => {
                let _ = fs::remove_file(&part);
                return Err(e);
            }
        }
    }
}

// ---------- segmented ----------

struct Shared {
    client: Client,
    cfg: EngineConfig,
    url: String,
    referer: Option<String>,
    cookie: Option<String>,
    etag: Option<String>,
    last_modified: Option<String>,
    filename: String,
    total: u64,
    ranges: Vec<ByteRange>,
    done: Arc<Vec<AtomicU64>>,
    file: Arc<File>,
    progress: Arc<Progress>,
    limiters: Vec<Arc<RateLimiter>>,
}

impl Shared {
    fn snapshot(&self) -> PartState {
        PartState {
            url: self.url.clone(),
            total: self.total,
            etag: self.etag.clone(),
            last_modified: self.last_modified.clone(),
            filename: self.filename.clone(),
            segments: self
                .ranges
                .iter()
                .zip(self.done.iter())
                .map(|(r, d)| SegState { start: r.start, end: r.end, done: d.load(Ordering::SeqCst) })
                .collect(),
        }
    }
}

async fn save_state(path: PathBuf, file: Arc<File>, st: PartState) {
    let _ = tokio::task::spawn_blocking(move || {
        let _ = file.sync_data(); // data first, then the record that claims it
        let mut tmp = path.clone().into_os_string();
        tmp.push(".tmp");
        let tmp = PathBuf::from(tmp);
        if let Ok(json) = serde_json::to_vec(&st) {
            if fs::write(&tmp, json).is_ok() {
                let _ = fs::rename(&tmp, &path);
            }
        }
    })
    .await;
}

enum FetchEnd {
    Complete,
    Stopped,
    Short,
}

async fn fetch_range(
    sh: &Arc<Shared>,
    idx: usize,
    req: ByteRange,
    ctrl: &mut watch::Receiver<Signal>,
) -> Result<FetchEnd, DlError> {
    let _g = ConnGuard::new(&sh.progress);
    let mut rb = get(&sh.client, &sh.url, &sh.referer, &sh.cookie).header(RANGE, format!("bytes={}-{}", req.start, req.end));
    if let Some(e) = &sh.etag {
        rb = rb.header(IF_RANGE, e.as_str());
    }
    let send = rb.send();
    let mut resp = tokio::select! {
        r = tokio::time::timeout(sh.cfg.request_timeout, send) => match r {
            Ok(Ok(resp)) => resp,
            Ok(Err(e)) => return Err(net_err(e)),
            Err(_) => return Err(timeout_err("response headers")),
        },
        _ = ctrl.changed() => return Ok(FetchEnd::Stopped),
    };
    let status = resp.status().as_u16();
    if status != 206 {
        if status == 200 {
            return Err(if sh.etag.is_some() {
                DlError::new(ErrKind::ResourceChanged, "server answered 200 to If-Range: resource changed", false)
            } else {
                DlError::new(ErrKind::RangeIgnored, "server returned 200 to a range request", false)
            });
        }
        return Err(status_error(status, resp.headers()));
    }
    let cr = resp
        .headers()
        .get(CONTENT_RANGE)
        .and_then(|v| v.to_str().ok())
        .map(str::to_owned)
        .ok_or_else(|| bad("missing Content-Range"))?;
    validate_content_range(req, &cr, Some(sh.total)).map_err(|e| bad(format!("invalid Content-Range: {e:?}")))?;
    let got_etag = resp.headers().get(ETAG).and_then(|v| v.to_str().ok()).map(str::to_owned);
    if let (Some(want), Some(got)) = (&sh.etag, &got_etag) {
        if want != got {
            return Err(DlError::new(ErrKind::ResourceChanged, "ETag changed during download", false));
        }
    }
    if let Some(cl) = resp.content_length() {
        if cl != req.len() {
            return Err(bad("Content-Length does not match requested range"));
        }
    }
    let seg_start = sh.ranges[idx].start;
    let mut off = req.start;
    loop {
        let next = tokio::select! {
            r = tokio::time::timeout(sh.cfg.idle_timeout, resp.chunk()) => r,
            _ = ctrl.changed() => return Ok(FetchEnd::Stopped),
        };
        match next {
            Err(_) => return Err(timeout_err("stalled range")),
            Ok(Err(e)) => return Err(net_err(e)),
            Ok(Ok(None)) => return Ok(if off > req.end { FetchEnd::Complete } else { FetchEnd::Short }),
            Ok(Ok(Some(chunk))) => {
                let n = chunk.len() as u64;
                if off + n > req.end + 1 {
                    return Err(bad("response body longer than requested range"));
                }
                for l in &sh.limiters {
                    l.acquire(n).await;
                }
                write_at(&sh.file, off, chunk.to_vec()).await?;
                off += n;
                sh.done[idx].store(off - seg_start, Ordering::SeqCst);
                sh.progress.downloaded.fetch_add(n, Ordering::SeqCst);
                if off > req.end {
                    return Ok(FetchEnd::Complete);
                }
            }
        }
    }
}

async fn segment_worker(sh: Arc<Shared>, idx: usize, mut ctrl: watch::Receiver<Signal>) -> Result<(), DlError> {
    let seg = sh.ranges[idx];
    let mut attempt = 0u32;
    loop {
        if sig(&ctrl) != Signal::Run {
            return Ok(());
        }
        let done = sh.done[idx].load(Ordering::SeqCst);
        if done >= seg.len() {
            return Ok(());
        }
        let req = ByteRange { start: seg.start + done, end: seg.end };
        let res = fetch_range(&sh, idx, req, &mut ctrl).await;
        let after = sh.done[idx].load(Ordering::SeqCst);
        let err = match res {
            Ok(FetchEnd::Complete) | Ok(FetchEnd::Stopped) => continue,
            Ok(FetchEnd::Short) => DlError::new(ErrKind::Network, "connection closed before range completed", true),
            Err(e) => e,
        };
        if after > done {
            attempt = 0; // made progress: the retry budget is for consecutive failures
        }
        if !err.retriable || attempt >= sh.cfg.max_retries {
            return Err(err);
        }
        attempt += 1;
        sh.progress.retries.fetch_add(1, Ordering::SeqCst);
        sleep_or_signal(backoff(&sh.cfg, attempt, err.retry_after), &mut ctrl).await;
    }
}

async fn segmented(
    cfg: &EngineConfig,
    job: &Job,
    client: Client,
    progress: Arc<Progress>,
    ctrl: watch::Receiver<Signal>,
    p: Probe,
    total: u64,
) -> Result<Outcome, DlError> {
    let part = part_path(&job.dest_dir, &p.filename);
    let spath = state_path(&job.dest_dir, &p.filename);
    let n = job.max_conns.unwrap_or(cfg.max_conns).clamp(1, 32);

    // Reuse saved progress only if the remote resource is provably the same.
    let reusable = load_state(&spath).filter(|st| {
        st.url == job.url
            && st.total == total
            && st.etag == p.etag
            && (st.etag.is_some() || st.last_modified == p.last_modified)
            && st.valid(total)
            && fs::metadata(&part).map(|m| m.len() == total).unwrap_or(false)
    });
    let segs: Vec<SegState> = match reusable {
        Some(st) => st.segments,
        None => {
            cleanup_partials(&job.dest_dir, &p.filename);
            plan_segments(total, n, cfg.min_segment)
                .into_iter()
                .map(|r| SegState { start: r.start, end: r.end, done: 0 })
                .collect()
        }
    };
    let file = OpenOptions::new().read(true).write(true).create(true).truncate(false).open(&part).map_err(io_err)?;
    if file.metadata().map_err(io_err)?.len() != total {
        file.set_len(total).map_err(io_err)?;
    }
    let file = Arc::new(file);

    let ranges: Vec<ByteRange> = segs.iter().map(|s| ByteRange { start: s.start, end: s.end }).collect();
    let already: u64 = segs.iter().map(|s| s.done).sum();
    progress.total.store(total, Ordering::SeqCst);
    progress.downloaded.store(already, Ordering::SeqCst);
    progress.segmented.store(true, Ordering::SeqCst);

    let sh = Arc::new(Shared {
        client,
        cfg: cfg.clone(),
        url: job.url.clone(),
        referer: job.referer.clone(),
        cookie: job.cookie.clone(),
        etag: p.etag.clone(),
        last_modified: p.last_modified.clone(),
        filename: p.filename.clone(),
        total,
        ranges: ranges.clone(),
        done: Arc::new(segs.iter().map(|s| AtomicU64::new(s.done)).collect()),
        file: file.clone(),
        progress: progress.clone(),
        limiters: job.limiters.clone(),
    });

    *progress.seg_ranges.lock().unwrap() = ranges.iter().map(|r| (r.start, r.end)).collect();
    *progress.seg_done.lock().unwrap() = Some(sh.done.clone());
    let mut set: JoinSet<Result<(), DlError>> = JoinSet::new();
    for (i, r) in ranges.iter().enumerate() {
        if sh.done[i].load(Ordering::SeqCst) < r.len() {
            set.spawn(segment_worker(sh.clone(), i, ctrl.clone()));
        }
    }
    let mut tick = tokio::time::interval(cfg.state_save_interval);
    tick.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
    tick.tick().await;
    let mut first_err: Option<DlError> = None;
    loop {
        tokio::select! {
            r = set.join_next() => match r {
                None => break,
                Some(Ok(Ok(()))) => {}
                Some(Ok(Err(e))) => { if first_err.is_none() { first_err = Some(e); set.abort_all(); } }
                Some(Err(je)) => {
                    if !je.is_cancelled() && first_err.is_none() {
                        first_err = Some(DlError::new(ErrKind::Io, "segment worker panicked", false));
                        set.abort_all();
                    }
                }
            },
            _ = tick.tick() => save_state(spath.clone(), file.clone(), sh.snapshot()).await,
        }
    }
    save_state(spath.clone(), file.clone(), sh.snapshot()).await;

    if let Some(e) = first_err {
        return Err(e); // partial data and state are kept so the user can retry/resume
    }
    match sig(&ctrl) {
        Signal::Cancel => {
            cleanup_partials(&job.dest_dir, &p.filename);
            return Ok(Outcome::Cancelled);
        }
        Signal::Pause => return Ok(Outcome::Paused),
        Signal::Run => {}
    }
    if !(0..ranges.len()).all(|i| sh.done[i].load(Ordering::SeqCst) >= ranges[i].len()) {
        return Err(DlError::new(ErrKind::Io, "download ended with incomplete segments", false));
    }
    verify_exact_cover(total, &ranges).map_err(|e| bad(format!("segment coverage error: {e:?}")))?;
    finalize(job, part, Some(spath), file, &p.filename, total, true).await
}
