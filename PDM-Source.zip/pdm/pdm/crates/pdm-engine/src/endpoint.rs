//! Endpoint naming. The UI client derives the same name (see ui/src/ipc_client.cpp).

/// Keep only [A-Za-z0-9_-], at most 32 chars.
pub fn sanitize_component(s: &str) -> String {
    let cleaned: String = s
        .chars()
        .map(|c| if c.is_ascii_alphanumeric() || c == '_' || c == '-' { c } else { '_' })
        .take(32)
        .collect();
    if cleaned.is_empty() { "user".to_string() } else { cleaned }
}

/// `PDM_PIPE_NAME` overrides (used by tests); otherwise `pdm-v1-<user>`.
pub fn default_endpoint_name() -> String {
    if let Ok(n) = std::env::var("PDM_PIPE_NAME") {
        if !n.is_empty() {
            return sanitize_component(&n);
        }
    }
    let user = std::env::var("USERNAME").or_else(|_| std::env::var("USER")).unwrap_or_default();
    format!("pdm-v1-{}", sanitize_component(&user))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sanitizes() {
        assert_eq!(sanitize_component("Ana Lee\\x"), "Ana_Lee_x");
        assert_eq!(sanitize_component(""), "user");
        assert_eq!(sanitize_component(&"a".repeat(100)).len(), 32);
    }
}
