//! Deterministic local HTTP/1.1 fixture server used by the engine tests.
//! Records every request (range, start/end instants, bytes sent) so tests can
//! prove genuine concurrency and exact byte coverage.
use std::collections::HashMap;
use std::net::SocketAddr;
use std::path::PathBuf;
use std::sync::atomic::{AtomicU32, Ordering};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};

#[derive(Clone)]
pub struct Behavior {
    pub data: Arc<Vec<u8>>,
    pub etag: Option<String>,
    pub flip_etag_after: Option<u32>,
    pub accept_ranges: bool,
    pub advertise_ranges: bool,
    pub bad_content_range: bool,
    pub omit_content_length: bool,
    pub fail_first_n: u32,
    pub fail_status: u16,
    pub retry_after: Option<u32>,
    pub truncate_after: Option<usize>,
    pub truncate_times: u32,
    pub chunk_size: usize,
    pub chunk_delay_ms: u64,
    pub redirect_to: Option<String>,
    pub content_disposition: Option<String>,
}

impl Behavior {
    pub fn new(data: Vec<u8>) -> Self {
        Behavior {
            data: Arc::new(data),
            etag: Some("\"v1\"".into()),
            flip_etag_after: None,
            accept_ranges: true,
            advertise_ranges: true,
            bad_content_range: false,
            omit_content_length: false,
            fail_first_n: 0,
            fail_status: 503,
            retry_after: Some(0),
            truncate_after: None,
            truncate_times: 0,
            chunk_size: 16 * 1024,
            chunk_delay_ms: 0,
            redirect_to: None,
            content_disposition: None,
        }
    }
}

#[derive(Clone, Debug)]
pub struct RequestRecord {
    pub path: String,
    pub range: Option<(u64, u64)>,
    pub status: u16,
    pub started: Instant,
    pub ended: Option<Instant>,
    pub body_bytes: u64,
}

struct Entry {
    b: Behavior,
    hits: AtomicU32,
    fails_left: AtomicU32,
    truncs_left: AtomicU32,
}

type Entries = Arc<Mutex<HashMap<String, Arc<Entry>>>>;
type Log = Arc<Mutex<Vec<RequestRecord>>>;

pub struct Fixture {
    pub addr: SocketAddr,
    entries: Entries,
    log: Log,
    task: tokio::task::JoinHandle<()>,
}

impl Drop for Fixture {
    fn drop(&mut self) {
        self.task.abort();
    }
}

impl Fixture {
    pub async fn start() -> Fixture {
        let listener = TcpListener::bind("127.0.0.1:0").await.expect("bind fixture");
        let addr = listener.local_addr().unwrap();
        let entries: Entries = Arc::new(Mutex::new(HashMap::new()));
        let log: Log = Arc::new(Mutex::new(Vec::new()));
        let (e2, l2) = (entries.clone(), log.clone());
        let task = tokio::spawn(async move {
            loop {
                let Ok((s, _)) = listener.accept().await else { break };
                let (e, l) = (e2.clone(), l2.clone());
                tokio::spawn(async move {
                    let _ = handle(s, e, l).await;
                });
            }
        });
        Fixture { addr, entries, log, task }
    }

    pub fn add(&self, path: &str, b: Behavior) {
        let e = Entry {
            hits: AtomicU32::new(0),
            fails_left: AtomicU32::new(b.fail_first_n),
            truncs_left: AtomicU32::new(b.truncate_times),
            b,
        };
        self.entries.lock().unwrap().insert(path.to_string(), Arc::new(e));
    }

    pub fn url(&self, path: &str) -> String {
        format!("http://{}{}", self.addr, path)
    }

    pub fn log(&self) -> Vec<RequestRecord> {
        self.log.lock().unwrap().clone()
    }

    pub fn requests_for(&self, path: &str) -> Vec<RequestRecord> {
        self.log().into_iter().filter(|r| r.path == path).collect()
    }

    /// Maximum number of simultaneously open requests for `path`.
    pub fn max_concurrency(&self, path: &str) -> usize {
        let now = Instant::now();
        let recs = self.requests_for(path);
        recs.iter()
            .map(|r| {
                recs.iter()
                    .filter(|o| o.started <= r.started && o.ended.unwrap_or(now) >= r.started)
                    .count()
            })
            .max()
            .unwrap_or(0)
    }
}

fn parse_range(v: &str, len: u64) -> Option<Result<(u64, u64), ()>> {
    let spec = v.trim().strip_prefix("bytes=")?;
    let (a, b) = spec.split_once('-')?;
    let a: u64 = a.parse().ok()?;
    let b: Option<u64> = if b.is_empty() { None } else { Some(b.parse().ok()?) };
    if a >= len {
        return Some(Err(()));
    }
    let end = b.map_or(len - 1, |b| b.min(len - 1));
    if end < a {
        return None;
    }
    Some(Ok((a, end)))
}

async fn respond_simple(s: &mut TcpStream, status: u16, extra: &str) {
    let reason = match status {
        302 => "Found",
        404 => "Not Found",
        416 => "Range Not Satisfiable",
        _ => "Error",
    };
    let msg = format!("HTTP/1.1 {status} {reason}\r\n{extra}Content-Length: 0\r\nConnection: close\r\n\r\n");
    let _ = s.write_all(msg.as_bytes()).await;
    let _ = s.shutdown().await;
}

async fn handle(mut s: TcpStream, entries: Entries, log: Log) -> std::io::Result<()> {
    let mut buf = Vec::new();
    let mut tmp = [0u8; 4096];
    loop {
        let n = s.read(&mut tmp).await?;
        if n == 0 {
            return Ok(());
        }
        buf.extend_from_slice(&tmp[..n]);
        if buf.windows(4).any(|w| w == b"\r\n\r\n") {
            break;
        }
        if buf.len() > 16 * 1024 {
            return Ok(());
        }
    }
    let text = String::from_utf8_lossy(&buf).to_string();
    let mut lines = text.split("\r\n");
    let first = lines.next().unwrap_or("");
    let mut parts = first.split(' ');
    let (_method, path) = (parts.next().unwrap_or(""), parts.next().unwrap_or("/").to_string());
    let mut headers: HashMap<String, String> = HashMap::new();
    for l in lines {
        if let Some((k, v)) = l.split_once(':') {
            headers.insert(k.trim().to_ascii_lowercase(), v.trim().to_string());
        }
    }
    let Some(entry) = entries.lock().unwrap().get(&path).cloned() else {
        let now = Instant::now();
        log.lock().unwrap().push(RequestRecord { path: path.clone(), range: None, status: 404, started: now, ended: Some(now), body_bytes: 0 });
        respond_simple(&mut s, 404, "").await;
        return Ok(());
    };
    let b = &entry.b;
    let hit = entry.hits.fetch_add(1, Ordering::SeqCst);
    let idx = {
        let mut g = log.lock().unwrap();
        g.push(RequestRecord { path: path.clone(), range: None, status: 0, started: Instant::now(), ended: None, body_bytes: 0 });
        g.len() - 1
    };
    let finish = |status: u16, range: Option<(u64, u64)>, body: u64| {
        let mut g = log.lock().unwrap();
        let r = &mut g[idx];
        r.status = status;
        r.range = range;
        r.body_bytes = body;
        r.ended = Some(Instant::now());
    };

    if entry.fails_left.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |v| v.checked_sub(1)).is_ok() {
        let ra = b.retry_after.map(|r| format!("Retry-After: {r}\r\n")).unwrap_or_default();
        let msg = format!("HTTP/1.1 {} Error\r\n{ra}Content-Length: 0\r\nConnection: close\r\n\r\n", b.fail_status);
        let _ = s.write_all(msg.as_bytes()).await;
        let _ = s.shutdown().await;
        finish(b.fail_status, None, 0);
        return Ok(());
    }
    if let Some(loc) = &b.redirect_to {
        respond_simple(&mut s, 302, &format!("Location: {loc}\r\n")).await;
        finish(302, None, 0);
        return Ok(());
    }

    let len = b.data.len() as u64;
    let etag = b.etag.clone().map(|e| match b.flip_etag_after {
        Some(n) if hit >= n => "\"v2\"".to_string(),
        _ => e,
    });
    let mut range: Option<(u64, u64)> = None;
    if b.accept_ranges {
        if let Some(rv) = headers.get("range") {
            let if_range_ok = match (headers.get("if-range"), &etag) {
                (Some(ir), Some(e)) => ir == e,
                (Some(_), None) => false,
                (None, _) => true,
            };
            if if_range_ok {
                match parse_range(rv, len) {
                    Some(Ok(r)) => range = Some(r),
                    Some(Err(())) => {
                        respond_simple(&mut s, 416, &format!("Content-Range: bytes */{len}\r\n")).await;
                        finish(416, None, 0);
                        return Ok(());
                    }
                    None => {}
                }
            }
        }
    }
    let mut head = String::new();
    let (status, body): (u16, &[u8]) = match range {
        Some((a, e)) => {
            let (ra, re) = if b.bad_content_range { (a + 1, e + 1) } else { (a, e) };
            head.push_str(&format!("HTTP/1.1 206 Partial Content\r\nContent-Range: bytes {ra}-{re}/{len}\r\n"));
            (206, &b.data[a as usize..=e as usize])
        }
        None => {
            head.push_str("HTTP/1.1 200 OK\r\n");
            (200, &b.data[..])
        }
    };
    let mut send_len = body.len();
    if let Some(t) = b.truncate_after {
        if body.len() > t && entry.truncs_left.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |v| v.checked_sub(1)).is_ok() {
            send_len = t;
        }
    }
    if !b.omit_content_length {
        head.push_str(&format!("Content-Length: {}\r\n", body.len()));
    }
    if b.advertise_ranges {
        head.push_str("Accept-Ranges: bytes\r\n");
    }
    if let Some(e) = &etag {
        head.push_str(&format!("ETag: {e}\r\n"));
    }
    if let Some(cd) = &b.content_disposition {
        head.push_str(&format!("Content-Disposition: {cd}\r\n"));
    }
    head.push_str("Connection: close\r\n\r\n");
    if s.write_all(head.as_bytes()).await.is_err() {
        finish(status, range, 0);
        return Ok(());
    }
    let mut sent = 0u64;
    for chunk in body[..send_len].chunks(b.chunk_size.max(1)) {
        if s.write_all(chunk).await.is_err() {
            break;
        }
        sent += chunk.len() as u64;
        if b.chunk_delay_ms > 0 {
            tokio::time::sleep(Duration::from_millis(b.chunk_delay_ms)).await;
        }
    }
    let _ = s.shutdown().await;
    finish(status, range, sent);
    Ok(())
}

/// Deterministic pseudo-random test data.
pub fn test_data(len: usize, seed: u64) -> Vec<u8> {
    let mut x = seed.wrapping_mul(0x9E37_79B9_7F4A_7C15) | 1;
    (0..len)
        .map(|_| {
            x ^= x << 13;
            x ^= x >> 7;
            x ^= x << 17;
            (x >> 24) as u8
        })
        .collect()
}

pub fn temp_dir(tag: &str) -> PathBuf {
    use std::sync::atomic::AtomicU64;
    static N: AtomicU64 = AtomicU64::new(0);
    let p = std::env::temp_dir().join(format!(
        "pdm-test-{}-{}-{}",
        std::process::id(),
        tag,
        N.fetch_add(1, std::sync::atomic::Ordering::SeqCst)
    ));
    std::fs::create_dir_all(&p).unwrap();
    p
}
