//! HLS (.m3u8) downloads: choose a variant, fetch every segment (several at a time), and write them in order
//! into one .ts file (or .mp4 for fragmented-MP4 playlists). Not supported, and rejected with a clear error:
//! encrypted playlists, byte-range segments and live streams. Not resumable: Resume starts over.
use crate::download::{
    backoff, finalize, get, io_err, net_err, part_path, percent_decode, sig, status_error, stop_outcome, DlError, EngineConfig, ErrKind, Job, Outcome, Progress, Signal,
};
use pdm_core::filename::sanitize_filename;
use reqwest::{Client, Url};
use std::fs::OpenOptions;
use std::io::Write;
use std::sync::atomic::Ordering;
use std::sync::Arc;
use tokio::sync::watch;
use tokio::task::JoinSet;

const MAX_PLAYLIST_BYTES: usize = 8 << 20;
const MAX_SEGMENTS: usize = 100_000;

/// A `.m3u8` path, or the `#pdm-hls` fragment the browser extension adds when the server hides the extension.
pub fn is_hls(url: &str) -> bool {
    match Url::parse(url) {
        Ok(u) => u.path().to_ascii_lowercase().ends_with(".m3u8") || u.fragment() == Some("pdm-hls"),
        Err(_) => false,
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct Variant {
    pub url: Url,
    pub bandwidth: u64,
    pub height: u32,
}

#[derive(Debug, Clone, PartialEq)]
pub struct Media {
    pub init: Option<Url>,
    pub segments: Vec<Url>,
}

#[derive(Debug, Clone, PartialEq)]
pub enum Parsed {
    Master(Vec<Variant>),
    Media(Media),
}

/// `KEY=value,KEY2="quoted, value"` -> pairs (quotes removed).
fn attrs(s: &str) -> Vec<(String, String)> {
    let (mut out, mut cur, mut inq) = (Vec::new(), String::new(), false);
    let mut push = |cur: &mut String, out: &mut Vec<(String, String)>| {
        if let Some((k, v)) = cur.split_once('=') {
            out.push((k.trim().to_ascii_uppercase(), v.trim().trim_matches('"').to_string()));
        }
        cur.clear();
    };
    for c in s.chars() {
        match c {
            '"' => {
                inq = !inq;
                cur.push(c);
            }
            ',' if !inq => push(&mut cur, &mut out),
            _ => cur.push(c),
        }
    }
    push(&mut cur, &mut out);
    out
}

fn attr<'a>(a: &'a [(String, String)], k: &str) -> Option<&'a str> {
    a.iter().find(|(n, _)| n == k).map(|(_, v)| v.as_str())
}

pub fn parse(text: &str, base: &Url) -> Result<Parsed, String> {
    let mut lines = text.lines().map(str::trim).filter(|l| !l.is_empty());
    if !lines.next().map_or(false, |l| l.starts_with("#EXTM3U")) {
        return Err("not an HLS playlist".into());
    }
    let join = |u: &str| base.join(u).map_err(|e| format!("bad playlist URL {u:?}: {e}"));
    let (mut variants, mut segments, mut init) = (Vec::new(), Vec::new(), None);
    let (mut pending_variant, mut expect_segment, mut ended) = (None::<(u64, u32)>, false, false);
    for l in lines {
        if let Some(rest) = l.strip_prefix("#EXT-X-STREAM-INF:") {
            let a = attrs(rest);
            let bw = attr(&a, "BANDWIDTH").and_then(|v| v.parse().ok()).unwrap_or(0);
            let h = attr(&a, "RESOLUTION").and_then(|r| r.split(['x', 'X']).nth(1)).and_then(|v| v.parse().ok()).unwrap_or(0);
            pending_variant = Some((bw, h));
        } else if let Some(rest) = l.strip_prefix("#EXT-X-KEY:") {
            let a = attrs(rest);
            let m = attr(&a, "METHOD").unwrap_or("NONE");
            if m != "NONE" {
                return Err(format!("encrypted playlists (METHOD={m}) are not supported"));
            }
        } else if let Some(rest) = l.strip_prefix("#EXT-X-MAP:") {
            if let Some(u) = attr(&attrs(rest), "URI") {
                init = Some(join(u)?);
            }
        } else if l.starts_with("#EXT-X-BYTERANGE") {
            return Err("byte-range segments are not supported".into());
        } else if l.starts_with("#EXTINF") {
            expect_segment = true;
        } else if l.starts_with("#EXT-X-ENDLIST") {
            ended = true;
        } else if l.starts_with('#') {
            continue;
        } else if let Some((bandwidth, height)) = pending_variant.take() {
            variants.push(Variant { url: join(l)?, bandwidth, height });
        } else if expect_segment || variants.is_empty() {
            expect_segment = false;
            if segments.len() >= MAX_SEGMENTS {
                return Err("playlist has too many segments".into());
            }
            segments.push(join(l)?);
        }
    }
    if !variants.is_empty() {
        return Ok(Parsed::Master(variants));
    }
    if segments.is_empty() {
        return Err("playlist has no segments".into());
    }
    if !ended {
        return Err("live streams are not supported".into());
    }
    Ok(Parsed::Media(Media { init, segments }))
}

fn pick_variant(v: &[Variant]) -> &Variant {
    v.iter().max_by_key(|x| (x.bandwidth, x.height)).expect("non-empty")
}

fn dl_err(kind: ErrKind, msg: impl Into<String>) -> DlError {
    DlError::new(kind, msg, false)
}

async fn fetch_text(client: &Client, cfg: &EngineConfig, job: &Job, url: &Url) -> Result<String, DlError> {
    let send = get(client, url.as_str(), &job.referer, &job.cookie).send();
    let resp = tokio::time::timeout(cfg.request_timeout, send)
        .await
        .map_err(|_| DlError::new(ErrKind::Timeout, "timed out: playlist", true))?
        .map_err(net_err)?;
    if !resp.status().is_success() {
        return Err(status_error(resp.status().as_u16(), resp.headers()));
    }
    let body = tokio::time::timeout(cfg.request_timeout, resp.bytes())
        .await
        .map_err(|_| DlError::new(ErrKind::Timeout, "timed out: playlist body", true))?
        .map_err(net_err)?;
    if body.len() > MAX_PLAYLIST_BYTES {
        return Err(dl_err(ErrKind::BadResponse, "playlist is too large"));
    }
    Ok(String::from_utf8_lossy(&body).into_owned())
}

async fn fetch_segment(client: Client, cfg: EngineConfig, job_referer: Option<String>, job_cookie: Option<String>, url: Url, limiters: Vec<Arc<crate::ratelimit::RateLimiter>>) -> Result<Vec<u8>, DlError> {
    let mut attempt = 0;
    loop {
        let res: Result<Vec<u8>, DlError> = async {
            let send = get(&client, url.as_str(), &job_referer, &job_cookie).send();
            let resp = tokio::time::timeout(cfg.request_timeout, send)
                .await
                .map_err(|_| DlError::new(ErrKind::Timeout, "timed out: segment", true))?
                .map_err(net_err)?;
            if !resp.status().is_success() {
                return Err(status_error(resp.status().as_u16(), resp.headers()));
            }
            tokio::time::timeout(cfg.request_timeout * 4, resp.bytes())
                .await
                .map_err(|_| DlError::new(ErrKind::Timeout, "timed out: segment body", true))?
                .map_err(net_err)
                .map(|b| b.to_vec())
        }
        .await;
        match res {
            Ok(b) => {
                for l in &limiters {
                    l.acquire(b.len() as u64).await;
                }
                return Ok(b);
            }
            Err(e) if e.retriable && attempt < cfg.max_retries => {
                attempt += 1;
                tokio::time::sleep(backoff(&cfg, attempt, e.retry_after)).await;
            }
            Err(e) => return Err(e),
        }
    }
}

/// Name from the playlist URL, without ".m3u8"; generic playlist names fall back to the host.
fn default_name(url: &Url, ext: &str) -> String {
    let last = url.path_segments().and_then(|mut s| s.next_back()).map(percent_decode).unwrap_or_default();
    let last = last.as_str();
    let stem = last.rsplit_once('.').map_or(last, |(s, _)| s);
    let generic = matches!(stem.to_ascii_lowercase().as_str(), "" | "index" | "playlist" | "master" | "chunklist" | "manifest" | "stream" | "video" | "hls");
    let base = if generic { url.host_str().unwrap_or("video").to_string() } else { stem.to_string() };
    format!("{}.{ext}", sanitize_filename(&base))
}

pub(crate) async fn run_hls(
    cfg: &EngineConfig,
    job: &Job,
    client: Client,
    progress: Arc<Progress>,
    mut ctrl: watch::Receiver<Signal>,
) -> Result<Outcome, DlError> {
    let top = Url::parse(&job.url).map_err(|e| dl_err(ErrKind::BadResponse, e.to_string()))?;
    let mut parsed = parse(&fetch_text(&client, cfg, job, &top).await?, &top).map_err(|e| dl_err(ErrKind::BadResponse, e))?;
    if let Parsed::Master(v) = &parsed {
        let chosen = pick_variant(v).url.clone();
        parsed = parse(&fetch_text(&client, cfg, job, &chosen).await?, &chosen).map_err(|e| dl_err(ErrKind::BadResponse, e))?;
    }
    let media = match parsed {
        Parsed::Media(m) => m,
        Parsed::Master(_) => return Err(dl_err(ErrKind::BadResponse, "playlist nesting is too deep")),
    };
    let ext = if media.init.is_some() { "mp4" } else { "ts" };
    let name = match &job.filename {
        Some(n) => sanitize_filename(n),
        None => default_name(&top, ext),
    };
    *progress.filename.lock().unwrap() = Some(name.clone());

    let part = part_path(&job.dest_dir, &name);
    let file = Arc::new(OpenOptions::new().create(true).write(true).truncate(true).open(&part).map_err(io_err)?);
    let items: Vec<Url> = media.init.iter().cloned().chain(media.segments.iter().cloned()).collect();
    let conc = job.max_conns.unwrap_or(cfg.max_conns).clamp(1, 16) as usize;
    progress.conns.store(conc as u32, Ordering::SeqCst);
    progress.segmented.store(false, Ordering::SeqCst);

    let (mut next, mut written) = (0usize, 0u64);
    while next < items.len() {
        if sig(&ctrl) != Signal::Run {
            return Ok(stop_outcome(&ctrl));
        }
        let end = (next + conc).min(items.len());
        let mut set = JoinSet::new();
        for (i, u) in items.iter().enumerate().take(end).skip(next) {
            let (c, cf, r, k, u, l) = (client.clone(), cfg.clone(), job.referer.clone(), job.cookie.clone(), u.clone(), job.limiters.clone());
            set.spawn(async move { (i, fetch_segment(c, cf, r, k, u, l).await) });
        }
        let mut got: Vec<(usize, Vec<u8>)> = Vec::with_capacity(end - next);
        loop {
            tokio::select! {
                r = set.join_next() => match r {
                    None => break,
                    Some(Ok((i, Ok(b)))) => got.push((i, b)),
                    Some(Ok((_, Err(e)))) => { set.abort_all(); return Err(e); }
                    Some(Err(e)) => return Err(dl_err(ErrKind::Io, format!("segment task failed: {e}"))),
                },
                _ = ctrl.changed() => {
                    if sig(&ctrl) != Signal::Run { set.abort_all(); return Ok(stop_outcome(&ctrl)); }
                }
            }
        }
        got.sort_by_key(|(i, _)| *i);
        for (_, b) in &got {
            (&*file).write_all(b).map_err(io_err)?;
            written += b.len() as u64;
        }
        next = end;
        progress.downloaded.store(written, Ordering::SeqCst);
        // Total is unknown until the end; extrapolate from the segments done so far so the UI can show a percentage.
        progress.total.store(written.saturating_mul(items.len() as u64) / next as u64, Ordering::SeqCst);
    }
    progress.total.store(written, Ordering::SeqCst);
    finalize(job, part, None, file, &name, written, false).await
}

#[cfg(test)]
mod tests {
    use super::*;

    fn base() -> Url {
        Url::parse("https://cdn.example/path/master.m3u8").unwrap()
    }

    #[test]
    fn detects_hls_urls() {
        assert!(is_hls("https://a/b/index.M3U8?token=1"));
        assert!(is_hls("https://a/stream.php?id=3#pdm-hls"));
        assert!(!is_hls("https://a/video.mp4"));
        assert!(!is_hls("not a url"));
    }

    #[test]
    fn master_playlist_lists_variants_with_quoted_commas() {
        let t = "#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=312000,RESOLUTION=854x480,CODECS=\"avc1.4d401e,mp4a.40.2\"\nlow/index.m3u8\n#EXT-X-STREAM-INF:BANDWIDTH=2800000,RESOLUTION=1920x1080\nhttps://other/hi.m3u8\n";
        match parse(t, &base()).unwrap() {
            Parsed::Master(v) => {
                assert_eq!(v.len(), 2);
                assert_eq!((v[0].bandwidth, v[0].height), (312000, 480));
                assert_eq!(v[0].url.as_str(), "https://cdn.example/path/low/index.m3u8");
                assert_eq!(pick_variant(&v).height, 1080);
            }
            p => panic!("{p:?}"),
        }
    }

    #[test]
    fn media_playlist_resolves_segments_and_init() {
        let t = "#EXTM3U\n#EXT-X-MAP:URI=\"init.mp4\"\n#EXTINF:4.0,\nseg1.m4s\n#EXTINF:4.0,\n/abs/seg2.m4s\n#EXT-X-ENDLIST\n";
        match parse(t, &base()).unwrap() {
            Parsed::Media(m) => {
                assert_eq!(m.init.unwrap().as_str(), "https://cdn.example/path/init.mp4");
                assert_eq!(m.segments[0].as_str(), "https://cdn.example/path/seg1.m4s");
                assert_eq!(m.segments[1].as_str(), "https://cdn.example/abs/seg2.m4s");
            }
            p => panic!("{p:?}"),
        }
    }

    #[test]
    fn rejects_what_it_cannot_save() {
        assert!(parse("<html>", &base()).is_err());
        assert!(parse("#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI=\"k\"\n#EXTINF:4,\na.ts\n#EXT-X-ENDLIST\n", &base()).unwrap_err().contains("encrypted"));
        assert!(parse("#EXTM3U\n#EXTINF:4,\na.ts\n", &base()).unwrap_err().contains("live"));
        assert!(parse("#EXTM3U\n#EXT-X-BYTERANGE:100@0\n#EXTINF:4,\na.ts\n#EXT-X-ENDLIST\n", &base()).is_err());
        assert!(parse("#EXTM3U\n#EXT-X-ENDLIST\n", &base()).is_err());
    }

    #[test]
    fn default_names_avoid_generic_playlist_names() {
        assert_eq!(default_name(&Url::parse("https://cdn.example/a/index.m3u8").unwrap(), "ts"), "cdn.example.ts");
        assert_eq!(default_name(&Url::parse("https://cdn.example/a/My Show.m3u8").unwrap(), "mp4"), "My Show.mp4");
    }
}
