//! pdmd: PDM engine daemon (Milestone 1: IPC skeleton only).
use std::process::ExitCode;
use std::sync::Arc;
use tokio::sync::Notify;
use std::path::PathBuf;
use pdm_engine::download::EngineConfig;
use pdm_engine::manager::{system_shutdown, Manager, PostAction};
use pdm_engine::{endpoint, server};

fn data_dir() -> PathBuf {
    std::env::var_os("PDM_DATA_DIR")
        .map(PathBuf::from)
        .or_else(|| std::env::var_os("APPDATA").map(|a| PathBuf::from(a).join("PDM")))
        .unwrap_or_else(|| std::env::temp_dir().join("pdm"))
}

fn main() -> ExitCode {
    let mut name: Option<String> = None;
    let mut resume = false;
    let mut args = std::env::args().skip(1);
    while let Some(a) = args.next() {
        match a.as_str() {
            "--endpoint" => match args.next() {
                Some(v) => name = Some(endpoint::sanitize_component(&v)),
                None => {
                    eprintln!("--endpoint requires a value");
                    return ExitCode::from(2);
                }
            },
            "--resume" => resume = true,
            "--version" => {
                println!("pdmd {}", env!("CARGO_PKG_VERSION"));
                return ExitCode::SUCCESS;
            }
            other => {
                eprintln!("unknown argument: {other}\nusage: pdmd [--endpoint NAME] [--resume] [--version]");
                return ExitCode::from(2);
            }
        }
    }
    let name = name.unwrap_or_else(endpoint::default_endpoint_name);

    // Two worker threads: enough for I/O multiplexing, bounded by design.
    let rt = match tokio::runtime::Builder::new_multi_thread().worker_threads(2).enable_all().build() {
        Ok(rt) => rt,
        Err(e) => {
            eprintln!("runtime error: {e}");
            return ExitCode::from(1);
        }
    };
    rt.block_on(async move {
        let shutdown = Arc::new(Notify::new());
        let sd = shutdown.clone();
        tokio::spawn(async move {
            let _ = tokio::signal::ctrl_c().await;
            sd.notify_one();
        });
        let sd2 = shutdown.clone();
        let runner: pdm_engine::manager::ActionRunner = Arc::new(move |a| match a {
            PostAction::Exit => sd2.notify_one(),
            PostAction::Shutdown => system_shutdown(),
            PostAction::None => {}
        });
        let mgr = Manager::new(tokio::runtime::Handle::current(), EngineConfig { resume_on_start: resume, ..EngineConfig::default() }, Some(data_dir().join("manager.json")), runner);
        match server::run_server(&name, shutdown, Some(mgr)).await {
            Ok(()) => ExitCode::SUCCESS,
            Err(e) => {
                eprintln!("pdmd: cannot serve endpoint `{name}`: {e}");
                ExitCode::from(3)
            }
        }
    })
}
