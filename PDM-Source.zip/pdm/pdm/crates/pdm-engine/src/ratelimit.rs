//! Shared token-bucket limiter (bytes/second, 0 = unlimited). One-second burst.
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Mutex;
use std::time::{Duration, Instant};

pub struct RateLimiter {
    rate: AtomicU64,
    state: Mutex<(f64, Instant)>, // (tokens, last refill)
}

impl RateLimiter {
    pub fn new(rate: u64) -> Self {
        RateLimiter { rate: AtomicU64::new(rate), state: Mutex::new((rate as f64, Instant::now())) }
    }

    pub fn rate(&self) -> u64 {
        self.rate.load(Ordering::SeqCst)
    }

    pub fn set_rate(&self, rate: u64) {
        self.rate.store(rate, Ordering::SeqCst);
        let mut g = self.state.lock().unwrap();
        g.0 = rate as f64;
        g.1 = Instant::now();
    }

    /// Debit `n` bytes at time `now`; returns how long the caller must wait.
    pub fn delay_for(&self, n: u64, now: Instant) -> Duration {
        let rate = self.rate();
        if rate == 0 {
            return Duration::ZERO;
        }
        let mut g = self.state.lock().unwrap();
        let dt = now.saturating_duration_since(g.1).as_secs_f64();
        if now > g.1 {
            g.1 = now;
        }
        g.0 = (g.0 + dt * rate as f64).min(rate as f64);
        g.0 -= n as f64;
        if g.0 < 0.0 {
            Duration::from_secs_f64(-g.0 / rate as f64)
        } else {
            Duration::ZERO
        }
    }

    pub async fn acquire(&self, n: u64) {
        let d = self.delay_for(n, Instant::now());
        if !d.is_zero() {
            tokio::time::sleep(d).await;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn unlimited_never_waits() {
        let l = RateLimiter::new(0);
        assert_eq!(l.delay_for(1 << 30, Instant::now()), Duration::ZERO);
    }

    #[test]
    fn burst_then_throttle() {
        let l = RateLimiter::new(1000);
        let t0 = Instant::now();
        assert_eq!(l.delay_for(500, t0), Duration::ZERO);
        let d = l.delay_for(1000, t0); // 500 tokens left, debit 1000 => 500 bytes of debt
        assert!(d >= Duration::from_millis(450) && d <= Duration::from_millis(550), "{d:?}");
    }

    #[test]
    fn refills_over_time_up_to_burst() {
        let l = RateLimiter::new(1000);
        let t0 = Instant::now();
        l.delay_for(1000, t0);
        let d = l.delay_for(0, t0 + Duration::from_secs(10));
        assert_eq!(d, Duration::ZERO);
        // after a long idle the bucket is capped at one second of tokens
        let d = l.delay_for(2000, t0 + Duration::from_secs(10));
        assert!(d >= Duration::from_millis(950) && d <= Duration::from_millis(1050), "{d:?}");
    }

    #[test]
    fn set_rate_changes_behaviour() {
        let l = RateLimiter::new(0);
        l.set_rate(100);
        assert_eq!(l.rate(), 100);
        let t = Instant::now();
        assert!(l.delay_for(300, t) > Duration::from_millis(1500));
    }
}
