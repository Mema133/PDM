//! Local IPC server. Windows: named pipe (supported target). Unix: domain
//! socket, provided only so the protocol tests can run on developer machines.
use crate::manager::Manager;
use crate::session::Session;
use std::io;
use std::sync::Arc;
use std::time::Duration;
use tokio::io::{AsyncRead, AsyncReadExt, AsyncWrite, AsyncWriteExt};
use tokio::sync::{Notify, Semaphore};
use pdm_proto::{encode_error, encode_frame, ErrorCode, FrameDecoder, FrameError};

pub const HANDSHAKE_TIMEOUT: Duration = Duration::from_secs(10);
pub const MAX_CONNECTIONS: usize = 8;
const READ_CHUNK: usize = 8192;

async fn write_body<S: AsyncWrite + Unpin>(s: &mut S, body: &[u8]) -> io::Result<()> {
    let frame = encode_frame(body).map_err(|e| io::Error::new(io::ErrorKind::InvalidData, e))?;
    s.write_all(&frame).await?;
    s.flush().await
}

/// Serve one connection until EOF, protocol violation, or handshake timeout.
/// Reads are event-driven; the only timer runs before the handshake completes.
pub async fn serve_connection<S>(stream: S, shutdown: Arc<Notify>) -> io::Result<()>
where
    S: AsyncRead + AsyncWrite + Unpin,
{
    serve_connection_with(stream, shutdown, None).await
}

pub async fn serve_connection_with<S>(mut stream: S, shutdown: Arc<Notify>, mgr: Option<Arc<Manager>>) -> io::Result<()>
where
    S: AsyncRead + AsyncWrite + Unpin,
{
    let mut session = match mgr {
        Some(m) => Session::with_manager(m),
        None => Session::new(),
    };
    let mut decoder = FrameDecoder::new();
    let mut buf = [0u8; READ_CHUNK];
    loop {
        let n = if session.is_handshaken() {
            stream.read(&mut buf).await?
        } else {
            match tokio::time::timeout(HANDSHAKE_TIMEOUT, stream.read(&mut buf)).await {
                Ok(r) => r?,
                Err(_) => return Ok(()), // no hello in time: drop the client
            }
        };
        if n == 0 {
            return Ok(());
        }
        decoder.push(&buf[..n]);
        loop {
            match decoder.next_frame() {
                Ok(None) => break,
                Ok(Some(body)) => {
                    let out = session.handle_frame(&body);
                    if let Some(reply) = out.reply {
                        write_body(&mut stream, &reply).await?;
                    }
                    if out.shutdown {
                        shutdown.notify_one();
                    }
                    if out.close {
                        let _ = stream.shutdown().await;
                        return Ok(());
                    }
                }
                Err(e) => {
                    let code = match e {
                        FrameError::TooLarge(_) => ErrorCode::TooLarge,
                        FrameError::Empty => ErrorCode::Malformed,
                    };
                    let _ = write_body(&mut stream, &encode_error(None, code, &e.to_string())).await;
                    let _ = stream.shutdown().await;
                    return Ok(());
                }
            }
        }
    }
}

#[cfg(windows)]
pub async fn run_server(name: &str, shutdown: Arc<Notify>, mgr: Option<Arc<Manager>>) -> io::Result<()> {
    use tokio::net::windows::named_pipe::ServerOptions;
    let path = format!(r"\\.\pipe\{name}");
    let limit = Arc::new(Semaphore::new(MAX_CONNECTIONS));
    // first_pipe_instance(true) fails if another daemon already owns the name.
    let mut server = ServerOptions::new()
        .first_pipe_instance(true)
        .reject_remote_clients(true)
        .create(&path)?;
    loop {
        tokio::select! {
            r = server.connect() => { r?; }
            _ = shutdown.notified() => return Ok(()),
        }
        let connected = server;
        server = ServerOptions::new().reject_remote_clients(true).create(&path)?;
        match limit.clone().try_acquire_owned() {
            Ok(permit) => {
                let (sd, mg) = (shutdown.clone(), mgr.clone());
                tokio::spawn(async move {
                    let _permit = permit;
                    let _ = serve_connection_with(connected, sd, mg).await;
                });
            }
            Err(_) => drop(connected),
        }
    }
}

#[cfg(unix)]
pub async fn run_server(name: &str, shutdown: Arc<Notify>, mgr: Option<Arc<Manager>>) -> io::Result<()> {
    use tokio::net::{UnixListener, UnixStream};
    let dir = std::env::var_os("XDG_RUNTIME_DIR").map(std::path::PathBuf::from).unwrap_or_else(std::env::temp_dir);
    let path = dir.join(format!("{name}.sock"));
    if path.exists() {
        if UnixStream::connect(&path).await.is_ok() {
            return Err(io::Error::new(io::ErrorKind::AddrInUse, "another pdmd is already running"));
        }
        let _ = std::fs::remove_file(&path);
    }
    let listener = UnixListener::bind(&path)?;
    let limit = Arc::new(Semaphore::new(MAX_CONNECTIONS));
    let result = loop {
        tokio::select! {
            r = listener.accept() => {
                let (stream, _) = match r { Ok(x) => x, Err(e) => break Err(e) };
                match limit.clone().try_acquire_owned() {
                    Ok(permit) => {
                        let (sd, mg) = (shutdown.clone(), mgr.clone());
                        tokio::spawn(async move {
                            let _permit = permit;
                            let _ = serve_connection_with(stream, sd, mg).await;
                        });
                    }
                    Err(_) => drop(stream),
                }
            }
            _ = shutdown.notified() => break Ok(()),
        }
    };
    let _ = std::fs::remove_file(&path);
    result
}
