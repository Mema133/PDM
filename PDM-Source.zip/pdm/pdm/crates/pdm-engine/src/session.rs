//! Per-connection protocol state machine. Pure logic, no I/O.
use crate::manager::{AddRequest, Manager, PostAction, ProxyUpdate, QueueUpdate};
use serde_json::{json, Map, Value};
use std::path::PathBuf;
use std::sync::Arc;
use std::time::{SystemTime, UNIX_EPOCH};
use pdm_proto::{encode_error, encode_response, parse_request, ErrorCode, PROTOCOL_VERSION};

pub struct Outcome {
    pub reply: Option<Vec<u8>>,
    /// Close the connection after sending `reply`.
    pub close: bool,
    /// Ask the daemon to shut down.
    pub shutdown: bool,
}

#[derive(Default)]
pub struct Session {
    handshaken: bool,
    mgr: Option<Arc<Manager>>,
}

fn opt_str<'a>(p: &'a Map<String, Value>, k: &str) -> Result<Option<&'a str>, String> {
    match p.get(k) {
        None => Ok(None),
        Some(Value::String(s)) if s.len() <= 4096 => Ok(Some(s)),
        Some(_) => Err(format!("`{k}` must be a string")),
    }
}
fn opt_u64(p: &Map<String, Value>, k: &str) -> Result<Option<u64>, String> {
    match p.get(k) {
        None => Ok(None),
        Some(v) => v.as_u64().map(Some).ok_or_else(|| format!("`{k}` must be a non-negative integer")),
    }
}
/// absent -> None, null -> Some(None), integer -> Some(Some(n))
fn opt_nullable_i64(p: &Map<String, Value>, k: &str) -> Result<Option<Option<i64>>, String> {
    match p.get(k) {
        None => Ok(None),
        Some(Value::Null) => Ok(Some(None)),
        Some(v) => v.as_i64().map(|n| Some(Some(n))).ok_or_else(|| format!("`{k}` must be an integer or null")),
    }
}
fn need_id(p: &Map<String, Value>) -> Result<u64, String> {
    opt_u64(p, "id")?.ok_or_else(|| "`id` is required".to_string())
}

fn error(id: Option<&str>, code: ErrorCode, msg: &str, close: bool) -> Outcome {
    Outcome { reply: Some(encode_error(id, code, msg)), close, shutdown: false }
}

fn ok(id: &str, result: Value) -> Outcome {
    Outcome { reply: Some(encode_response(id, result)), close: false, shutdown: false }
}

fn only_keys(params: &Map<String, Value>, allowed: &[&str]) -> bool {
    params.keys().all(|k| allowed.contains(&k.as_str()))
}

impl Session {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn with_manager(m: Arc<Manager>) -> Self {
        Session { handshaken: false, mgr: Some(m) }
    }

    fn handle_manager(&self, id: &str, method: &str, p: &Map<String, Value>) -> Outcome {
        let Some(m) = &self.mgr else {
            return error(Some(id), ErrorCode::UnknownMethod, "download manager not available", false);
        };
        let allowed: &[&str] = match method {
            "downloads.add" => &["url", "dest_dir", "filename", "queue", "sha256", "max_conns", "start", "referer", "cookie"],
            "downloads.list" | "queues.list" | "settings.get" => &[],
            "downloads.pause" | "downloads.resume" | "downloads.cancel" | "downloads.remove" => &["id"],
            "queues.set" => &["name", "max_active", "speed_limit", "start_at", "stop_at", "post_action"],
            "queues.start" | "queues.stop" => &["name"],
            "settings.set" => &["global_speed_limit", "max_conns", "max_total_active", "proxy"],
            _ => return error(Some(id), ErrorCode::UnknownMethod, "unknown method", false),
        };
        if !only_keys(p, allowed) {
            return error(Some(id), ErrorCode::Invalid, "unknown param", false);
        }
        let res: Result<Value, String> = (|| match method {
            "downloads.add" => {
                let url = opt_str(p, "url")?.ok_or("`url` is required")?.to_string();
                let dest = opt_str(p, "dest_dir")?.ok_or("`dest_dir` is required")?;
                let start = match p.get("start") { None => true, Some(Value::Bool(b)) => *b, Some(_) => return Err("`start` must be boolean".into()) };
                let max_conns = opt_u64(p, "max_conns")?.map(|n| n.min(u32::MAX as u64) as u32);
                let id = m.add(AddRequest {
                    url,
                    dest_dir: PathBuf::from(dest),
                    filename: opt_str(p, "filename")?.map(str::to_string),
                    queue: opt_str(p, "queue")?.map(str::to_string),
                    sha256: opt_str(p, "sha256")?.map(str::to_string),
                    max_conns,
                    start,
                    referer: opt_str(p, "referer")?.map(str::to_string),
                    cookie: opt_str(p, "cookie")?.map(str::to_string),
                })?;
                Ok(json!({"id": id}))
            }
            "downloads.list" => {
                let mut all = m.list();
                let truncated = all.len() > 1000;
                all.truncate(1000);
                Ok(json!({"downloads": all, "truncated": truncated}))
            }
            "downloads.pause" => m.pause(need_id(p)?).map(|_| json!({})),
            "downloads.resume" => m.resume(need_id(p)?).map(|_| json!({})),
            "downloads.cancel" => m.cancel(need_id(p)?).map(|_| json!({})),
            "downloads.remove" => m.remove(need_id(p)?).map(|_| json!({})),
            "queues.list" => Ok(json!({"queues": m.list_queues()})),
            "queues.set" => {
                let name = opt_str(p, "name")?.ok_or("`name` is required")?;
                let post = match opt_str(p, "post_action")? {
                    None => None,
                    Some("none") => Some(PostAction::None),
                    Some("exit") => Some(PostAction::Exit),
                    Some("shutdown") => Some(PostAction::Shutdown),
                    Some(_) => return Err("`post_action` must be none, exit or shutdown".into()),
                };
                m.set_queue(name, QueueUpdate {
                    post_action: post,
                    max_active: opt_u64(p, "max_active")?.map(|n| n as usize),
                    speed_limit: opt_u64(p, "speed_limit")?,
                    start_at: opt_nullable_i64(p, "start_at")?,
                    stop_at: opt_nullable_i64(p, "stop_at")?,
                })?;
                Ok(json!({}))
            }
            "queues.start" => m.start_queue(opt_str(p, "name")?.ok_or("`name` is required")?).map(|_| json!({})),
            "queues.stop" => m.stop_queue(opt_str(p, "name")?.ok_or("`name` is required")?).map(|_| json!({})),
            "settings.get" => {
                let st = m.settings();
                let mut v = serde_json::to_value(&st).unwrap_or(Value::Null);
                if let Some(o) = v.get_mut("proxy").and_then(Value::as_object_mut) {
                    o.remove("password"); // never sent back to a client
                    o.insert("has_password".into(), json!(!st.proxy.password.is_empty()));
                }
                Ok(v)
            }
            "settings.set" => {
                m.update_settings(
                    opt_u64(p, "global_speed_limit")?,
                    opt_u64(p, "max_conns")?.map(|n| n.min(u32::MAX as u64) as u32),
                    opt_u64(p, "max_total_active")?.map(|n| n as usize),
                )?;
                if let Some(pv) = p.get("proxy") {
                    let o = pv.as_object().ok_or("`proxy` must be an object")?;
                    if !only_keys(o, &["mode", "kind", "host", "port", "username", "password"]) {
                        return Err("unknown proxy field".into());
                    }
                    let port = match opt_u64(o, "port")? {
                        None => None,
                        Some(n) => Some(u16::try_from(n).map_err(|_| "proxy port must be 1..=65535".to_string())?),
                    };
                    m.set_proxy(ProxyUpdate {
                        mode: opt_str(o, "mode")?.map(str::to_string),
                        kind: opt_str(o, "kind")?.map(str::to_string),
                        host: opt_str(o, "host")?.map(str::to_string),
                        port,
                        username: opt_str(o, "username")?.map(str::to_string),
                        password: opt_str(o, "password")?.map(str::to_string),
                    })?;
                }
                Ok(json!({}))
            }
            _ => Err("unknown method".into()),
        })();
        match res {
            Ok(v) => ok(id, v),
            Err(msg) => error(Some(id), ErrorCode::Invalid, &msg, false),
        }
    }

    pub fn is_handshaken(&self) -> bool {
        self.handshaken
    }

    pub fn handle_frame(&mut self, body: &[u8]) -> Outcome {
        let req = match parse_request(body) {
            Ok(r) => r,
            Err(e) => {
                let close = matches!(e.code, ErrorCode::Malformed | ErrorCode::Version | ErrorCode::TooLarge);
                return error(e.id.as_deref(), e.code, &e.message, close);
            }
        };
        let id = req.id.as_str();
        match (req.method.as_str(), self.handshaken) {
            ("hello", false) => {
                let client_ok = matches!(req.params.get("client"), Some(Value::String(s)) if !s.is_empty() && s.len() <= 64);
                if !client_ok || !only_keys(&req.params, &["client", "capabilities"]) {
                    return error(Some(id), ErrorCode::Invalid, "hello requires `client` (1-64 chars)", false);
                }
                if let Some(c) = req.params.get("capabilities") {
                    let valid = c.as_array().map_or(false, |a| a.len() <= 16 && a.iter().all(Value::is_string));
                    if !valid {
                        return error(Some(id), ErrorCode::Invalid, "`capabilities` must be <=16 strings", false);
                    }
                }
                self.handshaken = true;
                ok(id, json!({
                    "server": "pdmd",
                    "server_version": env!("CARGO_PKG_VERSION"),
                    "protocol": PROTOCOL_VERSION,
                    "capabilities": []
                }))
            }
            ("hello", true) => error(Some(id), ErrorCode::Invalid, "already handshaken", false),
            (_, false) => error(Some(id), ErrorCode::HandshakeRequired, "send `hello` first", false),
            ("app.ping", true) => {
                if !only_keys(&req.params, &["nonce"]) {
                    return error(Some(id), ErrorCode::Invalid, "unknown param", false);
                }
                let nonce = match req.params.get("nonce") {
                    None => Value::Null,
                    Some(Value::String(s)) if s.len() <= 64 => Value::String(s.clone()),
                    Some(_) => return error(Some(id), ErrorCode::Invalid, "`nonce` must be a string <=64 bytes", false),
                };
                let now_ms = SystemTime::now()
                    .duration_since(UNIX_EPOCH)
                    .map(|d| d.as_millis() as u64)
                    .unwrap_or(0);
                ok(id, json!({"pong": true, "nonce": nonce, "server_time_ms": now_ms}))
            }
            ("app.shutdown", true) => {
                let mut o = ok(id, json!({"stopping": true}));
                o.shutdown = true;
                o
            }
            (m, true) if m.starts_with("downloads.") || m.starts_with("queues.") || m.starts_with("settings.") => {
                self.handle_manager(id, m, &req.params)
            }
            _ => error(Some(id), ErrorCode::UnknownMethod, "unknown method", false),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn run(s: &mut Session, body: &str) -> (Value, bool, bool) {
        let o = s.handle_frame(body.as_bytes());
        (serde_json::from_slice(&o.reply.unwrap()).unwrap(), o.close, o.shutdown)
    }
    const HELLO: &str = r#"{"v":1,"id":"h","type":"request","method":"hello","params":{"client":"t"}}"#;

    #[test]
    fn requires_hello_first() {
        let mut s = Session::new();
        let (v, close, _) = run(&mut s, r#"{"v":1,"id":"p","type":"request","method":"app.ping"}"#);
        assert_eq!(v["error"]["code"], "E_HANDSHAKE_REQUIRED");
        assert_eq!(v["id"], "p");
        assert!(!close);
    }

    #[test]
    fn hello_then_ping_echoes_nonce() {
        let mut s = Session::new();
        let (v, _, _) = run(&mut s, HELLO);
        assert_eq!(v["result"]["protocol"], 1);
        assert!(s.is_handshaken());
        let (v, _, _) = run(&mut s, r#"{"v":1,"id":"p","type":"request","method":"app.ping","params":{"nonce":"n1"}}"#);
        assert_eq!(v["type"], "response");
        assert_eq!(v["result"]["pong"], true);
        assert_eq!(v["result"]["nonce"], "n1");
        assert!(v["result"]["server_time_ms"].is_u64());
    }

    #[test]
    fn rejects_second_hello_bad_hello_and_unknown_method() {
        let mut s = Session::new();
        let (v, _, _) = run(&mut s, r#"{"v":1,"id":"h","type":"request","method":"hello","params":{}}"#);
        assert_eq!(v["error"]["code"], "E_INVALID");
        assert!(!s.is_handshaken());
        run(&mut s, HELLO);
        let (v, _, _) = run(&mut s, HELLO);
        assert_eq!(v["error"]["code"], "E_INVALID");
        let (v, _, _) = run(&mut s, r#"{"v":1,"id":"x","type":"request","method":"fs.delete"}"#);
        assert_eq!(v["error"]["code"], "E_UNKNOWN_METHOD");
    }

    #[test]
    fn ping_param_validation() {
        let mut s = Session::new();
        run(&mut s, HELLO);
        let (v, _, _) = run(&mut s, r#"{"v":1,"id":"p","type":"request","method":"app.ping","params":{"nonce":5}}"#);
        assert_eq!(v["error"]["code"], "E_INVALID");
        let long = "a".repeat(65);
        let (v, _, _) = run(&mut s, &format!(r#"{{"v":1,"id":"p","type":"request","method":"app.ping","params":{{"nonce":"{long}"}}}}"#));
        assert_eq!(v["error"]["code"], "E_INVALID");
        let (v, _, _) = run(&mut s, r#"{"v":1,"id":"p","type":"request","method":"app.ping","params":{"other":1}}"#);
        assert_eq!(v["error"]["code"], "E_INVALID");
    }

    #[test]
    fn malformed_and_version_close_connection() {
        let mut s = Session::new();
        let (v, close, _) = run(&mut s, "garbage");
        assert_eq!(v["error"]["code"], "E_MALFORMED");
        assert!(v["id"].is_null());
        assert!(close);
        let (v, close, _) = run(&mut s, r#"{"v":9,"id":"a","type":"request","method":"a.b"}"#);
        assert_eq!(v["error"]["code"], "E_VERSION");
        assert!(close);
    }

    #[test]
    fn shutdown_flag() {
        let mut s = Session::new();
        run(&mut s, HELLO);
        let (v, _, sd) = run(&mut s, r#"{"v":1,"id":"s","type":"request","method":"app.shutdown"}"#);
        assert_eq!(v["result"]["stopping"], true);
        assert!(sd);
    }
}
