//! Engine tests against the deterministic local fixture server.
use std::fs;
use std::sync::Arc;
use std::time::{Duration, Instant};
use tokio::sync::watch;
use pdm_core::ranges::{verify_exact_cover, ByteRange};
use pdm_engine::download::*;
use pdm_engine::fixture::*;
use pdm_engine::ratelimit::RateLimiter;

fn cfg() -> EngineConfig {
    EngineConfig {
        max_conns: 4,
        min_segment: 64 * 1024,
        max_retries: 5,
        backoff_base_ms: 5,
        backoff_max_ms: 50,
        connect_timeout: Duration::from_secs(5),
        request_timeout: Duration::from_secs(5),
        idle_timeout: Duration::from_secs(5),
        state_save_interval: Duration::from_millis(50),
        use_system_proxy: false,
        user_agent: "pdm-test".into(),
        resume_on_start: true,
    }
}

async fn run(cfg: &EngineConfig, job: &Job) -> Result<Outcome, DlError> {
    let (_tx, rx) = watch::channel(Signal::Run);
    run_download(cfg, job, Progress::new(), rx).await
}

fn completed(o: Outcome) -> (std::path::PathBuf, String, bool) {
    match o {
        Outcome::Completed { path, sha256, segmented } => (path, sha256, segmented),
        other => panic!("expected Completed, got {other:?}"),
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn concurrent_range_download_is_exact_and_overlapping() {
    let data = test_data(8 << 20, 1);
    let want = sha256_hex(&data);
    let fx = Fixture::start().await;
    let mut b = Behavior::new(data.clone());
    b.chunk_delay_ms = 4;
    fx.add("/big.bin", b);
    let dir = temp_dir("seg");
    let (path, sha, segmented) = completed(run(&cfg(), &Job::new(fx.url("/big.bin"), &dir)).await.unwrap());
    assert!(segmented);
    assert_eq!(sha, want);
    assert_eq!(fs::read(&path).unwrap(), data);
    assert!(fx.max_concurrency("/big.bin") >= 2, "no overlapping requests observed");
    // Segment requests (everything except the 0-0 probe) must tile the file exactly.
    let ranges: Vec<ByteRange> = fx
        .requests_for("/big.bin")
        .iter()
        .filter(|r| r.status == 206 && r.range != Some((0, 0)))
        .map(|r| {
            let (s, e) = r.range.unwrap();
            ByteRange { start: s, end: e }
        })
        .collect();
    assert!(ranges.len() >= 2);
    verify_exact_cover(data.len() as u64, &ranges).expect("ranges overlap or leave gaps");
    assert!(!dir.join("big.bin.pdmpart").exists());
    assert!(!dir.join("big.bin.pdmpart.json").exists());
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn range_ignored_falls_back_to_single_stream() {
    let data = test_data(1 << 20, 2);
    let fx = Fixture::start().await;
    let mut b = Behavior::new(data.clone());
    b.accept_ranges = false; // advertises ranges but answers 200
    fx.add("/f.bin", b);
    let dir = temp_dir("ign");
    let (path, sha, segmented) = completed(run(&cfg(), &Job::new(fx.url("/f.bin"), &dir)).await.unwrap());
    assert!(!segmented);
    assert_eq!(sha, sha256_hex(&data));
    assert_eq!(fs::read(path).unwrap(), data);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn malformed_content_range_falls_back_safely() {
    let data = test_data(512 << 10, 3);
    let fx = Fixture::start().await;
    let mut b = Behavior::new(data.clone());
    b.bad_content_range = true;
    fx.add("/f.bin", b);
    let dir = temp_dir("badcr");
    // Probe gets a 206 with a shifted range; the plain GET then returns the full body.
    let (path, _, segmented) = completed(run(&cfg(), &Job::new(fx.url("/f.bin"), &dir)).await.unwrap());
    assert!(!segmented);
    assert_eq!(fs::read(path).unwrap(), data);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn unknown_length_single_stream() {
    let data = test_data(300_000, 4);
    let fx = Fixture::start().await;
    let mut b = Behavior::new(data.clone());
    b.accept_ranges = false;
    b.omit_content_length = true;
    fx.add("/u.bin", b);
    let dir = temp_dir("unk");
    let (path, sha, segmented) = completed(run(&cfg(), &Job::new(fx.url("/u.bin"), &dir)).await.unwrap());
    assert!(!segmented);
    assert_eq!(sha, sha256_hex(&data));
    assert_eq!(fs::read(path).unwrap().len(), data.len());
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn transient_503_is_retried() {
    let data = test_data(256 << 10, 5);
    let fx = Fixture::start().await;
    let mut b = Behavior::new(data.clone());
    b.fail_first_n = 2;
    fx.add("/r.bin", b);
    let dir = temp_dir("retry");
    let progress = Progress::new();
    let (_tx, rx) = watch::channel(Signal::Run);
    let out = run_download(&cfg(), &Job::new(fx.url("/r.bin"), &dir), progress.clone(), rx).await.unwrap();
    assert_eq!(fs::read(completed(out).0).unwrap(), data);
    assert!(progress.retries.load(std::sync::atomic::Ordering::SeqCst) >= 2);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn retries_are_bounded() {
    let fx = Fixture::start().await;
    let mut b = Behavior::new(test_data(1000, 6));
    b.fail_first_n = 1000;
    fx.add("/x.bin", b);
    let mut c = cfg();
    c.max_retries = 2;
    let dir = temp_dir("bound");
    let e = run(&c, &Job::new(fx.url("/x.bin"), &dir)).await.unwrap_err();
    assert_eq!(e.status, Some(503));
    assert_eq!(fx.requests_for("/x.bin").len(), 3); // 1 try + 2 retries
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn http_404_is_fatal_without_retry() {
    let fx = Fixture::start().await;
    let dir = temp_dir("404");
    let e = run(&cfg(), &Job::new(fx.url("/missing"), &dir)).await.unwrap_err();
    assert_eq!(e.status, Some(404));
    assert!(!e.retriable);
    assert_eq!(fx.requests_for("/missing").len(), 1);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn truncated_responses_resume_from_offset() {
    let data = test_data(1 << 20, 7);
    let fx = Fixture::start().await;
    let mut b = Behavior::new(data.clone());
    b.truncate_after = Some(100 * 1024);
    b.truncate_times = 3;
    fx.add("/t.bin", b);
    let dir = temp_dir("trunc");
    let progress = Progress::new();
    let (_tx, rx) = watch::channel(Signal::Run);
    let out = run_download(&cfg(), &Job::new(fx.url("/t.bin"), &dir), progress.clone(), rx).await.unwrap();
    let (path, sha, _) = completed(out);
    assert_eq!(sha, sha256_hex(&data));
    assert_eq!(fs::read(path).unwrap(), data);
    assert!(progress.retries.load(std::sync::atomic::Ordering::SeqCst) >= 3);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn changed_etag_midstream_is_detected() {
    let data = test_data(2 << 20, 8);
    let fx = Fixture::start().await;
    let mut b = Behavior::new(data);
    b.flip_etag_after = Some(1); // probe sees v1, every later request sees v2
    fx.add("/c.bin", b);
    let dir = temp_dir("etag");
    let e = run(&cfg(), &Job::new(fx.url("/c.bin"), &dir)).await.unwrap_err();
    assert_eq!(e.kind, ErrKind::ResourceChanged);
    assert!(fs::read_dir(&dir).unwrap().all(|f| !f.unwrap().file_name().to_string_lossy().ends_with(".bin")));
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn wrong_sha256_is_rejected_and_not_finalized() {
    let fx = Fixture::start().await;
    fx.add("/h.bin", Behavior::new(test_data(300_000, 9)));
    let dir = temp_dir("hash");
    let mut job = Job::new(fx.url("/h.bin"), &dir);
    job.expected_sha256 = Some("00".repeat(32));
    let e = run(&cfg(), &job).await.unwrap_err();
    assert_eq!(e.kind, ErrKind::Integrity);
    assert!(!dir.join("h.bin").exists());
    assert!(!dir.join("h.bin.pdmpart").exists());
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn correct_sha256_is_accepted() {
    let data = test_data(300_000, 10);
    let fx = Fixture::start().await;
    fx.add("/h.bin", Behavior::new(data.clone()));
    let dir = temp_dir("hashok");
    let mut job = Job::new(fx.url("/h.bin"), &dir);
    job.expected_sha256 = Some(sha256_hex(&data).to_uppercase());
    completed(run(&cfg(), &job).await.unwrap());
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn cancel_removes_partial_files() {
    let fx = Fixture::start().await;
    let mut b = Behavior::new(test_data(4 << 20, 11));
    b.chunk_delay_ms = 20;
    fx.add("/s.bin", b);
    let dir = temp_dir("cancel");
    let (tx, rx) = watch::channel(Signal::Run);
    let job = Job::new(fx.url("/s.bin"), &dir);
    let c = cfg();
    let h = tokio::spawn(async move { run_download(&c, &job, Progress::new(), rx).await });
    tokio::time::sleep(Duration::from_millis(400)).await;
    tx.send(Signal::Cancel).unwrap();
    assert_eq!(h.await.unwrap().unwrap(), Outcome::Cancelled);
    assert_eq!(fs::read_dir(&dir).unwrap().count(), 0);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn pause_then_resume_reuses_verified_ranges() {
    let data = test_data(4 << 20, 12);
    let fx = Fixture::start().await;
    let mut b = Behavior::new(data.clone());
    b.chunk_delay_ms = 10;
    fx.add("/p.bin", b);
    let dir = temp_dir("pause");
    let job = Job::new(fx.url("/p.bin"), &dir);
    let c = cfg();
    let (tx, rx) = watch::channel(Signal::Run);
    let (j2, c2) = (job.clone(), c.clone());
    let h = tokio::spawn(async move { run_download(&c2, &j2, Progress::new(), rx).await });
    tokio::time::sleep(Duration::from_millis(500)).await;
    tx.send(Signal::Pause).unwrap();
    assert_eq!(h.await.unwrap().unwrap(), Outcome::Paused);

    let st: PartState = serde_json::from_slice(&fs::read(dir.join("p.bin.pdmpart.json")).unwrap()).unwrap();
    let saved: u64 = st.segments.iter().map(|s| s.done).sum();
    assert!(saved > 0 && saved < data.len() as u64, "saved={saved}");

    let progress = Progress::new();
    let (_tx2, rx2) = watch::channel(Signal::Run);
    let out = run_download(&c, &job, progress.clone(), rx2).await.unwrap();
    let (path, sha, _) = completed(out);
    assert_eq!(sha, sha256_hex(&data));
    assert_eq!(fs::read(path).unwrap(), data);
    // Resume must not have re-requested the already saved prefix of each segment.
    let resumed_starts: Vec<u64> = fx.requests_for("/p.bin").iter().skip(st.segments.len() + 1).filter_map(|r| r.range.map(|x| x.0)).collect();
    assert!(resumed_starts.iter().any(|s| st.segments.iter().any(|g| *s > g.start && g.done > 0)), "no resumed offset inside a saved segment");
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn restart_after_abrupt_termination_recovers() {
    let data = test_data(4 << 20, 13);
    let fx = Fixture::start().await;
    let mut b = Behavior::new(data.clone());
    b.chunk_delay_ms = 10;
    fx.add("/k.bin", b);
    let dir = temp_dir("crash");
    let job = Job::new(fx.url("/k.bin"), &dir);
    let c = cfg();
    let (_tx, rx) = watch::channel(Signal::Run);
    let (j2, c2) = (job.clone(), c.clone());
    let h = tokio::spawn(async move { run_download(&c2, &j2, Progress::new(), rx).await });
    tokio::time::sleep(Duration::from_millis(500)).await;
    h.abort(); // simulates the process dying: no pause, no final state save
    let _ = h.await;
    assert!(dir.join("k.bin.pdmpart").exists());
    let (path, sha, _) = completed(run(&c, &job).await.unwrap());
    assert_eq!(sha, sha256_hex(&data));
    assert_eq!(fs::read(path).unwrap(), data);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn stale_partial_for_changed_resource_is_discarded() {
    let old = test_data(2 << 20, 14);
    let new = test_data(2 << 20, 15);
    let fx = Fixture::start().await;
    let mut b = Behavior::new(old);
    b.chunk_delay_ms = 10;
    fx.add("/v.bin", b);
    let dir = temp_dir("stale");
    let job = Job::new(fx.url("/v.bin"), &dir);
    let c = cfg();
    let (tx, rx) = watch::channel(Signal::Run);
    let (j2, c2) = (job.clone(), c.clone());
    let h = tokio::spawn(async move { run_download(&c2, &j2, Progress::new(), rx).await });
    tokio::time::sleep(Duration::from_millis(300)).await;
    tx.send(Signal::Pause).unwrap();
    assert_eq!(h.await.unwrap().unwrap(), Outcome::Paused);
    // The server now serves different content under a different validator.
    let mut b2 = Behavior::new(new.clone());
    b2.etag = Some("\"other\"".into());
    fx.add("/v.bin", b2);
    let (path, sha, _) = completed(run(&c, &job).await.unwrap());
    assert_eq!(sha, sha256_hex(&new));
    assert_eq!(fs::read(path).unwrap(), new);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn bandwidth_limit_is_enforced() {
    let data = test_data(512 << 10, 16);
    let fx = Fixture::start().await;
    fx.add("/l.bin", Behavior::new(data));
    let dir = temp_dir("limit");
    let mut job = Job::new(fx.url("/l.bin"), &dir);
    job.limiters = vec![Arc::new(RateLimiter::new(256 * 1024))]; // 256 KiB/s, 1 s burst
    let t = Instant::now();
    completed(run(&cfg(), &job).await.unwrap());
    let el = t.elapsed();
    assert!(el >= Duration::from_millis(800), "finished too fast for the limit: {el:?}");
    assert!(el < Duration::from_secs(10), "too slow: {el:?}");
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn existing_file_is_never_overwritten() {
    let data = test_data(100_000, 17);
    let fx = Fixture::start().await;
    fx.add("/e.bin", Behavior::new(data.clone()));
    let dir = temp_dir("exists");
    fs::write(dir.join("e.bin"), b"precious").unwrap();
    let (path, _, _) = completed(run(&cfg(), &Job::new(fx.url("/e.bin"), &dir)).await.unwrap());
    assert_eq!(path.file_name().unwrap().to_string_lossy(), "e (1).bin");
    assert_eq!(fs::read(dir.join("e.bin")).unwrap(), b"precious");
    assert_eq!(fs::read(path).unwrap(), data);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn content_disposition_filename_is_sanitized() {
    let fx = Fixture::start().await;
    let mut b = Behavior::new(test_data(50_000, 18));
    b.content_disposition = Some("attachment; filename=\"..\\..\\evil.txt\"".into());
    fx.add("/d", b);
    let dir = temp_dir("cd");
    let (path, _, _) = completed(run(&cfg(), &Job::new(fx.url("/d"), &dir)).await.unwrap());
    assert_eq!(path.parent().unwrap(), dir.as_path());
    assert_eq!(path.file_name().unwrap().to_string_lossy(), "evil.txt");
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn redirects_are_followed() {
    let data = test_data(80_000, 19);
    let fx = Fixture::start().await;
    fx.add("/final.bin", Behavior::new(data.clone()));
    let mut r = Behavior::new(vec![]);
    r.redirect_to = Some(fx.url("/final.bin"));
    fx.add("/go", r);
    let dir = temp_dir("redir");
    let (path, _, _) = completed(run(&cfg(), &Job::new(fx.url("/go"), &dir)).await.unwrap());
    assert_eq!(fs::read(path).unwrap(), data);
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn hls_master_picks_best_variant_and_joins_segments_in_order() {
    let fx = Fixture::start().await;
    let segs: Vec<Vec<u8>> = (0..7u64).map(|i| test_data(70_000 + i as usize, 20 + i)).collect();
    for (i, s) in segs.iter().enumerate() {
        fx.add(&format!("/hi/s{i}.ts"), Behavior::new(s.clone()));
    }
    fx.add("/lo/s0.ts", Behavior::new(vec![1, 2, 3]));
    let master = "#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=300000,RESOLUTION=640x360\nlo/p.m3u8\n#EXT-X-STREAM-INF:BANDWIDTH=900000,RESOLUTION=1280x720\nhi/p.m3u8\n";
    let mut media = String::from("#EXTM3U\n#EXT-X-TARGETDURATION:4\n");
    for i in 0..segs.len() {
        media.push_str(&format!("#EXTINF:4.0,\ns{i}.ts\n"));
    }
    media.push_str("#EXT-X-ENDLIST\n");
    fx.add("/movie.m3u8", Behavior::new(master.as_bytes().to_vec()));
    fx.add("/hi/p.m3u8", Behavior::new(media.into_bytes()));
    fx.add("/lo/p.m3u8", Behavior::new(b"#EXTM3U\n#EXTINF:4,\ns0.ts\n#EXT-X-ENDLIST\n".to_vec()));
    let dir = temp_dir("hls");
    let (path, _sha, _) = completed(run(&cfg(), &Job::new(fx.url("/movie.m3u8"), &dir)).await.unwrap());
    assert_eq!(path.file_name().unwrap().to_string_lossy(), "movie.ts");
    assert_eq!(fs::read(&path).unwrap(), segs.concat());
    assert!(!dir.join("movie.ts.pdmpart").exists());
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn hls_live_and_encrypted_playlists_are_rejected_not_hung() {
    let fx = Fixture::start().await;
    fx.add("/live.m3u8", Behavior::new(b"#EXTM3U\n#EXTINF:4,\na.ts\n".to_vec()));
    fx.add("/enc.m3u8", Behavior::new(b"#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI=\"k\"\n#EXTINF:4,\na.ts\n#EXT-X-ENDLIST\n".to_vec()));
    let dir = temp_dir("hls-bad");
    for p in ["/live.m3u8", "/enc.m3u8"] {
        let e = run(&cfg(), &Job::new(fx.url(p), &dir)).await.unwrap_err();
        assert!(!e.retriable, "{p}: {}", e.msg);
    }
}
