//! End-to-end over the IPC protocol: add a download via `downloads.add`, poll `downloads.list`.
use serde_json::{json, Value};
use std::sync::Arc;
use std::time::{Duration, Instant};
use tokio::io::{duplex, AsyncReadExt, AsyncWriteExt, DuplexStream};
use tokio::sync::Notify;
use pdm_engine::download::EngineConfig;
use pdm_engine::fixture::*;
use pdm_engine::manager::{Manager, PostAction};
use pdm_engine::server::serve_connection_with;
use pdm_proto::encode_frame;

async fn call(c: &mut DuplexStream, id: &str, method: &str, params: Value) -> Value {
    let body = json!({"v":1,"id":id,"type":"request","method":method,"params":params}).to_string();
    c.write_all(&encode_frame(body.as_bytes()).unwrap()).await.unwrap();
    let mut hdr = [0u8; 4];
    c.read_exact(&mut hdr).await.unwrap();
    let mut buf = vec![0u8; u32::from_le_bytes(hdr) as usize];
    c.read_exact(&mut buf).await.unwrap();
    serde_json::from_slice(&buf).unwrap()
}

fn start() -> (DuplexStream, Arc<Manager>) {
    let cfg = EngineConfig { use_system_proxy: false, min_segment: 64 * 1024, ..EngineConfig::default() };
    let m = Manager::new(tokio::runtime::Handle::current(), cfg, None, Arc::new(|_: PostAction| {}));
    let (client, server) = duplex(1 << 20);
    tokio::spawn(serve_connection_with(server, Arc::new(Notify::new()), Some(m.clone())));
    (client, m)
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn add_list_complete_over_ipc() {
    let data = test_data(2 << 20, 77);
    let fx = Fixture::start().await;
    fx.add("/a.bin", Behavior::new(data.clone()));
    let dir = temp_dir("ipc");
    let (mut c, _m) = start();
    assert!(call(&mut c, "h", "hello", json!({"client":"t"})).await["result"].is_object());
    let r = call(&mut c, "a", "downloads.add", json!({"url": fx.url("/a.bin"), "dest_dir": dir.to_string_lossy()})).await;
    let id = r["result"]["id"].as_u64().unwrap_or_else(|| panic!("add failed: {r}"));
    let t = Instant::now();
    loop {
        let l = call(&mut c, "l", "downloads.list", json!({})).await;
        let d = l["result"]["downloads"].as_array().unwrap().iter().find(|d| d["id"] == id).unwrap().clone();
        if d["status"] == "completed" {
            assert_eq!(d["sha256"], pdm_engine::download::sha256_hex(&data));
            assert_eq!(std::fs::read(d["final_path"].as_str().unwrap()).unwrap(), data);
            break;
        }
        assert_ne!(d["status"], "failed", "{d}");
        assert!(t.elapsed() < Duration::from_secs(30));
        tokio::time::sleep(Duration::from_millis(20)).await;
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn ipc_rejects_bad_params() {
    let (mut c, _m) = start();
    call(&mut c, "h", "hello", json!({"client":"t"})).await;
    for (method, params) in [
        ("downloads.add", json!({"url":"ftp://x/y","dest_dir":"/tmp"})),
        ("downloads.add", json!({"url":"http://x/y"})),
        ("downloads.add", json!({"url":"http://x/y","dest_dir":"/tmp","extra":1})),
        ("downloads.add", json!({"url": 5, "dest_dir":"/tmp"})),
        ("downloads.pause", json!({})),
        ("downloads.pause", json!({"id":"x"})),
        ("downloads.pause", json!({"id": 99999})),
        ("queues.set", json!({"name":"q","post_action":"explode"})),
        ("queues.set", json!({"name":"default","post_action":"shutdown"})),
        ("settings.set", json!({"post_action":"exit"})),
        ("queues.set", json!({"name":"../evil"})),
        ("queues.set", json!({"name":"q","max_active":0})),
    ] {
        let r = call(&mut c, "x", method, params.clone()).await;
        assert_eq!(r["error"]["code"], "E_INVALID", "{method} {params} -> {r}");
    }
    let r = call(&mut c, "y", "shell.exec", json!({})).await;
    assert_eq!(r["error"]["code"], "E_UNKNOWN_METHOD");
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn settings_roundtrip_over_ipc() {
    let (mut c, _m) = start();
    call(&mut c, "h", "hello", json!({"client":"t"})).await;
    let r = call(&mut c, "s", "settings.set", json!({"global_speed_limit": 1048576, "max_conns": 6})).await;
    assert!(r["result"].is_object(), "{r}");
    let r = call(&mut c, "g", "settings.get", json!({})).await;
    assert_eq!(r["result"]["global_speed_limit"], 1048576);
    assert_eq!(r["result"]["max_conns"], 6);
    assert!(r["result"].get("post_action").is_none(), "post_action is per queue now");
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn queue_post_action_roundtrip_over_ipc() {
    let (mut c, _m) = start();
    call(&mut c, "h", "hello", json!({"client":"t"})).await;
    let r = call(&mut c, "s", "queues.set", json!({"name":"night","post_action":"shutdown"})).await;
    assert!(r["result"].is_object(), "{r}");
    let r = call(&mut c, "l", "queues.list", json!({})).await;
    let q = r["result"]["queues"].as_array().unwrap().iter().find(|q| q["name"] == "night").unwrap().clone();
    assert_eq!(q["post_action"], "shutdown");
    let d = r["result"]["queues"].as_array().unwrap().iter().find(|q| q["name"] == "default").unwrap().clone();
    assert_eq!(d["post_action"], "none");
}
