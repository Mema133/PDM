//! Transport-independent protocol tests using in-memory duplex streams.
use serde_json::Value;
use std::sync::Arc;
use std::time::Duration;
use tokio::io::{duplex, AsyncReadExt, AsyncWriteExt, DuplexStream};
use tokio::sync::Notify;
use pdm_engine::server::serve_connection;
use pdm_proto::{encode_frame, MAX_FRAME_BYTES};

fn start() -> (DuplexStream, Arc<Notify>, tokio::task::JoinHandle<std::io::Result<()>>) {
    let (client, server) = duplex(64 * 1024);
    let sd = Arc::new(Notify::new());
    let h = tokio::spawn(serve_connection(server, sd.clone()));
    (client, sd, h)
}

async fn send(c: &mut DuplexStream, body: &str) {
    c.write_all(&encode_frame(body.as_bytes()).unwrap()).await.unwrap();
}

/// Returns None on EOF.
async fn recv(c: &mut DuplexStream) -> Option<Value> {
    let mut hdr = [0u8; 4];
    if c.read_exact(&mut hdr).await.is_err() {
        return None;
    }
    let mut body = vec![0u8; u32::from_le_bytes(hdr) as usize];
    c.read_exact(&mut body).await.ok()?;
    Some(serde_json::from_slice(&body).unwrap())
}

const HELLO: &str = r#"{"v":1,"id":"h","type":"request","method":"hello","params":{"client":"test"}}"#;
const PING: &str = r#"{"v":1,"id":"p1","type":"request","method":"app.ping","params":{"nonce":"abc"}}"#;

#[tokio::test]
async fn ping_round_trip() {
    let (mut c, _sd, _h) = start();
    send(&mut c, HELLO).await;
    assert_eq!(recv(&mut c).await.unwrap()["result"]["server"], "pdmd");
    send(&mut c, PING).await;
    let r = recv(&mut c).await.unwrap();
    assert_eq!(r["id"], "p1");
    assert_eq!(r["result"]["pong"], true);
    assert_eq!(r["result"]["nonce"], "abc");
}

#[tokio::test]
async fn ping_before_hello_is_refused_but_connection_survives() {
    let (mut c, _sd, _h) = start();
    send(&mut c, PING).await;
    assert_eq!(recv(&mut c).await.unwrap()["error"]["code"], "E_HANDSHAKE_REQUIRED");
    send(&mut c, HELLO).await;
    assert!(recv(&mut c).await.unwrap()["result"].is_object());
}

#[tokio::test]
async fn fragmented_bytes_are_reassembled() {
    let (mut c, _sd, _h) = start();
    let mut bytes = encode_frame(HELLO.as_bytes()).unwrap();
    bytes.extend(encode_frame(PING.as_bytes()).unwrap());
    for b in bytes {
        c.write_all(&[b]).await.unwrap();
    }
    assert!(recv(&mut c).await.unwrap()["result"]["server"] == "pdmd");
    assert_eq!(recv(&mut c).await.unwrap()["result"]["nonce"], "abc");
}

#[tokio::test]
async fn pipelined_requests_get_ordered_replies() {
    let (mut c, _sd, _h) = start();
    send(&mut c, HELLO).await;
    for i in 0..20 {
        send(&mut c, &format!(r#"{{"v":1,"id":"r{i}","type":"request","method":"app.ping"}}"#)).await;
    }
    recv(&mut c).await.unwrap();
    for i in 0..20 {
        assert_eq!(recv(&mut c).await.unwrap()["id"], format!("r{i}"));
    }
}

#[tokio::test]
async fn malformed_json_gets_error_then_close() {
    let (mut c, _sd, h) = start();
    send(&mut c, "not json at all").await;
    let r = recv(&mut c).await.unwrap();
    assert_eq!(r["error"]["code"], "E_MALFORMED");
    assert!(r["id"].is_null());
    assert!(recv(&mut c).await.is_none());
    h.await.unwrap().unwrap();
}

#[tokio::test]
async fn oversize_frame_header_is_rejected_without_buffering() {
    let (mut c, _sd, h) = start();
    c.write_all(&((MAX_FRAME_BYTES as u32 + 1).to_le_bytes())).await.unwrap();
    assert_eq!(recv(&mut c).await.unwrap()["error"]["code"], "E_TOO_LARGE");
    assert!(recv(&mut c).await.is_none());
    h.await.unwrap().unwrap();
}

#[tokio::test]
async fn zero_length_frame_is_rejected() {
    let (mut c, _sd, h) = start();
    c.write_all(&[0, 0, 0, 0]).await.unwrap();
    assert_eq!(recv(&mut c).await.unwrap()["error"]["code"], "E_MALFORMED");
    h.await.unwrap().unwrap();
}

#[tokio::test]
async fn version_mismatch_closes() {
    let (mut c, _sd, h) = start();
    send(&mut c, r#"{"v":2,"id":"a","type":"request","method":"hello","params":{"client":"t"}}"#).await;
    let r = recv(&mut c).await.unwrap();
    assert_eq!(r["error"]["code"], "E_VERSION");
    assert_eq!(r["id"], "a");
    assert!(recv(&mut c).await.is_none());
    h.await.unwrap().unwrap();
}

#[tokio::test]
async fn shutdown_request_notifies_daemon() {
    let (mut c, sd, _h) = start();
    send(&mut c, HELLO).await;
    recv(&mut c).await.unwrap();
    send(&mut c, r#"{"v":1,"id":"s","type":"request","method":"app.shutdown"}"#).await;
    assert_eq!(recv(&mut c).await.unwrap()["result"]["stopping"], true);
    tokio::time::timeout(Duration::from_secs(1), sd.notified()).await.expect("shutdown not signalled");
}

#[tokio::test(start_paused = true)]
async fn silent_client_is_dropped_after_handshake_timeout() {
    let (_c, _sd, h) = start();
    // With paused time the runtime auto-advances while all tasks are idle.
    h.await.unwrap().unwrap();
}

#[tokio::test]
async fn client_disconnect_ends_task() {
    let (c, _sd, h) = start();
    drop(c);
    h.await.unwrap().unwrap();
}
