//! Real named-pipe round trip. Windows only.
#![cfg(windows)]
use std::sync::Arc;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::windows::named_pipe::ClientOptions;
use tokio::sync::Notify;
use pdm_engine::server::run_server;
use pdm_proto::encode_frame;

#[tokio::test]
async fn named_pipe_ping() {
    let name = format!("pdm-test-{}", std::process::id());
    let sd = Arc::new(Notify::new());
    let server = tokio::spawn(run_server_owned(name.clone(), sd.clone()));
    let path = format!(r"\\.\pipe\{name}");
    let mut client = loop {
        match ClientOptions::new().open(&path) {
            Ok(c) => break c,
            Err(_) => tokio::time::sleep(std::time::Duration::from_millis(20)).await,
        }
    };
    for body in [
        r#"{"v":1,"id":"h","type":"request","method":"hello","params":{"client":"t"}}"#,
        r#"{"v":1,"id":"p","type":"request","method":"app.ping","params":{"nonce":"z"}}"#,
    ] {
        client.write_all(&encode_frame(body.as_bytes()).unwrap()).await.unwrap();
        let mut hdr = [0u8; 4];
        client.read_exact(&mut hdr).await.unwrap();
        let mut buf = vec![0u8; u32::from_le_bytes(hdr) as usize];
        client.read_exact(&mut buf).await.unwrap();
        let v: serde_json::Value = serde_json::from_slice(&buf).unwrap();
        assert_eq!(v["type"], "response");
        if v["id"] == "p" {
            assert_eq!(v["result"]["nonce"], "z");
        }
    }
    // A second daemon on the same name must refuse to start.
    assert!(run_server(&name, Arc::new(Notify::new()), None).await.is_err());
    sd.notify_one();
    server.await.unwrap().unwrap();
}

async fn run_server_owned(name: String, sd: Arc<Notify>) -> std::io::Result<()> {
    run_server(&name, sd, None).await
}
