//! pdm-host: Chrome/Edge Native Messaging bridge to the pdmd named pipe.
//! Browser <-> stdin/stdout (4-byte LE length + JSON); engine <-> pipe (pdm-proto frames).
//! `pdm-host --install` registers the host for the PDM extension (HKCU, no admin needed).
use pdm_proto::{encode_frame, FrameDecoder};
use serde_json::{json, Value};
use std::fs::{File, OpenOptions};
use std::io::{self, Read, Write};
use std::process::{Command, Stdio};
use std::time::{Duration, Instant};

/// Fixed by the `key` in extension/manifest.json.
const EXTENSION_ID: &str = "jjondcpienpijobdhkidnjmfgjcpopoo";
const HOST_NAME: &str = "com.pdm.host";
const MAX_IN: usize = 16 << 20;

fn read_native(r: &mut impl Read) -> io::Result<Option<Vec<u8>>> {
    let mut h = [0u8; 4];
    if let Err(e) = r.read_exact(&mut h) {
        return if e.kind() == io::ErrorKind::UnexpectedEof { Ok(None) } else { Err(e) };
    }
    let n = u32::from_le_bytes(h) as usize;
    if n == 0 || n > MAX_IN {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "bad message length"));
    }
    let mut b = vec![0u8; n];
    r.read_exact(&mut b)?;
    Ok(Some(b))
}

fn write_native(w: &mut impl Write, v: &Value) -> io::Result<()> {
    let b = serde_json::to_vec(v).unwrap_or_default();
    w.write_all(&(b.len() as u32).to_le_bytes())?;
    w.write_all(&b)?;
    w.flush()
}

fn valid_url(u: &str) -> bool {
    u.len() <= 4096 && (u.starts_with("http://") || u.starts_with("https://"))
}

fn open_pipe(start_engine: bool) -> io::Result<File> {
    let path = format!(r"\\.\pipe\{}", pdm_engine::endpoint::default_endpoint_name());
    let open = || OpenOptions::new().read(true).write(true).open(&path);
    if let Ok(f) = open() {
        return Ok(f);
    }
    if !start_engine {
        return open();
    }
    // Engine not running and the user asked for a download: start it from our own folder, then wait for the pipe.
    let exe = std::env::current_exe()?.with_file_name("pdmd.exe");
    spawn_detached(&exe)?;
    let deadline = Instant::now() + Duration::from_secs(6);
    loop {
        match open() {
            Ok(f) => return Ok(f),
            Err(e) if Instant::now() >= deadline => return Err(e),
            Err(_) => std::thread::sleep(Duration::from_millis(100)),
        }
    }
}

#[cfg(windows)]
fn spawn_detached(exe: &std::path::Path) -> io::Result<()> {
    use std::os::windows::process::CommandExt;
    // DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP, first with CREATE_BREAKAWAY_FROM_JOB so the
    // browser's job object cannot kill the engine; retry without it if the job forbids breakaway.
    let go = |flags: u32| Command::new(exe).stdin(Stdio::null()).stdout(Stdio::null()).stderr(Stdio::null()).creation_flags(flags).spawn();
    go(0x0100_0208).or_else(|_| go(0x208)).map(|_| ())
}
#[cfg(not(windows))]
fn spawn_detached(exe: &std::path::Path) -> io::Result<()> {
    Command::new(exe).stdin(Stdio::null()).stdout(Stdio::null()).stderr(Stdio::null()).spawn().map(|_| ())
}

struct Engine {
    pipe: File,
    dec: FrameDecoder,
    n: u32,
}

impl Engine {
    fn connect(start_engine: bool) -> Result<Engine, String> {
        let pipe = open_pipe(start_engine).map_err(|e| format!("cannot reach the PDM engine: {e}"))?;
        let mut e = Engine { pipe, dec: FrameDecoder::new(), n: 0 };
        e.call("hello", json!({"client": "pdm-host/0.1.0"}))?;
        Ok(e)
    }

    fn call(&mut self, method: &str, params: Value) -> Result<Value, String> {
        self.n += 1;
        let body = json!({"v": 1, "id": format!("h{}", self.n), "type": "request", "method": method, "params": params});
        let frame = encode_frame(&serde_json::to_vec(&body).unwrap_or_default()).map_err(|e| e.to_string())?;
        self.pipe.write_all(&frame).map_err(|e| e.to_string())?;
        let mut buf = [0u8; 8192];
        loop {
            if let Some(b) = self.dec.next_frame().map_err(|e| e.to_string())? {
                let v: Value = serde_json::from_slice(&b).map_err(|e| e.to_string())?;
                return if v["type"] == "response" {
                    Ok(v["result"].clone())
                } else {
                    Err(v["error"]["message"].as_str().unwrap_or("engine error").to_string())
                };
            }
            let n = self.pipe.read(&mut buf).map_err(|e| e.to_string())?;
            if n == 0 {
                return Err("engine closed the connection".into());
            }
            self.dec.push(&buf[..n]);
        }
    }
}

fn download_dir() -> String {
    let home = std::env::var("USERPROFILE").or_else(|_| std::env::var("HOME")).unwrap_or_default();
    std::env::var("PDM_DOWNLOAD_DIR").unwrap_or_else(|_| format!("{home}\\Downloads"))
}

/// Drops one request file for the UI's confirmation dialog. The UI reads only *.json, never a half-written file.
fn write_pending(dir: &std::path::Path, req: &Value) -> io::Result<()> {
    std::fs::create_dir_all(dir)?;
    let stamp = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_nanos()).unwrap_or(0);
    let tmp = dir.join(format!("{stamp}.tmp"));
    std::fs::write(&tmp, serde_json::to_vec(req).unwrap_or_default())?;
    std::fs::rename(&tmp, dir.join(format!("{stamp}.json")))
}

/// Hands one request to the PDM window instead of starting it blindly: leaves a request file, then starts pdm.exe.
/// A second pdm.exe just brings the running window to the front.
fn propose(req: &Value) -> io::Result<()> {
    let dir = std::path::PathBuf::from(std::env::var("APPDATA").unwrap_or_default()).join("PDM").join("pending");
    write_pending(&dir, req)?;
    spawn_detached(&std::env::current_exe()?.with_file_name("pdm.exe"))
}

/// {"action":"add","urls":[..],"referer":"https://page","name":"file.mp4","cookie":"a=1; b=2","cookie_map":{url:"a=1"},
///  "ytdlp":true,"cookies":"<cookies.txt>"} -> {"ok":bool,"added":n,"error":".."}   (also {"action":"ping"})
/// One URL waits for the user's confirmation in PDM; several (already chosen in the link grabber) start right away.
/// `cookie` / `cookie_map` are the browser's session for the URL(s), sent as the Cookie header by the engine;
/// `cookies` (Netscape format) is for yt-dlp.
fn handle(msg: &Value) -> Value {
    let act = msg["action"].as_str().unwrap_or("");
    if act == "ping" {
        // A ping must never launch the engine (it would wake a stale queue): just report whether it is up.
        return json!({"ok": true, "engine": Engine::connect(false).is_ok()});
    }
    if act != "add" {
        return json!({"ok": false, "error": "unknown action"});
    }
    let urls: Vec<&str> = msg["urls"].as_array().map(|a| a.iter().filter_map(Value::as_str).filter(|u| valid_url(u)).collect()).unwrap_or_default();
    let referer = msg["referer"].as_str().filter(|r| valid_url(r));
    let small = |v: &Value| v.as_str().filter(|c| c.len() <= 32768 && !c.is_empty()).map(str::to_string);
    if let [one] = urls.as_slice() {
        let req = json!({
            "url": one, "referer": referer, "name": msg["name"].as_str().filter(|n| n.len() <= 255),
            "ytdlp": msg["ytdlp"].as_bool().unwrap_or(false), "cookie": small(&msg["cookie"]),
            "source": msg["source"].as_str().filter(|s| s.len() <= 16), // which extension feature sent it, shown in the window
            "cookies": msg["cookies"].as_str().filter(|c| c.len() <= 2_000_000),
        });
        return match propose(&req) {
            Ok(()) => json!({"ok": true, "added": 1}),
            Err(e) => json!({"ok": false, "error": format!("cannot reach PDM: {e}")}),
        };
    }
    let mut eng = match Engine::connect(true) {
        Ok(e) => e,
        Err(e) => return json!({"ok": false, "error": e}),
    };
    let dir = download_dir();
    let (mut added, mut err) = (0, None);
    for u in urls {
        let mut params = json!({"url": u, "dest_dir": dir, "start": true});
        if let Some(r) = referer {
            params["referer"] = json!(r);
        }
        if let Some(c) = small(&msg["cookie_map"][u]) {
            params["cookie"] = json!(c);
        }
        match eng.call("downloads.add", params) {
            Ok(_) => added += 1,
            Err(e) => err = Some(e),
        }
    }
    json!({"ok": added > 0 && err.is_none(), "added": added, "error": err})
}

fn install() -> io::Result<()> {
    let exe = std::env::current_exe()?;
    let manifest = exe.with_file_name(format!("{HOST_NAME}.json"));
    let m = json!({
        "name": HOST_NAME, "description": "PDM native host", "path": exe, "type": "stdio",
        "allowed_origins": [format!("chrome-extension://{EXTENSION_ID}/")]
    });
    std::fs::write(&manifest, serde_json::to_vec_pretty(&m).unwrap_or_default())?;
    for base in [r"Software\Google\Chrome", r"Software\Microsoft\Edge", r"Software\BraveSoftware\Brave-Browser"] {
        let key = format!(r"HKCU\{base}\NativeMessagingHosts\{HOST_NAME}");
        let st = Command::new("reg").args(["add", &key, "/ve", "/t", "REG_SZ", "/d"]).arg(&manifest).arg("/f").stdout(Stdio::null()).status()?;
        if !st.success() {
            return Err(io::Error::new(io::ErrorKind::Other, format!("reg add failed for {key}")));
        }
    }
    Ok(())
}

fn main() {
    if std::env::args().any(|a| a == "--install") {
        if let Err(e) = install() {
            eprintln!("pdm-host: {e}");
            std::process::exit(1);
        }
        return;
    }
    let (mut i, mut o) = (io::stdin().lock(), io::stdout().lock());
    // One message in, one reply out; Chrome closes stdin when the port goes away.
    while let Ok(Some(b)) = read_native(&mut i) {
        let reply = match serde_json::from_slice::<Value>(&b) {
            Ok(v) => handle(&v),
            Err(_) => json!({"ok": false, "error": "bad message"}),
        };
        if write_native(&mut o, &reply).is_err() {
            break;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Cursor;

    #[test]
    fn native_framing_roundtrip_and_limits() {
        let mut out = Vec::new();
        write_native(&mut out, &json!({"a": 1})).unwrap();
        let got = read_native(&mut Cursor::new(out)).unwrap().unwrap();
        assert_eq!(serde_json::from_slice::<Value>(&got).unwrap()["a"], 1);
        assert!(read_native(&mut Cursor::new(Vec::new())).unwrap().is_none());
        assert!(read_native(&mut Cursor::new(vec![0, 0, 0, 0])).is_err());
        assert!(read_native(&mut Cursor::new(((MAX_IN + 1) as u32).to_le_bytes().to_vec())).is_err());
    }

    #[test]
    fn pending_request_is_a_complete_json_file() {
        let dir = std::env::temp_dir().join(format!("pdm-host-test-{}", std::process::id()));
        write_pending(&dir, &json!({"url": "https://a.b/c.zip", "referer": "https://a.b/", "name": null})).unwrap();
        let names: Vec<_> = std::fs::read_dir(&dir).unwrap().map(|e| e.unwrap().path()).collect();
        assert_eq!(names.len(), 1);
        assert_eq!(names[0].extension().unwrap(), "json");
        let v: Value = serde_json::from_slice(&std::fs::read(&names[0]).unwrap()).unwrap();
        assert_eq!((v["url"].as_str(), v["referer"].as_str(), v["name"].is_null()), (Some("https://a.b/c.zip"), Some("https://a.b/"), true));
        std::fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn only_http_urls_pass() {
        assert!(valid_url("https://a.b/c"));
        assert!(!valid_url("file:///C:/x"));
        assert!(!valid_url("javascript:alert(1)"));
        assert!(!valid_url(&format!("https://{}", "a".repeat(5000))));
    }
}
