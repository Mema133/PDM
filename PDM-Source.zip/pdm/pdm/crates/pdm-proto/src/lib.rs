//! PDM IPC protocol v1: length-prefixed framing and envelope validation.
//!
//! This crate performs no I/O. Frames are a 4-byte little-endian length
//! followed by a UTF-8 JSON body (1..=MAX_FRAME_BYTES bytes).

use serde_json::{json, Map, Value};
use std::fmt;

pub const PROTOCOL_VERSION: u64 = 1;
pub const HEADER_LEN: usize = 4;
pub const MAX_FRAME_BYTES: usize = 1 << 20;
pub const MAX_ID_LEN: usize = 64;
pub const MAX_METHOD_LEN: usize = 64;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ErrorCode {
    Malformed,
    Invalid,
    Version,
    HandshakeRequired,
    UnknownMethod,
    TooLarge,
    Internal,
}

impl ErrorCode {
    pub fn as_str(self) -> &'static str {
        match self {
            ErrorCode::Malformed => "E_MALFORMED",
            ErrorCode::Invalid => "E_INVALID",
            ErrorCode::Version => "E_VERSION",
            ErrorCode::HandshakeRequired => "E_HANDSHAKE_REQUIRED",
            ErrorCode::UnknownMethod => "E_UNKNOWN_METHOD",
            ErrorCode::TooLarge => "E_TOO_LARGE",
            ErrorCode::Internal => "E_INTERNAL",
        }
    }

    /// Parse a wire code (used by golden-file tests).
    pub fn from_wire(s: &str) -> Option<ErrorCode> {
        Some(match s {
            "E_MALFORMED" => ErrorCode::Malformed,
            "E_INVALID" => ErrorCode::Invalid,
            "E_VERSION" => ErrorCode::Version,
            "E_HANDSHAKE_REQUIRED" => ErrorCode::HandshakeRequired,
            "E_UNKNOWN_METHOD" => ErrorCode::UnknownMethod,
            "E_TOO_LARGE" => ErrorCode::TooLarge,
            "E_INTERNAL" => ErrorCode::Internal,
            _ => return None,
        })
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ProtoError {
    pub code: ErrorCode,
    pub message: String,
    /// Request id, when one could be recovered safely from the bad envelope.
    pub id: Option<String>,
}

impl ProtoError {
    pub fn new(code: ErrorCode, message: impl Into<String>) -> Self {
        ProtoError { code, message: message.into(), id: None }
    }
    pub fn with_id(mut self, id: Option<String>) -> Self {
        self.id = id;
        self
    }
}

impl fmt::Display for ProtoError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}: {}", self.code.as_str(), self.message)
    }
}
impl std::error::Error for ProtoError {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FrameError {
    /// Declared length exceeds MAX_FRAME_BYTES.
    TooLarge(usize),
    /// Zero-length frame.
    Empty,
}

impl fmt::Display for FrameError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            FrameError::TooLarge(n) => write!(f, "frame of {n} bytes exceeds limit"),
            FrameError::Empty => write!(f, "empty frame"),
        }
    }
}
impl std::error::Error for FrameError {}

/// Prefix `body` with its little-endian u32 length.
pub fn encode_frame(body: &[u8]) -> Result<Vec<u8>, FrameError> {
    if body.is_empty() {
        return Err(FrameError::Empty);
    }
    if body.len() > MAX_FRAME_BYTES {
        return Err(FrameError::TooLarge(body.len()));
    }
    let mut out = Vec::with_capacity(HEADER_LEN + body.len());
    out.extend_from_slice(&(body.len() as u32).to_le_bytes());
    out.extend_from_slice(body);
    Ok(out)
}

/// Incremental frame decoder. The declared length is checked as soon as the
/// 4 header bytes are available, so buffered data never exceeds
/// HEADER_LEN + MAX_FRAME_BYTES plus one read chunk.
#[derive(Debug, Default)]
pub struct FrameDecoder {
    buf: Vec<u8>,
}

impl FrameDecoder {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn push(&mut self, data: &[u8]) {
        self.buf.extend_from_slice(data);
    }

    /// Returns Ok(None) when more bytes are needed. After an Err the
    /// connection must be closed; the decoder is not resynchronizable.
    pub fn next_frame(&mut self) -> Result<Option<Vec<u8>>, FrameError> {
        if self.buf.len() < HEADER_LEN {
            return Ok(None);
        }
        let len = u32::from_le_bytes([self.buf[0], self.buf[1], self.buf[2], self.buf[3]]) as usize;
        if len == 0 {
            return Err(FrameError::Empty);
        }
        if len > MAX_FRAME_BYTES {
            return Err(FrameError::TooLarge(len));
        }
        if self.buf.len() < HEADER_LEN + len {
            return Ok(None);
        }
        let body = self.buf[HEADER_LEN..HEADER_LEN + len].to_vec();
        self.buf.drain(..HEADER_LEN + len);
        Ok(Some(body))
    }

    pub fn buffered(&self) -> usize {
        self.buf.len()
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct Request {
    pub id: String,
    pub method: String,
    pub params: Map<String, Value>,
}

pub fn valid_id(s: &str) -> bool {
    !s.is_empty()
        && s.len() <= MAX_ID_LEN
        && s.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'_' || b == b'-')
}

/// Methods look like `app.ping` or `downloads.add`: two or more dot-separated
/// segments, each starting with a-z followed by a-z, 0-9 or `_`.
pub fn valid_method(s: &str) -> bool {
    if s == "hello" {
        return true; // the only single-segment method: the mandatory handshake
    }
    if s.len() < 3 || s.len() > MAX_METHOD_LEN {
        return false;
    }
    let mut segments = 0;
    for seg in s.split('.') {
        let mut bytes = seg.bytes();
        match bytes.next() {
            Some(b) if b.is_ascii_lowercase() => {}
            _ => return false,
        }
        if !bytes.all(|b| b.is_ascii_lowercase() || b.is_ascii_digit() || b == b'_') {
            return false;
        }
        segments += 1;
    }
    segments >= 2
}

/// Validate a request envelope:
/// `{"v":1,"id":"..","type":"request","method":"a.b","params":{..}}`.
/// `params` is optional (defaults to an empty object); unknown top-level
/// fields are rejected.
pub fn parse_request(body: &[u8]) -> Result<Request, ProtoError> {
    let value: Value = serde_json::from_slice(body)
        .map_err(|e| ProtoError::new(ErrorCode::Malformed, format!("invalid JSON: {e}")))?;
    let obj = value
        .as_object()
        .ok_or_else(|| ProtoError::new(ErrorCode::Malformed, "envelope must be a JSON object"))?;

    let id_hint = obj
        .get("id")
        .and_then(Value::as_str)
        .filter(|s| valid_id(s))
        .map(str::to_owned);
    let fail = |code: ErrorCode, msg: &str| ProtoError::new(code, msg).with_id(id_hint.clone());

    if obj.keys().any(|k| !matches!(k.as_str(), "v" | "id" | "type" | "method" | "params")) {
        return Err(fail(ErrorCode::Invalid, "unknown envelope field"));
    }
    let v = obj
        .get("v")
        .and_then(Value::as_u64)
        .ok_or_else(|| fail(ErrorCode::Invalid, "`v` must be a non-negative integer"))?;
    if v != PROTOCOL_VERSION {
        return Err(fail(ErrorCode::Version, "unsupported protocol version"));
    }
    if obj.get("type").and_then(Value::as_str) != Some("request") {
        return Err(fail(ErrorCode::Invalid, "`type` must be \"request\""));
    }
    let id = id_hint
        .clone()
        .ok_or_else(|| fail(ErrorCode::Invalid, "`id` must be 1-64 chars of [A-Za-z0-9_-]"))?;
    let method = obj
        .get("method")
        .and_then(Value::as_str)
        .filter(|m| valid_method(m))
        .ok_or_else(|| fail(ErrorCode::Invalid, "`method` is missing or malformed"))?
        .to_owned();
    let params = match obj.get("params") {
        None => Map::new(),
        Some(Value::Object(m)) => m.clone(),
        Some(_) => return Err(fail(ErrorCode::Invalid, "`params` must be an object")),
    };
    Ok(Request { id, method, params })
}

/// JSON body (unframed) for a success response.
pub fn encode_response(id: &str, result: Value) -> Vec<u8> {
    let v = json!({"v": PROTOCOL_VERSION, "id": id, "type": "response", "result": result});
    serde_json::to_vec(&v).unwrap_or_default()
}

/// JSON body (unframed) for an error reply. `id` is null when unknown.
pub fn encode_error(id: Option<&str>, code: ErrorCode, message: &str) -> Vec<u8> {
    let v = json!({
        "v": PROTOCOL_VERSION,
        "id": id,
        "type": "error",
        "error": {"code": code.as_str(), "message": message}
    });
    serde_json::to_vec(&v).unwrap_or_default()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn code_of(body: &str) -> ErrorCode {
        parse_request(body.as_bytes()).unwrap_err().code
    }

    #[test]
    fn parses_valid_ping() {
        let r = parse_request(br#"{"v":1,"id":"c1","type":"request","method":"app.ping","params":{"nonce":"x"}}"#).unwrap();
        assert_eq!(r.id, "c1");
        assert_eq!(r.method, "app.ping");
        assert_eq!(r.params.get("nonce").unwrap(), "x");
    }

    #[test]
    fn params_default_to_empty_object() {
        let r = parse_request(br#"{"v":1,"id":"c1","type":"request","method":"app.ping"}"#).unwrap();
        assert!(r.params.is_empty());
    }

    #[test]
    fn rejects_bad_json_and_non_objects() {
        assert_eq!(code_of("not json"), ErrorCode::Malformed);
        assert_eq!(code_of("[1,2]"), ErrorCode::Malformed);
        assert_eq!(code_of("\"str\""), ErrorCode::Malformed);
        assert_eq!(code_of(""), ErrorCode::Malformed);
    }

    #[test]
    fn rejects_unknown_fields_and_bad_types() {
        assert_eq!(code_of(r#"{"v":1,"id":"a","type":"request","method":"a.b","x":1}"#), ErrorCode::Invalid);
        assert_eq!(code_of(r#"{"v":1,"id":"a","type":"response","method":"a.b"}"#), ErrorCode::Invalid);
        assert_eq!(code_of(r#"{"v":1,"id":"a","method":"a.b"}"#), ErrorCode::Invalid);
        assert_eq!(code_of(r#"{"v":"1","id":"a","type":"request","method":"a.b"}"#), ErrorCode::Invalid);
        assert_eq!(code_of(r#"{"v":1.0,"id":"a","type":"request","method":"a.b"}"#), ErrorCode::Invalid);
        assert_eq!(code_of(r#"{"v":-1,"id":"a","type":"request","method":"a.b"}"#), ErrorCode::Invalid);
    }

    #[test]
    fn version_mismatch_keeps_id() {
        let e = parse_request(br#"{"v":2,"id":"z9","type":"request","method":"a.b"}"#).unwrap_err();
        assert_eq!(e.code, ErrorCode::Version);
        assert_eq!(e.id.as_deref(), Some("z9"));
    }

    #[test]
    fn id_rules() {
        assert!(valid_id("a"));
        assert!(valid_id(&"a".repeat(64)));
        assert!(!valid_id(&"a".repeat(65)));
        assert!(!valid_id(""));
        assert!(!valid_id("a b"));
        assert!(!valid_id("a/b"));
        assert!(!valid_id("é"));
        assert_eq!(code_of(r#"{"v":1,"id":"bad id","type":"request","method":"a.b"}"#), ErrorCode::Invalid);
        assert_eq!(code_of(r#"{"v":1,"id":5,"type":"request","method":"a.b"}"#), ErrorCode::Invalid);
        // bad id is never echoed back
        let e = parse_request(br#"{"v":1,"id":"bad id","type":"request","method":"a.b"}"#).unwrap_err();
        assert_eq!(e.id, None);
    }

    #[test]
    fn method_rules() {
        assert!(valid_method("hello"));
        assert!(valid_method("app.ping"));
        assert!(valid_method("downloads.add"));
        assert!(valid_method("a.b.c_1"));
        assert!(!valid_method("ping"));
        assert!(!valid_method("App.ping"));
        assert!(!valid_method("app."));
        assert!(!valid_method(".app"));
        assert!(!valid_method("app..ping"));
        assert!(!valid_method("app.1ping"));
        assert!(!valid_method("app.pi ng"));
        assert!(!valid_method(&format!("a.{}", "b".repeat(70))));
    }

    #[test]
    fn rejects_non_object_params() {
        assert_eq!(code_of(r#"{"v":1,"id":"a","type":"request","method":"a.b","params":[]}"#), ErrorCode::Invalid);
        assert_eq!(code_of(r#"{"v":1,"id":"a","type":"request","method":"a.b","params":null}"#), ErrorCode::Invalid);
    }

    #[test]
    fn frame_roundtrip_and_layout() {
        let f = encode_frame(b"hello").unwrap();
        assert_eq!(&f[..4], &[5, 0, 0, 0]);
        let mut d = FrameDecoder::new();
        d.push(&f);
        assert_eq!(d.next_frame().unwrap().unwrap(), b"hello");
        assert_eq!(d.next_frame().unwrap(), None);
        assert_eq!(d.buffered(), 0);
    }

    #[test]
    fn frame_split_across_pushes_and_multiple_frames() {
        let mut bytes = encode_frame(b"one").unwrap();
        bytes.extend(encode_frame(b"two").unwrap());
        let mut d = FrameDecoder::new();
        for b in &bytes[..bytes.len() - 1] {
            d.push(std::slice::from_ref(b));
        }
        assert_eq!(d.next_frame().unwrap().unwrap(), b"one");
        assert_eq!(d.next_frame().unwrap(), None);
        d.push(&bytes[bytes.len() - 1..]);
        assert_eq!(d.next_frame().unwrap().unwrap(), b"two");
    }

    #[test]
    fn frame_limits() {
        assert_eq!(encode_frame(b"").unwrap_err(), FrameError::Empty);
        assert!(encode_frame(&vec![0u8; MAX_FRAME_BYTES]).is_ok());
        assert_eq!(
            encode_frame(&vec![0u8; MAX_FRAME_BYTES + 1]).unwrap_err(),
            FrameError::TooLarge(MAX_FRAME_BYTES + 1)
        );
        let mut d = FrameDecoder::new();
        d.push(&[0, 0, 0, 0]);
        assert_eq!(d.next_frame().unwrap_err(), FrameError::Empty);
        let mut d = FrameDecoder::new();
        d.push(&((MAX_FRAME_BYTES as u32 + 1).to_le_bytes()));
        assert!(matches!(d.next_frame(), Err(FrameError::TooLarge(_))));
    }

    #[test]
    fn error_encoding_has_null_id_when_unknown() {
        let v: Value = serde_json::from_slice(&encode_error(None, ErrorCode::Malformed, "x")).unwrap();
        assert!(v["id"].is_null());
        assert_eq!(v["type"], "error");
        assert_eq!(v["error"]["code"], "E_MALFORMED");
        let v: Value = serde_json::from_slice(&encode_response("a1", json!({"ok":true}))).unwrap();
        assert_eq!(v["id"], "a1");
        assert_eq!(v["result"]["ok"], true);
    }

    #[test]
    fn error_codes_roundtrip() {
        for c in [
            ErrorCode::Malformed, ErrorCode::Invalid, ErrorCode::Version,
            ErrorCode::HandshakeRequired, ErrorCode::UnknownMethod, ErrorCode::TooLarge, ErrorCode::Internal,
        ] {
            assert_eq!(ErrorCode::from_wire(c.as_str()), Some(c));
        }
        assert_eq!(ErrorCode::from_wire("nope"), None);
    }
}
