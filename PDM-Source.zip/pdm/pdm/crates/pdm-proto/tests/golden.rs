//! Golden envelope files in `proto/golden`:
//!   valid-<name>.json            must parse as a request
//!   invalid-<E_CODE>-<name>.json must fail with that error code
use std::fs;
use std::path::PathBuf;
use pdm_proto::{parse_request, ErrorCode};

#[test]
fn golden_files() {
    let dir = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../../proto/golden");
    let mut seen = 0;
    for entry in fs::read_dir(&dir).expect("proto/golden missing") {
        let path = entry.unwrap().path();
        let name = path.file_name().unwrap().to_string_lossy().into_owned();
        if !name.ends_with(".json") {
            continue;
        }
        let body = fs::read(&path).unwrap();
        let parts: Vec<&str> = name.trim_end_matches(".json").splitn(3, '-').collect();
        match parts[0] {
            "valid" => {
                parse_request(&body).unwrap_or_else(|e| panic!("{name}: expected valid, got {e}"));
            }
            "invalid" => {
                let want = ErrorCode::from_wire(parts[1]).unwrap_or_else(|| panic!("{name}: bad code in filename"));
                let got = parse_request(&body).expect_err(&name).code;
                assert_eq!(got, want, "{name}");
            }
            other => panic!("{name}: unknown golden prefix {other}"),
        }
        seen += 1;
    }
    assert!(seen >= 8, "expected at least 8 golden files, found {seen}");
}
