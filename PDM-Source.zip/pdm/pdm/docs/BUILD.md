# Building PDM on Windows

**Status: unverified.** No command here has been run by the author. Report first-run failures.

## Prerequisites (once)

```powershell
winget install Microsoft.VisualStudio.2022.BuildTools --override "--quiet --wait --add Microsoft.VisualStudio.Workload.VCTools --includeRecommended"
winget install Rustlang.Rustup
winget install Python.Python.3.12
rustup default stable-x86_64-pc-windows-msvc
# Flutter stable: https://docs.flutter.dev/get-started/install/windows/desktop  (then: flutter config --enable-windows-desktop; flutter doctor)
```

Open a new terminal afterwards. Flutter must be a recent stable (the UI uses `ColorScheme.surfaceContainerHighest`, `DialogThemeData`, `DropdownButtonFormField.initialValue`, `Color.toARGB32`).

## Build

```powershell
powershell -ExecutionPolicy Bypass -File scripts\build.ps1
```

Does: `cargo build --release --workspace`; generates the Flutter Windows runner once (`flutter create`, renamed to `pdm.exe`); `flutter build windows`; stages `dist\` with `pdm.exe`, `pdmd.exe`, `pdm-host.exe`, `extension\`; runs the embedded-browser check.


If `flutter pub get` says "authorization failed" for pub.dev (blocked in some countries), use a VPN/proxy, or run `scripts\build.ps1 -Mirror` which points Flutter at the flutter-io.cn mirrors. A mirror is a third party serving your packages.

## Browser extension

1. Run `dist\pdm.exe` once (it registers the native host) or `dist\pdm-host.exe --install`.
2. Chrome/Edge/Brave: `chrome://extensions`, Developer mode, "Load unpacked", choose `dist\extension`. The extension ID is fixed by the `key` in its manifest and matches `EXTENSION_ID` in `crates/pdm-host/src/main.rs`.

## Tests

`scripts\test.ps1` (cargo tests incl. `pdm-host`, checker tests, `flutter analyze`); `scripts/test.sh` on Linux/macOS runs the portable subset.
