# PDM Feature Matrix

Last updated: Milestone 1. Maintained at every milestone; no feature is marked complete without evidence.

## Status vocabulary

- `NOT IMPLEMENTED`: no working code.
- `PARTIAL`: some source exists; not a complete feature.
- `IMPLEMENTED ... NOT RUN`: source exists but was never built/executed.
- `VERIFIED in sandbox`: actually executed in the Milestone 1 authoring sandbox (Linux, g++ 13, Python 3.12). This is **not** evidence about Windows, Qt or Rust behaviour.
- Test status `NOT RUN` means tests may be written but have not been executed anywhere.

No row is verified on Windows. No row has measured performance numbers.

| ID | Feature | Spec § | Status | Test status | Dependencies | Acceptance criteria |
|---|---|---|---|---|---|---|
| F-001 | Native Flutter (Dart) Windows shell: Downloads, Queues, Settings (themes, connections, proxy), 6 themes | 2,4 | PARTIAL (source written; never analysed or built) | NOT RUN | Flutter, dart:ffi | Window shows engine state; no web view in process |
| F-002 | Tray residency / close-to-tray | 2,4,13 | PARTIAL (source written; Windows build unverified) | NOT RUN | Qt Widgets | Closing window hides it; engine keeps running; Exit item quits |
| F-003 | Rust engine daemon `pdmd` skeleton | 2 | PARTIAL (source written; Windows build unverified) | cargo test written, NOT RUN | tokio | Starts, serves IPC, exits cleanly on shutdown/Ctrl+C; second instance refuses (exit 3) |
| F-004 | IPC framing (4-byte LE length, 1 MiB cap) - Rust | 2,19 | IMPLEMENTED in source; unit tests written, NOT RUN | pdm-proto unit tests (written, not run) | none | Partial/multiple/oversize/zero frames handled |
| F-005 | IPC framing - C++ codec | 2,19 | IMPLEMENTED and VERIFIED in sandbox (g++ 13, ASan/UBSan) | ui/tests/frame_codec_test.cpp: PASSED in sandbox | none | Same behaviour as Rust codec |
| F-006 | IPC envelope validation (v, id, type, method, params, unknown fields) | 2,19 | IMPLEMENTED in source; unit and golden tests written, NOT RUN | pdm-proto unit + golden tests (not run) | serde_json | Malformed requests produce documented error codes; bad ids never echoed |
| F-007 | Handshake (`hello`) and version negotiation | 2 | PARTIAL (source written; Windows build unverified) | engine session/duplex tests written, NOT RUN | - | Non-hello before handshake refused; major mismatch closes |
| F-008 | `app.ping` request/response round trip | 2 | PARTIAL (source written; Windows build unverified) | duplex test + named-pipe test + `--selftest-ping` e2e: written, NOT RUN | - | Nonce echoed; id echoed; timestamp present |
| F-009 | `app.shutdown` | 2 | PARTIAL (source written; Windows build unverified) | duplex test written, NOT RUN | - | Daemon exits after reply |
| F-010 | Named-pipe server (reject remote clients, first-instance, 8 conn cap, handshake timeout) | 2,19 | PARTIAL (source written; Windows build unverified) | pipe_e2e (Windows) written, NOT RUN | tokio named_pipe | Single owner of pipe name; slow/silent clients dropped |
| F-011 | Pipe ACL restricted to current user | 19 | NOT IMPLEMENTED (known gap; default pipe DACL applies) | - | windows security attrs | Only owner SID can connect; test with second user |
| F-012 | Embedded-browser dependency guard | 2,24 | IMPLEMENTED and VERIFIED in sandbox (sources); dist scan covered by unit tests only | tools/test_check_no_webengine.py: 16 tests PASSED in sandbox; real dist scan NOT RUN | Python 3 | Fails on WebEngine/WebView/CEF/Electron/Tauri/wry in sources or staged output |
| F-013 | Build scripts (MSVC 2022, Qt 6, Rust, CMake, Ninja) | 20,22 | IMPLEMENTED in source; NEVER RUN | scripts/build.ps1 NOT RUN | VS 2022, Qt, Rust, CMake, Ninja, Python | dist\ produced from clean checkout |
| F-014 | Memory/startup measurement script and method | 3 | IMPLEMENTED in source; NEVER RUN; no numbers exist | scripts/measure.ps1 NOT RUN | PowerShell | Reports private WS, WS, commit, peak, threads, startup |
| E-001 | Segment planner (non-overlapping, min size, max conns) | 6 | PARTIAL: pure function written | pdm-core unit tests written, NOT RUN | - | Exact cover for all sizes/conn counts |
| E-002 | Work-stealing split of slow range | 6 | PARTIAL: pure function written | unit test written, NOT RUN | - | Remainder halves are disjoint and exact |
| E-003 | Exact-cover verifier (gaps/overlaps/overflow) | 6 | PARTIAL: pure function written | unit tests written, NOT RUN | - | Detects every gap/overlap |
| E-004 | Content-Range parsing and validation against request | 6 | PARTIAL: pure function written | unit tests written, NOT RUN | - | Rejects malformed, wrong range, wrong total |
| E-005 | Filename sanitiser (Windows reserved names, traversal, length) | 5,19 | PARTIAL: pure function written | unit tests written, NOT RUN | - | No separators, no reserved names, never empty |
| E-010 | Streaming HTTP/HTTPS downloads | 5 | IMPLEMENTED in source; NEVER COMPILED OR RUN | tests/download.rs written, NOT RUN | Rust, hyper/reqwest, rustls | Real transfer against local fixture server |
| E-011 | Large files and unknown content length | 5 | IMPLEMENTED in source; NEVER COMPILED OR RUN | unknown_length test written, NOT RUN | - | Fixture without Content-Length completes correctly |
| E-012 | Redirects with security checks | 5,19 | PARTIAL: reqwest redirects (max 10); no per-hop private-network/SSRF checks | redirect test written, NOT RUN | - | Per-hop checks; cap; credential stripping |
| E-013 | Content-Disposition filename detection | 5 | IMPLEMENTED in source; NEVER COMPILED OR RUN | content_disposition test written, NOT RUN | pdm-core sanitiser | Fixture with tricky names |
| E-014 | File-exists policies | 5 | IMPLEMENTED in source (auto-rename only; no overwrite/skip policy); NEVER RUN | existing_file test written, NOT RUN | - | Rename/overwrite/skip tested |
| E-015 | Pause, resume, cancel, retry | 5,9 | IMPLEMENTED in source; NEVER COMPILED OR RUN (single-stream pause restarts from zero) | pause/cancel/resume tests written, NOT RUN | - | State machine tests incl. races |
| E-016 | Retry policy (backoff, jitter, Retry-After, status table) | 5 | PARTIAL: backoff+jitter+Retry-After, 408/429/5xx retriable; no per-status policy table | retry tests written, NOT RUN | - | Fixture returning 429/503 with Retry-After |
| E-017 | Disk-full / permission / disconnect handling | 5 | PARTIAL: IO errors fail the download; no disk-full/disconnect specific handling or fault-injection tests | NOT WRITTEN | - | Fault-injection writer tests |
| E-018 | Sleep/wake recovery | 5 | NOT IMPLEMENTED (timeouts+retries only) | NOT WRITTEN | Windows power notifications | Manual + simulated test |
| E-019 | Safe temp files and atomic finalize | 5,19 | IMPLEMENTED in source; NEVER COMPILED OR RUN (part file, sync, atomic rename) | covered by download tests, NOT RUN | - | Crash mid-download leaves no completed-looking file |
| E-020 | Range capability probe (206, Content-Range, ignored Range, validators) | 6 | IMPLEMENTED in source; NEVER COMPILED OR RUN | ignored-range / bad Content-Range tests written, NOT RUN | - | All fixture modes classified correctly |
| E-021 | Concurrent segment download, offset writes | 6 | IMPLEMENTED in source; NEVER COMPILED OR RUN | concurrency + exact-cover + SHA-256 test written, NOT RUN | - | Temporal overlap proven by server log; SHA-256 equal |
| E-022 | Dynamic load balancing, stalled-worker detection | 6 | PARTIAL: static split + per-segment retry/stall timeout; no work stealing (planner exists, unused) | NOT WRITTEN | - | Slow-worker fixture finishes faster than static split |
| E-023 | Segment persistence and restart recovery | 6,18 | IMPLEMENTED in source (JSON sidecar, not SQLite) | abrupt-termination + pause/resume tests written, NOT RUN | SQLite | Kill/restart test reuses only verified ranges |
| E-024 | Resource identity (ETag/If-Range) change handling | 6 | IMPLEMENTED in source; NEVER COMPILED OR RUN (strong ETag + If-Range) | changed-etag + stale-partial tests written, NOT RUN | - | Changed-ETag fixture restarts, never mixes versions |
| E-025 | Local range test server (all failure modes in spec) | 6,21 | IMPLEMENTED in source (src/fixture.rs) | used by all engine tests, NOT RUN; no connection-reset/416/rate-limit modes | hyper | Server records per-request timing/ranges |
| E-026 | 1/2/4/8 connection benchmark | 6 | NOT IMPLEMENTED | NOT WRITTEN | - | Measured, reported with conditions |
| D-003 | Batched progress persistence | 3,18 | NOT IMPLEMENTED | NOT WRITTEN | - | Write rate bounded under load |
| D-004 | Secrets in OS secure storage | 18,19 | NOT IMPLEMENTED | NOT WRITTEN | Windows Credential Manager | No secret in DB or logs |
| L-001 | Download list: search/filter/sort/group/bulk actions | 7 | PARTIAL: table with progress/status/info; no search/filter/sort/group/bulk | NOT WRITTEN | Qt model/view | Responsive with 500+ items |
| L-002 | History, properties view, integrity (SHA-256) check | 7 | PARTIAL: SHA-256 computed and stored, optional expected hash enforced; no properties view | hash tests written, NOT RUN | sha2 | Hash matches fixture |
| L-003 | Import/export of download lists | 7,17 | NOT IMPLEMENTED | NOT WRITTEN | - | Round-trip test |
| L-004 | Open file/folder, rename/move completed, delete with confirm | 7 | NOT IMPLEMENTED | NOT WRITTEN | - | Manual + unit tests |
| C-001 | Default and custom categories, tags | 8 | PARTIAL: sidebar shows files grouped by the 7 default categories by extension (view filter only); no custom categories, tags or save-folder rules | NOT RUN | - | Persisted, editable |
| C-002 | Destination rules with documented precedence and preview | 8 | NOT IMPLEMENTED | NOT WRITTEN | - | Deterministic tests |
| Q-001 | Persistent user-defined queues (CRUD, reorder, move) | 9 | PARTIAL: named queues in manager + JSON persistence; no UI to create/reorder/move | manager tests written, NOT RUN | - | Survive restart |
| Q-002 | Queue concurrency limits enforced in backend | 9 | IMPLEMENTED in source; NEVER COMPILED OR RUN | queue limit test written, NOT RUN | - | Frontend cannot exceed limits |
| Q-003 | Download state machine (no duplicate starts) | 9 | PARTIAL: status transitions under one mutex | manager tests written, NOT RUN | - | Race tests |
| S-001 | One-time and recurring schedules, timezone/DST, missed schedules | 13 | PARTIAL: one-shot start/stop per queue (UTC epoch) + minimal UI; no recurrence/timezone/DST/missed-schedule views | schedule test (injected clock) written, NOT RUN | chrono-tz or jiff | DST edge tests |
| S-002 | Post-completion actions (notify, sound, open, exit, sleep/hibernate/shutdown, run program) | 13 | PARTIAL: per-queue (never the default queue) none/stop-engine/shutdown(60 s, abortable) after that queue finishes, blocked if any of its files failed; other actions not implemented | post-action tests (mock runner) written, NOT RUN; real shutdown never executed | Win32 power APIs | Opt-in, cancellable; no shell injection |
| B-001 | Global/queue/per-download bandwidth limits (token buckets) | 14 | PARTIAL: global + per-queue token buckets; no per-download limit | limiter unit tests + 2 download tests written, NOT RUN | - | Measured rate within tolerance |
| B-002 | Snail/Balanced/Max presets, scheduled profiles, quotas, priorities | 14 | NOT IMPLEMENTED | NOT WRITTEN | - | Behavioural tests |
| W-001 | Chrome/Edge extension (MV3) with required menu actions | 10 | PARTIAL: "Download with PDM", "Download all links with PDM", optional capture; no per-site rules, no cookies/referrer | node --check only | WebExtensions | Manual + harness |
| W-002 | Firefox extension | 10 | NOT IMPLEMENTED | NOT WRITTEN | WebExtensions | Manual + harness |
| W-003 | Native Messaging host + registration/removal scripts | 10 | PARTIAL: pdm-host.exe + `--install` (HKCU Chrome/Edge/Brave); no uninstall | 2 unit tests written, NOT RUN | Rust, registry | Missing-app and disconnect tests |
| W-004 | Download interception, filters, popup, default queue | 10 | NOT IMPLEMENTED | NOT WRITTEN | - | Documented limits verified |
| G-001 | Link Grabber window (filters, dedupe, select, probe, cancel) | 11 | PARTIAL: extension popup with filter, select all, dedupe; no probe/size column | NOT RUN | extension | Exactly selected items submitted |
| G-002 | Grabber -> download now / existing queue / new queue | 11 | NOT IMPLEMENTED | NOT WRITTEN | - | Backend persists selected jobs |
| X-001 | Site Explorer (depth, domain, filters, projects, mirror) | 12 | NOT IMPLEMENTED | NOT WRITTEN | - | Bounded crawl tests |
| T-001 | .torrent and magnet, metadata, peers, limits, selective files | 15 | NOT IMPLEMENTED | NOT WRITTEN | librqbit or libtorrent | Legal fixture integration tests |
| T-002 | Torrent seeding limits, persistence, queue integration | 15 | NOT IMPLEMENTED | NOT WRITTEN | - | Restart recovery |
| M-001 | Direct media detection and handoff (no DRM circumvention) | 16 | NOT IMPLEMENTED | NOT WRITTEN | - | Fixture pages |
| M-002 | Optional FFmpeg conversion (external, licensed) | 16 | NOT IMPLEMENTED | NOT WRITTEN | FFmpeg | Dependency documented |
| I-001 | Clipboard monitoring (consent, exclusions) | 17 | NOT IMPLEMENTED | NOT WRITTEN | Qt | No repeat prompts |
| I-002 | Drag-and-drop URLs/files | 17 | NOT IMPLEMENTED | NOT WRITTEN | Qt | Manual |
| I-003 | Command-line interface | 17 | NOT IMPLEMENTED | NOT WRITTEN | - | Argument validation tests |
| U-001 | Dashboard and all main screens (22 listed) | 4 | PARTIAL: downloads table + details, queues and scheduler, settings incl. proxy; no tray, Site Explorer, Torrent pages | NOT RUN | Flutter | Each screen reads real backend state |
| U-002 | Themes (Light, Dark, Midnight, Graphite, Aurora, Ocean), accent, density | 4 | PARTIAL: 6 themes (Light, Dark, Midnight, Graphite, Aurora, Ocean), custom accent, compact/comfortable, persisted, live switching; no transparency option | NOT RUN | Qt | Live switching, persisted |
| U-003 | Reduced motion, accessibility, keyboard navigation | 4 | PARTIAL: accessible names, tooltips, shortcuts; no reduced-motion setting, no accessibility audit | NOT RUN | Qt | Accessibility checklist |
| U-004 | Glass-style effects without per-frame blur | 4 | NOT IMPLEMENTED | NOT WRITTEN | Qt | Profiled |
| U-005 | Notifications and tray behaviour | 4,13 | PARTIAL: tray icon with close-to-tray; no completion notifications/sounds | NOT RUN | Qt | Manual |
| SEC-001 | Threat model implementation (path, SSRF, DNS rebinding, injection, symlink) | 19 | NOT IMPLEMENTED | NOT WRITTEN | - | Security test suite |
| SEC-002 | Safe update mechanism with signature verification | 20 | NOT IMPLEMENTED | NOT WRITTEN | Ed25519 | Tampered package rejected |
| R-001 | Windows installer, portable build, uninstall cleanup | 20 | NOT IMPLEMENTED | NOT WRITTEN | WiX or Inno | Install/upgrade/uninstall on clean VM |
| R-002 | Dependency/license inventory, SHA-256 checksums, release notes | 20 | NOT IMPLEMENTED | NOT WRITTEN | cargo-deny | Generated in CI |
| R-003 | Code signing (state clearly if absent) | 20 | NOT IMPLEMENTED | NOT WRITTEN | certificate | Signature verified |
| P-001 | Idle RAM ~30 MB (Private Working Set, pdm.exe) measured | 3 | NOT IMPLEMENTED | NOT WRITTEN | - | Real numbers with machine description |
| P-002 | Idle CPU ~0, cold start < 1 s measured | 3 | NOT IMPLEMENTED | NOT WRITTEN | - | Real numbers |
| P-003 | Hundreds of queued items / large Link Grabber memory | 3 | NOT IMPLEMENTED | NOT WRITTEN | - | Measured |
| P-004 | Long-running transfer stability | 21 | NOT IMPLEMENTED | NOT WRITTEN | - | Soak test |
| P-001 | Proxy: none / system / manual HTTP or SOCKS5 with optional credentials | - | PARTIAL: engine settings + UI panel; no PAC script, per-protocol rules or per-site rules | tests written, NOT RUN | reqwest socks | Download goes through a local test proxy |
| V-001 | On-page "Download this video" button with detected-file menu | - | PARTIAL: direct files and unencrypted HLS (no DASH, blob, encrypted or live streams); size/quality/bitrate shown when the page exposes them | node stub test of background logic only | WebExtensions | Real sites |
