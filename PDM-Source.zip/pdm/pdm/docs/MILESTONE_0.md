# PDM — Milestone 0: Architecture and Specification

Status: design only. Nothing here has been built or measured.
Environment note: the authoring sandbox has g++ 13, Python 3.12, Node 22 and libsqlite3, but no Rust, CMake, Qt 6, or network, and runs Linux. Nothing in this document was compiled.

## 1. Process model

Two processes, plus a short-lived native-messaging host.

| Process | Language | Lifetime | Role |
|---|---|---|---|
| `pdm.exe` | C++17, Qt 6 Widgets | User session, tray-resident | UI only. Holds no download state of its own. |
| `pdmd.exe` | Rust | Started by UI or native host if absent; keeps running while downloads/schedules exist | Engine, scheduler, SQLite owner, filesystem access. |
| `pdm-nmh.exe` | Rust | Spawned by the browser per connection | Stateless relay: stdin/stdout framing to the engine's IPC. |

Decision: the engine owns the database. The UI never opens SQLite directly (single writer, no cross-process locking issues). Closing the UI does not stop `pdmd`; `pdmd` exits only when idle with no schedules and no UI/host attached after a grace period, or on explicit "Exit PDM".

Open choice with default: the UI may be tray-only (no top-level window) so Qt's footprint stays minimal. Default: create the main window lazily, destroy it on close-to-tray.

## 2. IPC protocol (v1)

Transport: Windows named pipe `\\.\pipe\pdm-<user SID>` with an ACL granting only the current user. Server in Rust (tokio, `tokio::net::windows::named_pipe`). Client in Qt using `QLocalSocket`.

Framing: 4-byte little-endian length prefix, then a UTF-8 JSON body. Maximum frame 1 MiB (4 MiB for list imports, negotiated). Frames over the limit close the connection.

Envelope:

```json
{ "v": 1, "id": "u64-or-uuid", "type": "request|response|event|error",
  "method": "downloads.add", "params": {}, "result": {}, "error": {"code": "E_INVALID", "message": "..."} }
```

Rules:
- Handshake first: `hello {v, client, capabilities}` -> `hello {v, server, caps}`. Mismatched major version gets `E_VERSION` and a close.
- Every request carries a unique `id`; responses echo it. Server drops duplicates of an in-flight `id`. Per-request timeout 10 s unless documented.
- `downloads.add` takes a client-generated `idempotency_key` for duplicate-submission protection.
- Events (`download.progress`, `download.state`, `queue.changed`) are server-pushed only to subscribed clients, coalesced to at most 4 per second per download, delivered in batches.
- The method set is a closed allowlist. There is no generic filesystem, shell, or power method. Power actions are settings the engine executes itself.
- All params are validated against Rust serde structs with `deny_unknown_fields` and range checks. JSON Schema files in `proto/` are the published contract; both sides are tested against them.

Initial method list: `hello`, `app.ping`, `app.shutdown`, `downloads.add|list|get|pause|resume|cancel|retry|remove|update`, `queues.*`, `schedules.*`, `settings.get|set`, `grabber.submit`, `events.subscribe`.

## 3. Download state machine

States: `Queued -> Probing -> Running -> Finalizing -> Completed`; side states `Paused`, `Failed(reason)`, `Cancelled`, `Scheduled`.

Transitions are performed only by the engine's single supervisor task per download (actor pattern), which serializes commands. A start while in `Probing|Running|Finalizing` is rejected as a no-op error. Persisted state is written in the same transaction as the transition. On startup, `Probing|Running|Finalizing` are rewritten to `Queued` after validation of temp files.

## 4. Engine design (Rust)

- Runtime: tokio multi-thread with a fixed worker count (default: min(4, cores)), not per-download threads.
- HTTP: `reqwest` with `rustls` (or `hyper` + `rustls` directly if reqwest's footprint measures badly).
- Probe: `HEAD` fallback to `GET Range: bytes=0-0`; accept range support only on a `206` with a consistent `Content-Range` and matching total length. Record validators (strong ETag, Last-Modified, length). Use `If-Range` on later requests.
- Segments: file split into non-overlapping ranges with a minimum size (default 1 MiB) and max connections per file. Work stealing: when a worker finishes, split the largest remaining range in half. Offset writes via `FileExt::seek_write` on a preallocated `.pdmpart` file. Writers buffer up to 256 KiB per connection; global buffer budget enforced by a semaphore.
- Verification: each response checked for status, `Content-Range`, and byte count; any mismatch fails that segment, never the file. Resource-identity change (validator mismatch) invalidates all segments.
- Retry: exponential backoff with jitter, honoring `Retry-After`, bounded attempts, per-status policy table.
- Speed limit: shared token-bucket hierarchy (global -> queue -> download).
- Finalize: fsync, size check, optional SHA-256, atomic rename (`MoveFileExW` with replace semantics), then mark Completed.
- Redirect/SSRF policy: re-resolve and check every hop; block loopback/private ranges by default unless the user opts in per host; cap redirects at 10; strip credentials and sensitive headers on cross-origin hops.
- Filenames: sanitize reserved Windows names, trailing dots/spaces, separators, `..`, and over-length paths; resolve the final path and require it to sit inside the chosen directory.

## 5. SQLite schema (v1 sketch)

WAL mode, `synchronous=NORMAL`, migrations by `PRAGMA user_version` with numbered embedded SQL scripts.

```sql
CREATE TABLE downloads(
  id INTEGER PRIMARY KEY, url TEXT NOT NULL, effective_url TEXT, filename TEXT,
  dest_dir TEXT NOT NULL, temp_path TEXT, size INTEGER, state TEXT NOT NULL,
  error TEXT, etag TEXT, last_modified TEXT, range_ok INTEGER,
  category_id INTEGER REFERENCES categories(id), queue_id INTEGER REFERENCES queues(id),
  priority INTEGER NOT NULL DEFAULT 0, position INTEGER NOT NULL DEFAULT 0,
  max_conns INTEGER, speed_limit INTEGER, sha256_expected TEXT, sha256_actual TEXT,
  retries INTEGER NOT NULL DEFAULT 0, headers_json TEXT,
  created_at INTEGER NOT NULL, started_at INTEGER, finished_at INTEGER,
  idempotency_key TEXT UNIQUE);
CREATE TABLE segments(
  download_id INTEGER NOT NULL REFERENCES downloads(id) ON DELETE CASCADE,
  idx INTEGER NOT NULL, start INTEGER NOT NULL, end INTEGER NOT NULL,
  done INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(download_id, idx));
CREATE TABLE queues(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, mode TEXT NOT NULL,
  max_files INTEGER, max_conns INTEGER, speed_limit INTEGER, default_category INTEGER,
  default_dir TEXT, retry_policy_json TEXT, position INTEGER);
CREATE TABLE categories(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, dir TEXT, builtin INTEGER);
CREATE TABLE tags(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL);
CREATE TABLE download_tags(download_id INTEGER, tag_id INTEGER, PRIMARY KEY(download_id, tag_id));
CREATE TABLE rules(id INTEGER PRIMARY KEY, kind TEXT, pattern TEXT, category_id INTEGER,
  queue_id INTEGER, dest_dir TEXT, precedence INTEGER NOT NULL);
CREATE TABLE schedules(id INTEGER PRIMARY KEY, target_kind TEXT, target_id INTEGER,
  tz TEXT NOT NULL, rrule TEXT, start_local TEXT, end_local TEXT, action TEXT,
  bandwidth_limit INTEGER, enabled INTEGER, last_fired_utc INTEGER);
CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE history_events(id INTEGER PRIMARY KEY, download_id INTEGER, ts INTEGER, kind TEXT, detail TEXT);
```

Progress is persisted at most every 2 s per active download and on every state transition; segment `done` flags are written when a segment completes, and partial segment progress is recovered from the part-file size map written at pause/shutdown. If the DB fails `PRAGMA integrity_check` at startup it is moved aside as `pdm.db.corrupt-<ts>`, a fresh DB is created, and the user is told.

## 6. Rule precedence (categories/destinations)

Evaluated in order: (1) explicit user choice in the add dialog, (2) queue default, (3) rules sorted by `precedence` ascending, ties broken by lower `id`, with kinds checked as domain > filename pattern > extension within equal precedence, (4) General category. First match wins; the rules editor shows a preview of the winning rule for a sample URL.

## 7. Browser integration

- Extensions: Manifest V3 for Chrome/Edge (service worker), Manifest V3 or V2 event page for Firefox, chosen at build per browser. Shared source with a thin per-browser manifest.
- Permissions requested minimally: `contextMenus`, `nativeMessaging`, `downloads` (only if interception is enabled), `storage`, and `activeTab`/`scripting` injected on demand for link collection.
- Native host manifest installed via HKCU registry keys (Chrome/Edge: `HKCU\Software\Google\Chrome\NativeMessagingHosts\com.pdm.host`, Edge equivalent; Firefox: `HKCU\Software\Mozilla\NativeMessagingHosts\com.pdm.host`). `allowed_origins`/`allowed_extensions` pin exact extension IDs.
- Messages use the same envelope as IPC with an `pdm-ext/1` protocol tag; the host re-validates and forwards only the allowlisted methods `downloads.add`, `grabber.submit`, `status.get`. Host-to-browser message cap is 1 MiB (browser limit), extension-to-host 4 GiB by spec but we enforce 1 MiB.
- Cookies/headers: extension forwards only `Referer`, `User-Agent`, and cookies for the exact download URL when the user enables it; stored nowhere except in-memory job headers, with redaction in logs.
- Known limitation: interception cannot be guaranteed for all downloads (blob/data URLs, some authenticated flows). Fallback is context-menu handoff.

## 8. Security model (summary)

Assets: user files, credentials/cookies in jobs, ability to run programs/shutdown. Trust boundaries: network content, webpages, extension, native host, UI, engine.

| Threat | Mitigation |
|---|---|
| Path traversal / reserved names | Sanitizer plus resolved-path containment check |
| SSRF / DNS rebinding | Per-hop resolve-and-check, pin resolved IP for the connection |
| Webpage invoking native ops | Extension content scripts have no native access; only the service worker talks to the host; allowlist |
| IPC spoofing | Per-user pipe ACL, first-instance pipe flag, version handshake |
| Command injection | No shell; post-completion program runs via `CreateProcessW` with argument vector configured by the user, never from URL/filename data |
| Resource exhaustion | Bounded frames, connections, retries, buffers, log rotation |
| Version mixing | Validators + `If-Range` + final size/hash check |
| Insecure temp files | Part files created in the destination dir, `CREATE_NEW`, user-only ACL inheritance, no symlink following (`FILE_FLAG_OPEN_REPARSE_POINT` check) |
| Unsafe updates | Manual/opt-in update check over HTTPS with signed manifest (Ed25519) and SHA-256; no auto-install without signature verification |

Remaining limitations to document: no sandboxing of the engine, same-user malware can use the pipe, no DRM handling.

## 9. Dependency inventory (proposed, licenses to be verified at adoption)

| Dependency | Use | License (expected) | Reason |
|---|---|---|---|
| Qt 6 (Core, Gui, Widgets, Network-for-QLocalSocket) | UI | LGPLv3 (dynamic linking) | Native widgets |
| Rust std + tokio | Async runtime | MIT/Apache-2.0 | Bounded-thread async I/O |
| reqwest/hyper + rustls | HTTP/TLS | MIT/Apache-2.0, ISC | No OpenSSL dependency |
| rusqlite (bundled SQLite) | Persistence | MIT; SQLite public domain | Single static dependency |
| serde / serde_json | Protocol | MIT/Apache-2.0 | Validated schemas |
| sha2 | Hashing | MIT/Apache-2.0 | Integrity |
| chrono + chrono-tz (or `jiff`) | Timezone-aware scheduling | MIT/Apache-2.0 | DST handling |
| librqbit or libtorrent-rasterbar (Milestone 8) | Torrents | Apache-2.0 / BSD | Review before adoption |
| WiX Toolset v4 or Inno Setup | Installer | MS-RL / Inno license | Windows installer |

A `cargo deny` license policy and a `THIRD_PARTY.md` generated from lockfiles will be part of the build.

## 10. Test plan

- Rust unit tests: sanitizer, state machine, range math, token bucket, rule precedence, schedule/DST computations, migrations.
- Rust integration tests with an in-process fixture HTTP server (hyper) implementing the failure modes in the spec (ignored Range, bad Content-Range, short body, resets, slow worker, changed ETag, 416/429/503, redirects, unknown length). Concurrency proof: the server records request start/end timestamps and byte ranges; the test asserts temporal overlap, disjoint coverage of `[0,len)`, and SHA-256 equality.
- Fault injection: failing writer trait for disk-full/permission; kill-and-restart test harness for recovery.
- IPC contract tests: golden JSON files validated against `proto/*.schema.json` from both C++ and Rust.
- Browser: Playwright/Selenium-free approach first (native host tested via stdin/stdout harness); manual checklist for real Chrome/Firefox until automation is practical.
- UI: Qt Test for models (batched updates), smoke test launching the shell against a stub engine.
- Performance: see section 11.

## 11. Benchmark plan

Reference machine to be recorded (CPU, RAM, SSD, Windows build). Scenarios: cold start, idle with window, tray-only idle, one download, eight concurrent downloads, one 8-connection segmented download, 500 queued items, Link Grabber with 5,000 links.
Metrics, collected with `typeperf`/PowerShell `Get-Process` and VMMap/`GetProcessMemoryInfo`: Working Set, Private Working Set, Private Bytes (commit), peak working set. The "approximately 30 MB idle" target is compared against **Private Working Set of `pdm.exe`**, reported separately from `pdmd.exe`, and also as the combined figure. Each scenario is run 5 times, median and min/max reported, with Qt/engine versions and build flags recorded. Throughput benchmarks use a local rate-shaped server with 1/2/4/8 connections.

## 12. Feature acceptance matrix

The full matrix lives in `docs/FEATURE_MATRIX.md` (seeded in this milestone, all items `Not started`). Columns: Feature, Spec section, Implementation path, Tests, Evidence, Status, Limitations.

## 13. Milestone 1 plan

1. Cargo workspace: `pdm-proto` (types + schemas), `pdm-engine` (`pdmd`), `pdm-nmh` stub.
2. CMake project for `pdm` (Qt 6 Widgets) with a `QLocalSocket` IPC client, tray icon, empty main window, `app.ping` round trip.
3. Script `tools/check_no_webengine.ps1` that scans the build output for Qt WebEngine/Chromium/CEF/WebView2 DLLs and fails if found.
4. Build scripts and `docs/BUILD.md` for Windows (MSVC 2022, Qt 6.x, Rust stable, CMake, Ninja).
5. Measurement script for startup and memory.

Blocker for verified completion of Milestone 1: it must be compiled and run on a Windows machine with those toolchains. The sandbox used here cannot do this.
