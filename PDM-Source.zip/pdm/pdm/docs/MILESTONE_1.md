# Milestone 1 Report: Native Lightweight Foundation

**Headline: the source exists, but nothing has been compiled or run on Windows, and no Rust or Qt code has been compiled anywhere.** The authoring sandbox had g++ 13, Python 3.12 and Node 22 on Linux, with no Rust, Qt, CMake or network. Milestone 1's definition of done (it builds, `app.ping` works end to end, idle memory and startup measured) is **not met until you run the commands in section 6**.

`docs/MILESTONE_0.md` is preserved unchanged.

## 1. Files created

Root: `README.md`, `Cargo.toml`, `rust-toolchain.toml`, `.gitignore`

Rust:
- `crates/pdm-proto/Cargo.toml`, `src/lib.rs` (framing, envelope validation, error codes, unit tests), `tests/golden.rs`
- `crates/pdm-engine/Cargo.toml`, `src/lib.rs`, `src/main.rs` (`pdmd`), `src/session.rs`, `src/server.rs`, `src/endpoint.rs`, `tests/ping.rs`, `tests/pipe_e2e.rs`
- `crates/pdm-core/Cargo.toml`, `src/lib.rs`, `src/ranges.rs`, `src/filename.rs` (groundwork for Milestones 2-3)

Protocol fixtures: `proto/golden/` (3 valid, 8 invalid envelopes)

Qt/C++ (`ui/`): `CMakeLists.txt`, `src/frame_codec.{h,cpp}`, `src/ipc_client.{h,cpp}`, `src/main_window.{h,cpp}`, `src/main.cpp`, `tests/frame_codec_test.cpp`

Tooling: `tools/check_no_webengine.py`, `tools/test_check_no_webengine.py`, `scripts/build.ps1`, `scripts/test.ps1`, `scripts/test.sh`, `scripts/measure.ps1`

Docs: `docs/BUILD.md`, `docs/FEATURE_MATRIX.md`, `docs/MEMORY_MEASUREMENT.md`, `docs/MILESTONE_1.md`

## 2. Behavior implemented (in source)

- **Process model:** `pdm.exe` (Qt Widgets, tray-resident) and `pdmd.exe` (Rust). The UI starts the engine if the pipe is missing and retries connecting with single-shot timers. No polling loops.
- **IPC v1:** `\\.\pipe\pdm-v1-<USERNAME>` (override with `PDM_PIPE_NAME`); 4-byte little-endian length + JSON; 1 MiB cap checked at the header; envelope `{v,id,type,method,params}` with strict validation (unknown fields rejected, id `[A-Za-z0-9_-]{1,64}`, method `a.b` form, params must be an object).
- **Methods:** `hello` (required first; 10 s timeout before handshake), `app.ping` (optional `nonce` echoed, returns `server_time_ms`), `app.shutdown`.
- **Errors:** `E_MALFORMED`, `E_INVALID`, `E_VERSION`, `E_HANDSHAKE_REQUIRED`, `E_UNKNOWN_METHOD`, `E_TOO_LARGE`, `E_INTERNAL`; client-side `E_TIMEOUT`, `E_DISCONNECTED`. Malformed JSON, oversize/zero frames and version mismatch close the connection after an error reply.
- **Engine hardening:** `reject_remote_clients`, `first_pipe_instance` (second daemon exits with code 3), at most 8 concurrent connections, 2 worker threads.
- **UI:** window with engine status, "Ping engine", bounded (500 line) log, tray icon with close-to-tray and two exit modes (leave engine / stop engine). `pdm.exe --tray` starts hidden. `pdm.exe --selftest-ping` is a headless e2e check (exit 0 ok, 1 bad reply, 2 timeout, 3 cannot connect).
- **No embedded browser:** CMake requests only Core, Gui, Widgets, Network. `tools/check_no_webengine.py` scans sources and, with `--dist`, staged files and the project's own binaries.
- **Groundwork:** segment planner, work-stealing split, exact-cover verifier, strict `Content-Range` validation, Windows filename sanitiser (not yet used by any download).

## 3. Version decision

Qt **6.8.3** (6.8 LTS line), MSVC 2022 64-bit kit, as the documented default. Rationale and configuration points are in `docs/BUILD.md`. CMake accepts any Qt >= 6.5 (`-DPDM_QT_MIN_VERSION`), and `build.ps1` takes `-QtVersion`/`-QtRoot`. I could not verify that 6.8.3 installs via the commands shown (the `aqt` architecture name is flagged in BUILD.md for you to confirm).

## 4. Tests actually executed (sandbox: Linux, g++ 13.3, Python 3.12)

| Test | Command | Result |
|---|---|---|
| C++ frame codec (layout, fragmentation, limits, sticky errors; ASan+UBSan, `-Wall -Wextra -Wpedantic`) | `bash scripts/test.sh` | **PASSED** |
| Embedded-browser checker self-test (16 cases incl. dist names, binary strings, allow marker, real repo) | `python3 tools/test_check_no_webengine.py` | **PASSED** (16 tests) |
| Embedded-browser check on this repository's sources | `python3 tools/check_no_webengine.py` | **PASSED** (no findings). It did initially flag two of my own comments/script lines; I fixed the comment and made the checker ignore its own filename. |

These say nothing about Windows, Qt or Rust behaviour.

## 5. Tests written but NOT executed

- `cargo test --workspace`: `pdm-proto` unit tests (~13) and golden-file test; `pdm-engine` session unit tests (6), endpoint test, 11 duplex-stream protocol tests (ping round trip, handshake required, fragmentation, pipelining, malformed JSON, oversize header, zero length, version mismatch, shutdown signal, handshake timeout, disconnect); Windows-only real named-pipe test (ping + second-instance refusal); `pdm-core` tests for ranges and filenames.
- `ctest` wiring of the C++ codec test via CMake (the test itself passed when compiled directly with g++).
- `pdm.exe --selftest-ping` against a real `pdmd.exe` (in `scripts/test.ps1`).
- All Qt code (`ipc_client`, `main_window`, `main`), CMake configuration, `build.ps1`, `test.ps1`, `measure.ps1`.
- Not written yet: Qt Test model tests (no models exist yet), automated UI tests, a non-Windows e2e (Unix socket path exists in the engine for dev use but is untested).

## 6. Commands to run on Windows

Prerequisites are in `docs/BUILD.md` (VS 2022 Build Tools C++ workload, Rust, CMake, Ninja, Python, Qt 6.8.3 msvc2022_64 at `C:\Qt`).

```powershell
cd pdm
powershell -ExecutionPolicy Bypass -File scripts\build.ps1
powershell -ExecutionPolicy Bypass -File scripts\test.ps1
dist\pdm.exe
powershell -ExecutionPolicy Bypass -File scripts\measure.ps1 -Runs 5 -IdleSeconds 10
```

Expected if everything works: `test.ps1` shows PASS on all five rows, the window shows "Engine: connected", and "Ping engine" logs a pong. Please send me the full output of any step that fails; first-compile errors are likely since nothing was compiled.

## 7. Known limitations and risks

- Entire Rust and Qt side uncompiled. Likeliest trouble spots: tokio named-pipe API details, `QLocalSocket::errorOccurred` handling during engine auto-start, windeployqt output, `AttachConsole` console output in `--selftest-ping`.
- `Cargo.lock` does not exist yet (generated by the first `cargo build`).
- Pipe ACL is the Windows default plus `reject_remote_clients`; restricting to the current user's SID is **not implemented** (FEATURE_MATRIX F-011).
- `pdmd` does not exit on its own when the UI is gone; there is no idle policy yet.
- The UI is a minimal shell: no theming, models, or the 22 screens. The tray icon is a stock Qt style icon.
- No SQLite, no downloads, no persistence of any kind. `pdm-core` functions are not wired to anything.
- No performance numbers exist. Idle RAM (~30 MB target) and startup are unmeasured; Qt Widgets plus Qt Network may not reach 30 MB private working set, to be profiled rather than assumed.
- License for the project itself is unset; dependency licenses unverified (Milestone 0 inventory is proposed only).

## 8. Remaining requirements

All of Milestones 2-10. See `docs/FEATURE_MATRIX.md` (81 rows; 63 are `NOT IMPLEMENTED`; none is verified on Windows).

## 9. Next concrete step

After you report the Windows build/test results and fix any compile errors: Milestone 2/3 core in `pdm-engine`: the local fixture HTTP server with the failure modes from the spec (ignored Range, bad Content-Range, truncation, resets, changed ETag, 416/429/503), then the real single-stream and segmented downloader wired to the existing `pdm-core` planner/validator, with tests asserting temporal overlap of range requests and SHA-256 equality. I can write that source now, but it would be the second layer of unverified code, so I recommend confirming Milestone 1 builds first.
