# Verification report (read this first)

**This package contains NO Windows executables.** `pdm.exe` and `pdmd.exe` were never built.

## Build environment inspected
Linux sandbox. Present: g++ 13, make, Python 3.12, Node 22, git, curl/wget, pip, apt-get. Absent: Rust/cargo, CMake, Ninja, Qt 6, MinGW cross-compiler, Zig, clang, Wine, Docker, .NET, sudo. No network (DNS fails), so toolchains cannot be installed. Native Windows compilation and cross-compilation are therefore both impossible here. This is the blocker.

## Tests actually executed (all in the Linux sandbox)
- C++ frame codec test (g++, ASan/UBSan): PASSED.
- Embedded-browser checker self-test (16 cases): PASSED.
- Embedded-browser check of the sources: PASSED.

## Written but never compiled or run
All Rust code (protocol, session, server, download engine, manager, rate limiter, fixture server) and all its tests (about 60: protocol/session/duplex, 20 engine fixture tests, 9 manager tests, 3 IPC download tests, Windows named-pipe test); the entire Qt UI; CMake; PowerShell scripts. Expect compile errors on first build.

## Implemented in source but unverified
HTTP/HTTPS downloads, probe, genuine concurrent Range segments with Content-Range/ETag/If-Range validation, single-stream fallback, retries with backoff/Retry-After, pause/resume/cancel, JSON-sidecar recovery after restart, SHA-256 integrity, bandwidth limiters, queues with concurrency limits, one-shot queue schedules, armed post-completion shutdown/stop-engine, persistent history (JSON), IPC methods, Qt downloads window with controls.

## Not implemented
Browser extension and Native Messaging host; Link Grabber; Site Explorer; torrents; categories/tags/destination rules; SQLite; recurring schedules/time zones; per-download limits; work-stealing load balancing; HTTPS has never been exercised (native-tls/SChannel configured, tests use plain HTTP); no per-hop SSRF/private-network blocking; pipe ACL not restricted to the user; installer, update mechanism, themes, 22 screens; speed/ETA display (progress bytes only); licenses/third-party notices; Cargo.lock (needs network).

## How to get a real executable
Run `scripts\build.ps1`, `scripts\test.ps1`, `scripts\package.ps1` on Windows with the toolchain in `docs/BUILD.md`, or push to GitHub and run `.github/workflows/windows.yml`. Neither has ever been run.


## Update: UI redesign
Added theme system (6 palettes), settings dialog, sidebar/dashboard layout, live speed and ETA, search and category/status filters. Compiled/run status: unknown until the Windows build is run.

## Update: first Windows run (reported by the user, MSVC 2022 + Rust stable)
Observed on Windows from `diagnose-output.txt`: the Rust workspace compiles. Passed: pdm-core 10/10, pdm-engine unit 11/11, IPC/session 11/11, named pipe 1/1, IPC downloads 3/3, pdm-proto 13/13 + golden 1/1, download-engine fixture tests 18/19, manager tests 8/10. Failures found and fixed in source (not yet re-run): fixture did not log 404 requests; a cancel during the probe left partial files; the schedule test raced the real scheduler. `pdm.exe --selftest-ping` crashed (exit -1073741819); the selftest was rewritten to log progress to a file for diagnosis.
Since then (never compiled): Material-style UI, toolbar, add dialog, details dialog with real per-segment progress, queue manager dialog, queue sidebar entries.

## Update: UI redesign v3 (from the user's screenshots)
Root cause of unstyled/misaligned buttons found: the style sheet contained `padding: 8 px 18px` (a space before `px`), which Qt rejects, so every button/tab/list rule using it fell back to defaults (white accent fills, no padding). Fixed. New layout modelled on the user's reference: slim sidebar with count badges (Downloads, Queue, Completed, Failed), status chips, sortable table (click any header; default is date added, newest at the bottom), right-hand details panel (details, measured speed graph, real per-segment connections), row context menu. Removed summary cards/toolbar. Not compiled or viewed yet.


## Update: rename to PDM, Flutter UI, Downloaders, browser extension (never compiled)
- Renamed XDM -> PDM everywhere (crates, binaries, pipe `pdm-v1-<USER>`, env `PDM_*`, data dir `%APPDATA%\PDM`). Wire protocol unchanged.
- Qt UI (`ui/`) deleted; replaced by `ui_flutter/` (Dart, FFI named-pipe client in a worker isolate). Not analysed or run: no Flutter SDK in the sandbox.
- Downloaders: YouTube (yt-dlp: video MP4 by height, audio MP3/M4A/OPUS with MP3 bitrate) and Spotify (spotdl). They run as child processes and are listed on the Downloaders page, not in the engine's download list.
- New crate `pdm-host` (Native Messaging bridge) and `extension/` (MV3). Syntax-checked with `node --check` only.
- Not carried over from the Qt UI: system tray residency, the old log page. Engine calls `downloads.add` accepts no headers/cookies, so browser downloads that need login cookies cannot work through PDM.

## Update 2: unwanted background downloads, built-in tool installer, link grabber
- Root cause of downloads while the UI was closed: `pdmd` restarted every Queued/Running item at startup, and `pdm-host` started `pdmd` even for a popup ping. Now `pdmd` starts with unfinished items Paused (`--resume` restores the old behaviour), a ping never starts the engine, and closing the UI asks whether to stop the engine (`app.shutdown`). New test `cold_start_without_resume_keeps_unfinished_downloads_paused` (not run).
- yt-dlp/spotdl/ffmpeg are installed by the app into `%LOCALAPPDATA%\PDM\tools` (checksum-verified where the publisher provides one; spotdl only if GitHub supplies a digest). Daily update check of yt-dlp/spotdl only while the app is open; ffmpeg is never auto-updated.
- Link grabber now also lists images (lazy/srcset), scripts, styles, frames, CSS background images and everything in Resource Timing; allFrames when permitted.

## Update 3: Downloaders removed, proxy settings, video button (never compiled)
- Removed the YouTube/Spotify Downloaders page, the tool installer/updater and all yt-dlp/spotdl/ffmpeg code.
- Proxy: engine `Settings.proxy` (mode system|none|manual, kind http|socks5, host, port, user, password), `settings.set {proxy:{..}}`, `settings.get` never returns the password. reqwest `socks` feature added (new crates download on the next `cargo build`). Applies to downloads started or resumed afterwards. Tests written, not run: `proxy_settings_build_urls_and_reject_bad_input`, `add_rejects_non_http_referer`.
- `downloads.add` accepts an optional `referer` (http/https URL), stored in the record and sent on every request of that download. Cookies are still not supported.
- Extension 0.2.0: content script button over `<video>`/`<audio>` with a menu of detected files (type, height, kbps, size) and "Download all"; files are learned from `webRequest` events of type `media` only. Not supported: HLS/DASH and blob (MSE) streams. `tools/test_extension_background.js` (stubbed chrome API) passes; content.js is only syntax-checked. New permissions: webRequest and all-sites access.

## Update 4: HLS, file types, list sorting (never compiled)
- Engine: `hls.rs` downloads HLS playlists (master -> best variant, or the variant given), several segments at a time, joined in order into `.ts` (or `.mp4` when the playlist has an init segment). Rejected with a clear error: encrypted (AES) playlists, byte-range segments, live streams. Not resumable. A URL is treated as HLS when its path ends in `.m3u8` or it carries the `#pdm-hls` fragment (added by the extension). Tests written, not run: parser unit tests in `hls.rs`, `hls_master_picks_best_variant_and_joins_segments_in_order`, `hls_live_and_encrypted_playlists_are_rejected_not_hung`.
- Engine: a download named `x.php` (or no extension) served with a media Content-Type is saved with the media extension (`pdm_core::filename::ensure_media_ext`, unit-tested, not run). Explicit names are never rewritten.
- Extension: sniffs media/xhr/other responses (string checks only before storage), lists HLS qualities (height, kbps), labels files by Content-Type instead of the URL (`video.php` shows MP4), corner button while an `<audio>` plays. `tools/test_extension_background.js` passes (stubbed chrome API); content.js is syntax-checked only.
- UI: sortable column headers (name, queue, size, status, progress, speed, left, last try), Run / Open file buttons, details panel no longer under the scrollbar.
- Not possible here: Spotify (DRM), YouTube (separate chunked audio/video streams), DASH, blob/MSE players, encrypted HLS.
