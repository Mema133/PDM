const HOST = "com.pdm.host";

// The browser's session for a URL, as a Cookie header value ("" when none or unreadable). PDM's engine sends it
// with every request, so logged-in and token-protected downloads work like they do in the browser.
async function cookieHeader(url) {
  try {
    return (await chrome.cookies.getAll({ url })).map((c) => c.name + "=" + c.value).join("; ");
  } catch {
    return "";
  }
}

// Netscape cookies.txt for yt-dlp, which runs outside the browser (YouTube's "confirm you're not a bot" check needs it).
async function ytCookies(pageUrl) {
  try {
    const sets = [await chrome.cookies.getAll({ url: pageUrl })];
    if (/(^|\.)(youtube\.com|youtu\.be)$/.test(new URL(pageUrl).hostname)) {
      sets.push(await chrome.cookies.getAll({ domain: "youtube.com" }), await chrome.cookies.getAll({ domain: "google.com" }));
    }
    const all = new Map();
    for (const c of sets.flat()) all.set(c.domain + "|" + c.path + "|" + c.name, c);
    const line = (c) => [(c.httpOnly ? "#HttpOnly_" : "") + c.domain, c.domain.startsWith(".") ? "TRUE" : "FALSE", c.path, c.secure ? "TRUE" : "FALSE", Math.round(c.expirationDate || 0), c.name, c.value].join("\t");
    return "# Netscape HTTP Cookie File\n" + [...all.values()].map(line).join("\n") + "\n";
  } catch {
    return "";
  }
}

// Resolves {ok, added, error}; never rejects, so callers only branch on ok.
// extra: {name, ytdlp}. ytdlp = the URL is a page for yt-dlp, not a file.
async function sendToPdm(urls, referer, extra = {}) {
  const msg = { action: "add", urls, referer, name: extra.name, ytdlp: !!extra.ytdlp, source: extra.source };
  if (msg.ytdlp) msg.cookies = await ytCookies(urls[0]);
  else if (urls.length === 1) msg.cookie = await cookieHeader(urls[0]);
  else {
    const byOrigin = new Map(); // one lookup per site, not per link
    msg.cookie_map = {};
    for (const u of urls) {
      let o;
      try { o = new URL(u).origin; } catch { continue; }
      if (!byOrigin.has(o)) byOrigin.set(o, await cookieHeader(u));
      if (byOrigin.get(o)) msg.cookie_map[u] = byOrigin.get(o);
    }
  }
  return new Promise((resolve) => {
    chrome.runtime.sendNativeMessage(HOST, msg, (r) => {
      const err = chrome.runtime.lastError;
      resolve(err ? { ok: false, error: err.message } : r || { ok: false, error: "no reply" });
    });
  });
}

function flash(tabId, ok) {
  chrome.action.setBadgeBackgroundColor({ color: ok ? "#2DD4BF" : "#EF4444" });
  chrome.action.setBadgeText({ text: ok ? "OK" : "!" });
  setTimeout(() => chrome.action.setBadgeText({ text: "" }), 2500);
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    const all = ["page", "selection", "link", "image", "video", "audio"];
    chrome.contextMenus.create({ id: "pdm", title: "PDM Integration Module", contexts: all });
    chrome.contextMenus.create({ id: "pdm-one", parentId: "pdm", title: "Download with PDM", contexts: ["link", "image", "video", "audio"] });
    chrome.contextMenus.create({ id: "pdm-all", parentId: "pdm", title: "Download all links with PDM", contexts: ["page", "selection", "link", "image", "video", "audio"] });
  });
});

// Runs inside each frame of the page (activeTab grants access after the menu click).
// Collects what IDM lists: links, media, images (incl. lazy/srcset), scripts, styles, frames and
// everything the page actually loaded (Resource Timing: CSS backgrounds, fonts, XHR/media files).
function collectLinks() {
  const sel = getSelection();
  const onlySel = !!sel && !sel.isCollapsed;
  const seen = new Map();
  const add = (el, raw, text) => {
    if (!raw || (onlySel && el && !sel.containsNode(el, true))) return;
    let url;
    try { url = new URL(raw, document.baseURI).href; } catch { return; }
    if (!/^https?:/i.test(url) || seen.has(url)) return;
    seen.set(url, (text || "").trim().replace(/\s+/g, " ").slice(0, 200));
  };
  const srcset = (el, v) => String(v || "").split(",").forEach((c) => add(el, c.trim().split(/\s+/)[0], el.alt || ""));
  const scan = (root) => {
    for (const el of root.querySelectorAll("*")) {
      const t = el.localName;
      if (t === "a" || t === "area") add(el, el.getAttribute("href"), el.textContent || el.title);
      else if (t === "link") add(el, el.getAttribute("href"), el.rel);
      else if (t === "script" || t === "iframe" || t === "embed" || t === "audio" || t === "video" || t === "source" || t === "track" || t === "img" || t === "input") add(el, el.getAttribute("src"), el.alt || "");
      else if (t === "object") add(el, el.getAttribute("data"), "");
      if (t === "img" || t === "source") {
        for (const k of ["data-src", "data-lazy-src", "data-original", "data-full"]) add(el, el.getAttribute(k), el.alt || "");
        srcset(el, el.getAttribute("srcset") || el.getAttribute("data-srcset"));
      }
      if (t === "video") add(el, el.getAttribute("poster"), "");
      const st = el.getAttribute("style");
      if (st && st.includes("url(")) for (const m of st.matchAll(/url\(\s*["']?([^"')]+)/g)) add(el, m[1], "");
      if (el.shadowRoot) scan(el.shadowRoot);
    }
  };
  scan(document);
  if (!onlySel) for (const e of performance.getEntriesByType("resource")) add(null, e.name, "");
  return [...seen].map(([url, text]) => ({ url, text }));
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "pdm-one") {
    const url = info.linkUrl || info.srcUrl;
    if (url) flash(tab && tab.id, (await sendToPdm([url], info.pageUrl, { source: "menu" })).ok);
  } else if (info.menuItemId === "pdm-all" && tab) {
    let res = [];
    try {
      res = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: collectLinks });
    } catch {
      res = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: collectLinks });
    }
    const merged = new Map();
    for (const r of res) for (const l of r.result || []) if (!merged.has(l.url)) merged.set(l.url, l);
    await chrome.storage.session.set({ grab: { links: [...merged.values()], page: tab.url || "" } });
    chrome.windows.create({ url: "grabber.html", type: "popup", width: 1000, height: 680 });
  }
});

// Optional IDM-style capture of the browser's own downloads. Off by default.
// Like IDM, only take over the kinds of file a download manager is for (IDM keeps a configurable extension list);
// pages, images, JSON and the like are left to the browser.
const CAPTURE_EXT = new Set(("zip rar 7z gz tgz bz2 xz tar zst iso img dmg pkg exe msi apk deb rpm appx msix pdf doc docx xls xlsx ppt pptx epub " +
  "mp4 mkv avi mov wmv flv webm m4v ts mp3 flac wav aac ogg opus m4a wma").split(" "));
function wantsCapture(item, url) {
  const ext = (n) => ((/\.([a-z0-9]{1,5})$/i.exec(n || "") || [])[1] || "").toLowerCase();
  let e = ext(item.filename);
  if (!e) try { e = ext(new URL(url).pathname); } catch {}
  if (e) return CAPTURE_EXT.has(e);
  return /^(application\/(?!json|javascript|xml|xhtml)|video\/|audio\/)/i.test(item.mime || ""); // no extension: judge by type
}

const captured = new Map(); // url -> time, so one click never opens two confirmation windows
chrome.downloads.onCreated.addListener(async (item) => {
  const { intercept } = await chrome.storage.local.get({ intercept: false });
  const url = item.finalUrl || item.url;
  if (!intercept || item.byExtensionId || !/^https?:/i.test(url) || !wantsCapture(item, url)) return;
  // Only a download that has just started: Chrome can report older ones again (resumed, or restored after a restart).
  if (item.state !== "in_progress" || Date.now() - Date.parse(item.startTime) > 15000) return;
  if (Date.now() - (captured.get(url) || 0) < 10000) return;
  captured.set(url, Date.now());
  if ((await sendToPdm([url], item.referrer, { source: "capture" })).ok) {
    chrome.downloads.cancel(item.id, () => chrome.downloads.erase({ id: item.id }));
  }
});

// ---- video capture: remember media files a tab loads, for the on-page "Download this video" button ----
// The listener does only string checks before touching storage, so ordinary page traffic stays cheap.
// HLS playlists (.m3u8) are kept and expanded into their quality variants when the menu opens.
// DASH and blob/MSE streams are not single files and are skipped. YouTube's videoplayback URLs are kept (see ytItem).
const mediaKey = (tabId) => "media" + tabId;
const HLS_RE = /\.m3u8(\?|#|$)/i;
const SEGMENT_RE = /\.(ts|m4s|cmfv|cmfa|aac)(\?|#|$)/i; // pieces of a stream, not a file
const MEDIA_EXT_RE = /\.(mp4|m4v|webm|mkv|mov|flv|3gp|mp3|m4a|ogg|opus|flac|wav)(\?|#|$)/i;
let mediaQueue = Promise.resolve(); // storage read-modify-write must not interleave

// YouTube: the player fetches each stream (video-only, audio-only, or itag 18/22 with both) in range=... chunks.
// Dropping range/rn/rbuf from that same signed URL asks for the whole stream. SABR streams (POST, sabr=1) are no file.
const YT_Q = { 160: 144, 133: 240, 134: 360, 135: 480, 136: 720, 137: 1080, 264: 1440, 266: 2160, 278: 144, 242: 240, 243: 360, 244: 480, 247: 720, 248: 1080, 271: 1440, 313: 2160, 18: 360, 22: 720 };
const YT_BOTH = new Set([18, 22]);
function ytItem(d) {
  if (d.method !== "GET" || !/^https:\/\/[^/]*googlevideo\.com\/videoplayback\?/.test(d.url)) return null;
  const u = new URL(d.url), p = u.searchParams;
  const mime = (p.get("mime") || "").toLowerCase(), size = Number(p.get("clen")) || 0;
  if (p.get("sabr") || !/^(audio|video)\//.test(mime) || size < 50000) return null;
  for (const k of ["range", "rn", "rbuf"]) p.delete(k);
  const itag = Number(p.get("itag")) || 0;
  return { url: u.href, mime, size, yt: true, h: YT_Q[itag] || 0, d: Number(p.get("dur")) || 0,
    only: YT_BOTH.has(itag) ? "" : mime.startsWith("video/") ? "video only" : "audio only" };
}

async function remember(tabId, item) {
  const key = mediaKey(tabId);
  const list = (await chrome.storage.session.get(key))[key] || [];
  const old = list.find((m) => m.url === item.url);
  if (old) {
    old.size = item.size || old.size;
  } else {
    list.push(item);
    if (list.length > 30) list.shift();
  }
  await chrome.storage.session.set({ [key]: list });
}

async function noteMedia(d) {
  if (d.tabId < 0 || (d.statusCode !== 200 && d.statusCode !== 206)) return;
  // SABR: the player POSTs to googlevideo and gets a framed stream, so no file URL exists. Say so instead of showing nothing.
  if (/^https:\/\/[^/]*googlevideo\.com\/videoplayback/.test(d.url) && (d.method === "POST" || /[?&]sabr=1/.test(d.url))) {
    return chrome.storage.session.set({ ["sabr" + d.tabId]: true });
  }
  const yt = ytItem(d);
  if (yt) return remember(d.tabId, yt);
  if (d.url.includes("/videoplayback") || SEGMENT_RE.test(d.url)) return;
  const h = (n) => ((d.responseHeaders || []).find((x) => x.name.toLowerCase() === n) || {}).value || "";
  const mime = h("content-type").split(";")[0].trim().toLowerCase();
  if (mime === "video/mp2t") return; // an HLS segment
  // DASH keeps picture and sound in separate streams listed in a manifest: PDM's engine cannot join them, yt-dlp can.
  if (/dash\+xml/.test(mime) || /\.mpd(\?|#|$)/i.test(d.url)) return remember(d.tabId, { url: d.url, mime, size: 0, dash: true });
  const hls = /mpegurl/.test(mime) || HLS_RE.test(d.url);
  const media = /^(audio|video)\//.test(mime) || (mime === "application/octet-stream" && MEDIA_EXT_RE.test(d.url));
  if (!hls && !media) return;
  const total = /\/(\d+)\s*$/.exec(h("content-range")); // a 206's content-length is only the chunk
  const size = hls ? 0 : total ? Number(total[1]) : Number(h("content-length")) || 0;
  if (!hls && size && size < 50000) return; // sound effects, ad pings
  await remember(d.tabId, { url: d.url, mime, size, hls });
}

chrome.webRequest.onHeadersReceived.addListener(
  (d) => { mediaQueue = mediaQueue.then(() => noteMedia(d)).catch(() => {}); },
  { urls: ["<all_urls>"], types: ["media", "xmlhttprequest", "other"] },
  ["responseHeaders"]
);
chrome.tabs.onRemoved.addListener((id) => chrome.storage.session.remove(mediaKey(id)));
chrome.tabs.onUpdated.addListener((id, info) => { if (info.status === "loading" && info.url) chrome.storage.session.remove(mediaKey(id)); });

// ---- HLS: read a playlist and list its qualities (same rules as the engine: no encryption, no live) ----
function attrs(s) {
  const out = {};
  for (const m of s.matchAll(/([A-Z0-9-]+)=("[^"]*"|[^,]*)/g)) out[m[1]] = m[2].replace(/^"|"$/g, "");
  return out;
}

function parseM3u8(text, base) {
  const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (!lines.length || !lines[0].startsWith("#EXTM3U")) return { error: "not an HLS playlist" };
  const variants = [];
  let pending = null, ended = false, segments = 0, dur = 0, map = false, nextDur = 0;
  for (const l of lines) {
    if (l.startsWith("#EXT-X-STREAM-INF:")) {
      const a = attrs(l.slice(18));
      pending = { bw: Number(a.BANDWIDTH) || 0, h: Number((a.RESOLUTION || "").split(/x/i)[1]) || 0 };
    } else if (l.startsWith("#EXT-X-KEY:")) {
      const m = attrs(l.slice(11)).METHOD || "NONE";
      if (m !== "NONE") return { error: "encrypted (" + m + ") is not supported" };
    } else if (l.startsWith("#EXT-X-MAP:")) {
      map = true;
    } else if (l.startsWith("#EXT-X-BYTERANGE")) {
      return { error: "byte-range streams are not supported" };
    } else if (l.startsWith("#EXTINF:")) {
      nextDur = parseFloat(l.slice(8)) || 0;
    } else if (l.startsWith("#EXT-X-ENDLIST")) {
      ended = true;
    } else if (!l.startsWith("#")) {
      let u;
      try { u = new URL(l, base).href; } catch { continue; }
      if (pending) { variants.push({ url: u, ...pending }); pending = null; }
      else { segments++; dur += nextDur; nextDur = 0; }
    }
  }
  if (variants.length) return { variants };
  if (!segments) return { error: "playlist has no segments" };
  if (!ended) return { error: "live streams are not supported" };
  return { dur, ext: map ? "mp4" : "ts" };
}

async function hlsItems(url) {
  try {
    const r = await fetch(url, { credentials: "include", cache: "no-store", signal: AbortSignal.timeout(8000) });
    if (!r.ok) return [{ url, hls: true, error: "playlist answered HTTP " + r.status }];
    const p = parseM3u8((await r.text()).slice(0, 4000000), url);
    if (p.error) return [{ url, hls: true, error: p.error }];
    if (p.variants) return p.variants.map((v) => ({ url: v.url, hls: true, h: v.h, bw: v.bw, ext: "ts" }));
    return [{ url, hls: true, dur: p.dur, ext: p.ext }];
  } catch {
    return [{ url, hls: true, error: "playlist could not be read" }];
  }
}

async function buildList(tabId, domUrls) {
  const key = mediaKey(tabId);
  const known = new Map(((await chrome.storage.session.get(key))[key] || []).map((m) => [m.url, m]));
  for (const u of domUrls) if (!known.has(u)) known.set(u, { url: u, mime: "", size: 0, hls: HLS_RE.test(u) });
  const out = new Map();
  await Promise.all([...known.values()].map(async (it) => {
    for (const x of it.hls ? await hlsItems(it.url) : [it]) if (!out.has(x.url)) out.set(x.url, x);
  }));
  return [...out.values()];
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg) return;
  if (msg.type === "send") {
    sendToPdm(msg.urls, msg.referer, { name: msg.name, ytdlp: msg.ytdlp, source: msg.source || "page" }).then(reply);
    return true; // async reply
  }
  if (msg.type === "media-list" && sender.tab) {
    const sabrKey = "sabr" + sender.tab.id;
    Promise.all([buildList(sender.tab.id, Array.isArray(msg.dom) ? msg.dom.slice(0, 20) : []), chrome.storage.session.get(sabrKey)])
      .then(([list, s]) => reply({ list, sabr: !!s[sabrKey] }), (e) => reply({ list: [], error: String((e && e.message) || e) }));
    return true;
  }
});
