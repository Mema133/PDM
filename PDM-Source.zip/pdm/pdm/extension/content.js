// "Download this video" button (IDM-style). Cheap by design: no MutationObserver and no polling; work happens
// only on throttled mouse moves and when a media element starts playing. Pages that have no <video> cost
// one empty collection lookup per 200 ms of mouse movement.
(() => {
  if (window.__pdmVideo) return;
  window.__pdmVideo = true;
  const MIN_W = 200, MIN_H = 110;
  let host, root, btn, label, menu, target = null, hideTimer = 0, menuOpen = false, lastMove = 0, resetTimer = 0;
  let off = { x: 8, y: 8 }, dragging = false, moved = false; // button offset inside the video; the user can drag it

  const CSS = `
    :host { all: initial; }
    .wrap { font: 13px "Segoe UI", system-ui, sans-serif; color: #E6E8EE; }
    button { all: unset; cursor: grab; display: inline-flex; gap: 6px; align-items: center; padding: 3px 9px; border-radius: 8px; font-size: 11.5px; touch-action: none; user-select: none;
      background: linear-gradient(135deg, #5B9DFF, #7C8CFF); color: #fff; font-weight: 600; box-shadow: 0 2px 8px rgba(0,0,0,.4); opacity: .92; }
    button:active { cursor: grabbing; }
    button:hover { filter: brightness(1.12); }
    .menu { margin-top: 6px; min-width: 340px; max-width: min(620px, 92vw); max-height: 60vh; overflow: auto; background: #1C1F26; border: 1px solid #2E333F;
      border-radius: 12px; padding: 6px; box-shadow: 0 10px 30px rgba(0,0,0,.55); }
    .row { display: flex; gap: 10px; padding: 8px 10px; border-radius: 8px; cursor: pointer; align-items: baseline; }
    .row:hover { background: #252932; }
    .row.dim { cursor: default; color: #8E95A5; white-space: normal; }
    .row.dim:hover { background: none; }
    .n { color: #8E95A5; } .t { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; } .m { color: #8FB8FF; white-space: nowrap; }
    .all { font-weight: 600; border-bottom: 1px solid #2E333F; border-radius: 8px 8px 0 0; margin-bottom: 4px; }
  `;

  function ui() {
    if (host) return;
    host = document.createElement("div");
    host.style.cssText = "all:initial;position:fixed;z-index:2147483647;display:none;";
    root = host.attachShadow({ mode: "closed" });
    const sheet = new CSSStyleSheet(); // constructable sheets are not subject to the page's inline-style CSP
    sheet.replaceSync(CSS);
    root.adoptedStyleSheets = [sheet];
    const wrap = document.createElement("div");
    wrap.className = "wrap";
    btn = document.createElement("button");
    label = document.createElement("span");
    btn.append("\u2B07", label);
    menu = document.createElement("div");
    menu.className = "menu";
    menu.hidden = true;
    wrap.append(btn, menu);
    root.append(wrap);
    try { chrome.storage.local.get({ pdmBtn: off }).then((v) => { off = v.pdmBtn; }); } catch {}
    let from = null;
    btn.addEventListener("pointerdown", (e) => {
      if (e.button !== 0 || !target) return;
      from = { x: e.clientX, y: e.clientY, ox: off.x, oy: off.y };
      moved = false;
      btn.setPointerCapture(e.pointerId);
    });
    btn.addEventListener("pointermove", (e) => {
      if (!from) return;
      if (!moved && Math.hypot(e.clientX - from.x, e.clientY - from.y) < 4) return;
      moved = dragging = true;
      const r = target.getBoundingClientRect();
      off = { x: Math.max(0, Math.min(from.ox + e.clientX - from.x, r.width - 70)), y: Math.max(0, Math.min(from.oy + e.clientY - from.y, r.height - 26)) };
      place(r.left + off.x, r.top + off.y);
    });
    btn.addEventListener("pointerup", () => {
      if (!from) return;
      from = null;
      dragging = false;
      if (moved) try { chrome.storage.local.set({ pdmBtn: off }); } catch {}
    });
    btn.addEventListener("click", (e) => { e.stopPropagation(); if (moved) { moved = false; return; } menuOpen ? closeMenu() : openMenu(); });
    host.addEventListener("mouseenter", () => clearTimeout(hideTimer));
    host.addEventListener("mouseleave", () => scheduleHide(900));
    setLabel(false);
  }

  const isAudio = () => target && target.localName === "audio";
  function setLabel(text) { label.textContent = text || (isAudio() ? "Download this audio" : "Download this video"); }

  function place(left, top) {
    const parent = document.fullscreenElement || document.documentElement;
    if (host.parentNode !== parent) parent.append(host);
    host.style.left = Math.max(4, Math.min(left, innerWidth - 200)) + "px";
    host.style.top = Math.max(4, Math.min(top, innerHeight - 40)) + "px";
    host.style.display = "block";
  }

  function show(el, r) {
    if (menuOpen) return;
    ui();
    clearTimeout(hideTimer);
    target = el;
    if (!resetTimer) setLabel(false);
    r ? place(r.left + off.x, r.top + off.y) : place(innerWidth - 230, 12);
  }

  function scheduleHide(ms) {
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => { if (!menuOpen && !dragging && host) host.style.display = "none"; }, ms);
  }

  function closeMenu() {
    menuOpen = false;
    if (menu) menu.hidden = true;
    scheduleHide(1200);
  }

  // ---- gathering candidates: the page's media elements plus files the browser saw loading (background.js) ----
  const MIME_LABEL = { "video/mp4": "MP4", "video/webm": "WEBM", "video/x-matroska": "MKV", "video/quicktime": "MOV", "video/x-flv": "FLV", "video/3gpp": "3GP",
    "audio/mpeg": "MP3", "audio/mp3": "MP3", "audio/mp4": "M4A", "audio/x-m4a": "M4A", "audio/aac": "AAC", "audio/ogg": "OGG", "audio/opus": "OPUS",
    "audio/flac": "FLAC", "audio/wav": "WAV", "audio/x-wav": "WAV" };
  const PAGE_EXT = new Set(["php", "asp", "aspx", "jsp", "cgi", "html", "htm", "do", "action", "ashx"]);
  const extOf = (u) => { try { const m = /\.([a-z0-9]{2,5})$/i.exec(new URL(u).pathname); return m ? m[1].toLowerCase() : ""; } catch { return ""; } };
  // The server's Content-Type beats the URL: "video.php" served as video/mp4 is an MP4.
  function typeLabel(it) {
    if (it.hls) return (it.ext || "ts").toUpperCase();
    const m = MIME_LABEL[(it.mime || "").toLowerCase()];
    if (m) return m;
    const e = extOf(it.url);
    if (e && !PAGE_EXT.has(e)) return e.toUpperCase();
    const sub = (it.mime || "").split("/")[1];
    return sub ? sub.replace(/^x-/, "").toUpperCase() : "MEDIA";
  }
  const hlsTarget = (it) => { if (!it.hls) return it.url; const u = new URL(it.url); u.hash = "pdm-hls"; return u.href; }; // tells the engine it is HLS
  const fmtTime = (s) => (s >= 3600 ? Math.floor(s / 3600) + ":" : "") + String(Math.floor((s % 3600) / 60)).padStart(2, "0") + ":" + String(Math.floor(s % 60)).padStart(2, "0");
  const fmtSize = (b) => (b >= 1073741824 ? (b / 1073741824).toFixed(2) + " GB" : b >= 1048576 ? (b / 1048576).toFixed(1) + " MB" : Math.round(b / 1024) + " KB");

  function collect(sniffed) {
    const map = new Map();
    const put = (url, info) => {
      if (!/^https?:/i.test(url || "")) return; // blob:/data: streams cannot be fetched by PDM
      const o = map.get(url) || { url };
      for (const k in info) if (info[k]) o[k] = info[k];
      map.set(url, o);
    };
    for (const el of document.querySelectorAll("video,audio")) {
      const dims = { h: el.videoHeight, d: isFinite(el.duration) ? el.duration : 0 };
      put(el.currentSrc, dims);
      put(el.src, el.src === el.currentSrc ? dims : {});
      for (const s of el.querySelectorAll("source[src]")) put(s.src, s.src === el.currentSrc ? dims : {});
    }
    for (const s of sniffed) put(s.url, s);
    return [...map.values()].sort((a, b) => (b.h || 0) - (a.h || 0) || (b.size || 0) - (a.size || 0));
  }

  function row(cls, children, onClick) {
    const r = document.createElement("div");
    r.className = "row " + cls;
    for (const [c, text] of children) { const s = document.createElement("span"); s.className = c; s.textContent = text; r.append(s); }
    if (onClick) r.addEventListener("click", (e) => { e.stopPropagation(); onClick(); });
    menu.append(r);
  }

  // PDM can also hand the page itself to yt-dlp + ffmpeg: it handles YouTube and most video sites, joins separate
  // video/audio streams and lets you pick the quality. If a site is unsupported PDM shows yt-dlp's error.
  const ytPage = () => (/^(www\.|m\.|music\.)?youtube\.com$/.test(location.hostname) && /^\/(watch|shorts\/)/.test(location.pathname)) || location.hostname === "youtu.be";
  const YT_EXT = { "video/mp4": "mp4", "video/webm": "webm", "audio/mp4": "m4a", "audio/webm": "webm" };
  // After the extension is reloaded or updated, the copy already running in an open tab loses chrome.runtime.
  const alive = () => { try { return !!(chrome.runtime && chrome.runtime.id); } catch { return false; } };
  const STALE = "the PDM extension was reloaded: refresh this page (F5) and try again";
  let useYt = false; // the "Allow yt-dlp" switch in the popup; off by default
  const viaYtdlp = () => sendUrls([location.href], { ytdlp: true });

  function render(items, problem, sabr) {
    menu.textContent = "";
    const title = (document.title || location.hostname).replace(/\s+/g, " ").trim();
    const yt = ytPage();
    if (yt && useYt) row("all", [["t", "Download with PDM (video + audio, pick quality)"], ["m", "yt-dlp"]], viaYtdlp);
    if (problem) row("dim", [["t", problem]]);
    if (sabr && !items.some((i) => i.yt)) row("dim", [["t", "YouTube is streaming this video over SABR (a framed stream, no file URL), so the browser has nothing to save."]]);
    if (!items.length && !sabr) row("dim", [["t", yt ? "No stream seen yet: let the video play a few seconds, then open this again." : "No direct file was seen. Some players stream in a way PDM cannot save as a file (blob, DRM, live)."]]);
    const ok = items.filter((i) => !i.error && !i.dash);
    if (ok.length > 1 && !yt) row("all", [["t", "Download all"]], () => send(ok));
    items.forEach((it, i) => {
      if (it.error) return row("dim", [["n", i + 1 + "."], ["t", title + " \u2014 " + it.error]]);
      if (it.dash) return useYt ? row("", [["n", i + 1 + "."], ["t", title], ["m", "DASH stream (video and audio apart): via yt-dlp"]], viaYtdlp)
        : row("dim", [["n", i + 1 + "."], ["t", "DASH stream (picture and sound apart): PDM cannot join them without yt-dlp"]]);
      const bits = [typeLabel(it) + " file"]; // title text is untrusted: textContent only
      if (it.h) bits.push(it.h + "p");
      if (it.bw) bits.push(Math.round(it.bw / 1000) + " kbps");
      else if (it.size && it.d) bits.push(Math.round((it.size * 8) / it.d / 1000) + " kbps");
      if (it.only) bits.push(it.only);
      if (it.size) bits.push(fmtSize(it.size));
      else if (it.dur) bits.push(fmtTime(it.dur));
      row("", [["n", i + 1 + "."], ["t", title], ["m", bits.join(", ")]], () => send([it]));
    });
    if (!yt && useYt) row("all", [["t", "Let yt-dlp try this page (video + audio merged)"], ["m", "yt-dlp"]], viaYtdlp);
  }

  async function openMenu() {
    menuOpen = true;
    menu.hidden = false;
    menu.textContent = "";
    row("dim", [["t", "Looking for files\u2026"]]);
    let sniffed = [], problem = "", sabr = false;
    try { useYt = (await chrome.storage.local.get({ ytdlp: false })).ytdlp; } catch {}
    const dom = [];
    for (const el of document.querySelectorAll("video,audio")) for (const u of [el.currentSrc, el.src]) if (/^https?:/i.test(u || "") && !dom.includes(u)) dom.push(u);
    try {
      if (!alive()) throw new Error(STALE);
      const r = (await chrome.runtime.sendMessage({ type: "media-list", dom })) || {};
      sniffed = r.list || [];
      sabr = !!r.sabr;
      if (r.error) problem = "The extension could not build the file list: " + r.error;
    } catch (e) { // say why, and still list what the page itself exposes
      problem = alive() ? "Could not ask the PDM extension for loaded files: " + (e && e.message || e) : "Could not list loaded files: " + STALE + ".";
    }
    render(collect(sniffed), problem, sabr);
  }

  function send(items) {
    // YouTube streams are all called "videoplayback": name the file after the page instead.
    const one = items.length === 1 && items[0].yt ? items[0] : null;
    const name = one && YT_EXT[one.mime]
      ? (document.title || "video").replace(/ - YouTube$/, "").replace(/[\\/:*?"<>|\s]+/g, " ").trim().slice(0, 120) + (one.only === "audio only" ? " (audio)" : "") + "." + YT_EXT[one.mime]
      : undefined;
    return sendUrls(items.map(hlsTarget), { name });
  }

  async function sendUrls(urls, extra = {}) {
    closeMenu();
    setLabel("Sending\u2026");
    let r;
    try {
      if (!alive()) throw new Error(STALE);
      r = await chrome.runtime.sendMessage({ type: "send", urls, referer: location.href, name: extra.name, ytdlp: !!extra.ytdlp, source: "button" });
    } catch (e) {
      r = { ok: false, error: e && e.message ? e.message : String(e) };
    }
    setLabel(r && r.ok ? "Sent to PDM \u2714" : "PDM: " + ((r && r.error) || "failed"));
    clearTimeout(resetTimer);
    resetTimer = setTimeout(() => { resetTimer = 0; setLabel(false); }, 2500);
  }

  // ---- when to show the button ----
  addEventListener("mousemove", (e) => {
    const now = performance.now();
    if (now - lastMove < 200) return;
    lastMove = now;
    if (menuOpen || dragging || (host && e.composedPath().includes(host))) return;
    for (const v of document.getElementsByTagName("video")) { // live collection: empty on most pages
      const r = v.getBoundingClientRect();
      if (r.width >= MIN_W && r.height >= MIN_H && e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom) {
        return show(v, r);
      }
    }
    for (const a of document.getElementsByTagName("audio")) { // music players hide their <audio>: corner button while it plays
      if (!a.paused && !a.ended) return show(a, null);
    }
    if (host && host.style.display !== "none") scheduleHide(900);
  }, { passive: true, capture: true });

  // "play" does not bubble, so listen in the capture phase. Audio and hidden players get a corner button.
  document.addEventListener("play", (e) => {
    const el = e.target;
    if (!el || (el.localName !== "video" && el.localName !== "audio") || innerWidth < 160 || innerHeight < 60) return;
    const r = el.getBoundingClientRect();
    show(el, el.localName === "video" && r.width >= MIN_W && r.height >= MIN_H ? r : null);
    scheduleHide(4000);
  }, true);

  document.addEventListener("click", (e) => { if (menuOpen && host && !e.composedPath().includes(host)) closeMenu(); }, true);
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && menuOpen) closeMenu(); }, true);
})();
