const box = document.getElementById("icpt");
chrome.storage.local.get({ intercept: false }).then((s) => (box.checked = s.intercept));
box.onchange = () => chrome.storage.local.set({ intercept: box.checked });
const ytd = document.getElementById("ytd");
chrome.storage.local.get({ ytdlp: false }).then((s) => (ytd.checked = s.ytdlp));
ytd.onchange = () => chrome.storage.local.set({ ytdlp: ytd.checked });
chrome.runtime.sendNativeMessage("com.pdm.host", { action: "ping" }, (r) => {
  const e = chrome.runtime.lastError;
  document.getElementById("st").textContent = e ? "Not connected: run pdm-host.exe --install (" + e.message + ")" : r && r.ok ? (r.engine ? "PDM is running" : "PDM is not running (it starts only when you send a download)") : "PDM: " + ((r && r.error) || "unreachable");
});
