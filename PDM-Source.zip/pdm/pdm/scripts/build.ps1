<#
 Build PDM on Windows (MSVC 2022 + Rust stable + Flutter stable with Windows desktop enabled).
 Usage:  powershell -ExecutionPolicy Bypass -File scripts\build.ps1 [-Config Release]
 Output: dist\ (pdm.exe, pdmd.exe, pdm-host.exe, extension\).
 Never run by the author: expect to report first-run errors.
#>
param(
  [ValidateSet('Release','Debug')][string]$Config = 'Release',
  # Use the flutter-io.cn mirrors when pub.dev / storage.googleapis.com are unreachable (a third party then serves your packages).
  [switch]$Mirror
)
if ($Mirror) { $env:PUB_HOSTED_URL = 'https://pub.flutter-io.cn'; $env:FLUTTER_STORAGE_BASE_URL = 'https://storage.flutter-io.cn' }
$ErrorActionPreference = 'Stop'
$repo = Split-Path -Parent $PSScriptRoot
Set-Location $repo

function Require($name) { if (-not (Get-Command $name -ErrorAction SilentlyContinue)) { throw "Missing required tool: $name (see docs/BUILD.md)" } }
foreach ($t in 'cargo','flutter','python') { Require $t }

# --- Rust: engine + native messaging host ---
cargo build --release --workspace
if ($LASTEXITCODE) { throw 'cargo build failed' }

# --- Flutter UI (the Windows runner is generated once by `flutter create`, then renamed to pdm.exe) ---
$ui = Join-Path $repo 'ui_flutter'
Push-Location $ui
if (-not (Test-Path 'windows')) {
  flutter create --platforms=windows --project-name pdm_ui --org com.pdm .   # its own pub get may fail offline; the real check is `flutter pub get` below
  if (-not (Test-Path 'windows')) { throw 'flutter create failed' }
}
# Idempotent, so a half-finished earlier run is repaired instead of skipped.
Remove-Item test -Recurse -Force -ErrorAction SilentlyContinue   # template test references the template app
(Get-Content windows\CMakeLists.txt) -replace 'set\(BINARY_NAME "[^"]*"\)', 'set(BINARY_NAME "pdm")' | Set-Content windows\CMakeLists.txt
(Get-Content windows\runner\main.cpp) -replace 'L"pdm_ui"', 'L"Pervert Download Manager"' | Set-Content windows\runner\main.cpp
Copy-Item assets\app_icon.ico windows\runner\resources\app_icon.ico -Force
flutter pub get
if ($LASTEXITCODE) { throw 'flutter pub get failed. If it says authorization failed / cannot reach pub.dev, run build.ps1 -Mirror (or use a VPN/proxy).' }
flutter build windows --$($Config.ToLower())
if ($LASTEXITCODE) { throw 'flutter build failed' }
Pop-Location

# --- Stage ---
$dist = Join-Path $repo 'dist'
if (Test-Path $dist) { Remove-Item -Recurse -Force $dist }
New-Item -ItemType Directory $dist | Out-Null
Copy-Item (Join-Path $ui "build\windows\x64\runner\$Config\*") $dist -Recurse
foreach ($b in 'pdmd','pdm-host') { Copy-Item (Join-Path $repo "target\release\$b.exe") $dist }
Copy-Item (Join-Path $repo 'extension') (Join-Path $dist 'extension') -Recurse

# --- Embedded-browser guard on the staged output ---
python tools\check_no_webengine.py --dist $dist
if ($LASTEXITCODE) { throw 'embedded-browser check failed' }
Write-Host "Build OK: $dist ($Config)"
