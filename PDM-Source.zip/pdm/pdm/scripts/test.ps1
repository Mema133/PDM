<#
 Run every Milestone 1 test on Windows. Run scripts\build.ps1 first.
 Usage:  powershell -ExecutionPolicy Bypass -File scripts\test.ps1
 Prints one PASS/FAIL line per step and exits non-zero if any step failed.
#>
$ErrorActionPreference = 'Continue'
$repo = Split-Path -Parent $PSScriptRoot
Set-Location $repo
$results = @()
function Step($name, [scriptblock]$body) {
  Write-Host "== $name"
  & $body
  $ok = ($LASTEXITCODE -eq 0)
  $script:results += [pscustomobject]@{ Step = $name; Result = $(if ($ok) { 'PASS' } else { 'FAIL' }) }
}

# Same MSVC environment as the build (cargo needs the linker).
$vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
$vs = & $vswhere -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
cmd /c "`"$(Join-Path $vs 'VC\Auxiliary\Build\vcvars64.bat')`" >nul && set" | ForEach-Object { if ($_ -match '^(.*?)=(.*)$') { Set-Item -Path "env:$($Matches[1])" -Value $Matches[2] } }

Step 'cargo test (proto, engine incl. named pipe, core)' { cargo test --workspace --no-fail-fast }
Step 'embedded-browser checker self-test'               { python tools\test_check_no_webengine.py }
Step 'embedded-browser check (sources + dist)'          { python tools\check_no_webengine.py --dist dist }
Step 'flutter analyze'                                   { Push-Location ui_flutter; flutter analyze; $code = $LASTEXITCODE; Pop-Location; $global:LASTEXITCODE = $code }

Write-Host ''
$results | Format-Table -AutoSize
if ($results | Where-Object Result -eq 'FAIL') { exit 1 } else { exit 0 }
