#!/usr/bin/env bash
# Portable subset of the tests (Linux/macOS dev machines). Windows: use test.ps1.
# Runs what is available and says what was skipped; never reports a skipped step as passed.
set -u
cd "$(dirname "$0")/.."
fail=0
run() { echo "== $1"; shift; if "$@"; then echo "PASS"; else echo "FAIL"; fail=1; fi; }
skip() { echo "== $1"; echo "SKIPPED ($2)"; }

run "embedded-browser checker self-test" python3 tools/test_check_no_webengine.py
run "embedded-browser check (sources)"   python3 tools/check_no_webengine.py
if command -v node >/dev/null; then run "extension JS syntax" bash -c 'for f in extension/*.js; do node --check "$f" || exit 1; done'
else skip "extension JS syntax" "node not found"; fi
if command -v node >/dev/null; then run "extension background logic" node tools/test_extension_background.js; else skip "extension background logic" "node not found"; fi
if command -v cargo >/dev/null; then run "cargo test --workspace" cargo test --workspace
else skip "cargo test --workspace" "cargo not found"; fi
skip "Flutter UI build/analyze" "requires Flutter + Windows; use scripts/test.ps1"
exit $fail
