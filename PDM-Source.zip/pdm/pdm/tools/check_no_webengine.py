#!/usr/bin/env python3
"""Fail if an embedded browser / web-view dependency is introduced.

Scans (1) source, build and manifest files under --root and (2) an optional
built/staged tree under --dist (file names plus the project's own binaries).

Exit codes: 0 clean, 1 violations found, 2 usage error.
A source line containing the marker `pdm-allow-browser-word` is skipped.
"""
import argparse
import os
import re
import sys

SOURCE_EXTS = {
    ".cpp", ".cc", ".cxx", ".c", ".h", ".hpp", ".hxx", ".rs", ".toml", ".lock",
    ".txt", ".cmake", ".pro", ".pri", ".qrc", ".ui", ".qml", ".ps1", ".rc", ".wxs", ".iss",
}
SKIP_DIRS = {".git", "target", "build", "dist", "node_modules", "docs", "tools", "__pycache__"}
ALLOW_MARKER = "pdm-allow-browser-word"

# (label, regex) applied case-insensitively to source lines.
SOURCE_PATTERNS = [
    ("Qt WebEngine", re.compile(r"webengine", re.I)),
    ("web view (Qt WebView / WebView2)", re.compile(r"webview", re.I)),
    ("WebKit", re.compile(r"webkit", re.I)),
    ("Chromium Embedded Framework", re.compile(r"libcef|\bcef_|chromiumembedded|include/cef", re.I)),
    ("Electron", re.compile(r"\belectron\b", re.I)),
    ("Tauri", re.compile(r"\btauri\b", re.I)),
    ("wry (Rust web-view)", re.compile(r"\bwry\b", re.I)),
]

# Names of files that must not appear in a staged/dist tree.
DIST_NAME_PATTERNS = [
    re.compile(r"^qt6?webengine.*", re.I),
    re.compile(r"^qt6?webview.*", re.I),
    re.compile(r"^qtwebengineprocess\.exe$", re.I),
    re.compile(r"^qtwebengine_.*\.pak$", re.I),
    re.compile(r"^libcef\.dll$", re.I),
    re.compile(r"^chrome_elf\.dll$", re.I),
    re.compile(r"^webview2loader\.dll$", re.I),
    re.compile(r"^electron(\.exe)?$", re.I),
    re.compile(r"^app\.asar$", re.I),
]
# Strings that must not appear inside the project's own binaries.
BINARY_PATTERN = re.compile(rb"Qt6?WebEngine|QtWebView|WebView2Loader|libcef\.dll", re.I)
OWN_BINARIES = {"pdm.exe", "pdmd.exe", "pdm-host.exe", "pdm", "pdmd", "pdm-host"}


def scan_sources(root):
    findings = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for name in filenames:
            ext = os.path.splitext(name)[1].lower()
            if ext not in SOURCE_EXTS and name != "CMakeLists.txt":
                continue
            path = os.path.join(dirpath, name)
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as fh:
                    for lineno, line in enumerate(fh, 1):
                        if ALLOW_MARKER in line:
                            continue
                        # The checker's own file name is not a dependency.
                        probe = line.replace("check_no_webengine", "").replace("test_check_no_webengine", "")
                        for label, pat in SOURCE_PATTERNS:
                            if pat.search(probe):
                                findings.append(f"{path}:{lineno}: prohibited dependency ({label})")
            except OSError as e:
                findings.append(f"{path}: unreadable ({e})")
    return findings


def scan_dist(dist):
    findings = []
    for dirpath, _dirnames, filenames in os.walk(dist):
        for name in filenames:
            path = os.path.join(dirpath, name)
            for pat in DIST_NAME_PATTERNS:
                if pat.match(name):
                    findings.append(f"{path}: prohibited file in distribution")
                    break
            if name.lower() in OWN_BINARIES:
                try:
                    with open(path, "rb") as fh:
                        data = fh.read()
                except OSError as e:
                    findings.append(f"{path}: unreadable ({e})")
                    continue
                m = BINARY_PATTERN.search(data)
                if m:
                    findings.append(f"{path}: binary references prohibited component ({m.group(0).decode('latin1')})")
    return findings


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--root", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
    ap.add_argument("--dist", default=None, help="staged/installed output directory to scan as well")
    args = ap.parse_args(argv)
    if not os.path.isdir(args.root) or (args.dist and not os.path.isdir(args.dist)):
        print("error: --root/--dist must be existing directories", file=sys.stderr)
        return 2
    findings = scan_sources(args.root)
    if args.dist:
        findings += scan_dist(args.dist)
    if findings:
        print("FAIL: prohibited embedded-browser dependencies found:")
        for f in findings:
            print("  " + f)
        return 1
    print("OK: no prohibited embedded-browser dependencies found" + (" (sources + dist)" if args.dist else " (sources)"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
