#!/usr/bin/env python3
"""Self-test for check_no_webengine.py. Run: python tools/test_check_no_webengine.py"""
import contextlib
import io
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import check_no_webengine as chk  # noqa: E402


def write(root, rel, content, binary=False):
    p = os.path.join(root, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "wb" if binary else "w") as fh:
        fh.write(content)
    return p


def run(*argv):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
        rc = chk.main(list(argv))
    return rc, buf.getvalue()


class Checker(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = self.tmp.name

    def tearDown(self):
        self.tmp.cleanup()

    def test_clean_tree_passes(self):
        write(self.root, "ui/CMakeLists.txt", "find_package(Qt6 REQUIRED COMPONENTS Core Gui Widgets Network)\n")
        write(self.root, "Cargo.toml", '[dependencies]\ntokio = "1"\n')
        self.assertEqual(run("--root", self.root)[0], 0)

    def test_cmake_webengine_component_fails(self):
        write(self.root, "ui/CMakeLists.txt", "find_package(Qt6 REQUIRED COMPONENTS Widgets WebEngineWidgets)\n")
        rc, out = run("--root", self.root)
        self.assertEqual(rc, 1)
        self.assertIn("CMakeLists.txt:1", out)

    def test_cpp_include_fails(self):
        write(self.root, "ui/src/a.cpp", "#include <QWebEngineView>\n")
        self.assertEqual(run("--root", self.root)[0], 1)

    def test_webview2_header_fails(self):
        write(self.root, "ui/src/a.h", '#include "WebView2.h"\n')
        self.assertEqual(run("--root", self.root)[0], 1)

    def test_cef_include_fails(self):
        write(self.root, "ui/src/a.cpp", '#include "include/cef_app.h"\n')
        self.assertEqual(run("--root", self.root)[0], 1)

    def test_cargo_tauri_and_wry_fail(self):
        write(self.root, "a/Cargo.toml", '[dependencies]\ntauri = "1"\n')
        self.assertEqual(run("--root", self.root)[0], 1)
        write(self.root, "a/Cargo.toml", '[dependencies]\nwry = "0.3"\n')
        self.assertEqual(run("--root", self.root)[0], 1)

    def test_cargo_lock_transitive_fails(self):
        write(self.root, "Cargo.lock", 'name = "webview2-com"\n')
        self.assertEqual(run("--root", self.root)[0], 1)

    def test_electron_package_word_fails(self):
        write(self.root, "ui/CMakeLists.txt", "# add_subdirectory(electron)\n")
        self.assertEqual(run("--root", self.root)[0], 1)

    def test_docs_and_tools_are_not_scanned(self):
        write(self.root, "docs/NOTES.txt", "We forbid Qt WebEngine and Electron.\n")
        write(self.root, "tools/list.txt", "webengine\n")
        self.assertEqual(run("--root", self.root)[0], 0)

    def test_checker_filename_reference_is_not_a_violation(self):
        write(self.root, "scripts/b.ps1", "python tools\\check_no_webengine.py --dist dist\n")
        self.assertEqual(run("--root", self.root)[0], 0)
        write(self.root, "scripts/b.ps1", "python tools\\check_no_webengine.py # plus WebEngineCore\n")
        self.assertEqual(run("--root", self.root)[0], 1)

    def test_allow_marker(self):
        write(self.root, "ui/src/a.cpp", "// mentions WebEngine only to forbid it pdm-allow-browser-word\n")
        self.assertEqual(run("--root", self.root)[0], 0)

    def test_dist_file_names_fail(self):
        dist = os.path.join(self.root, "dist")
        for name in ["Qt6WebEngineCore.dll", "QtWebEngineProcess.exe", "libcef.dll", "WebView2Loader.dll", "Qt6WebViewQuick.dll"]:
            with self.subTest(name=name):
                write(dist, name, b"x", binary=True)
                self.assertEqual(run("--root", self.root, "--dist", dist)[0], 1)
                os.remove(os.path.join(dist, name))

    def test_dist_clean_passes(self):
        dist = os.path.join(self.root, "dist")
        write(dist, "pdm.exe", b"MZ....Qt6Widgets.dll....", binary=True)
        write(dist, "Qt6Core.dll", b"x", binary=True)
        self.assertEqual(run("--root", self.root, "--dist", dist)[0], 0)

    def test_dist_binary_string_fails(self):
        dist = os.path.join(self.root, "dist")
        write(dist, "pdm.exe", b"MZ....Qt6WebEngineCore.dll....", binary=True)
        rc, out = run("--root", self.root, "--dist", dist)
        self.assertEqual(rc, 1)
        self.assertIn("binary references", out)

    def test_usage_error(self):
        self.assertEqual(run("--root", os.path.join(self.root, "nope"))[0], 2)

    def test_real_repository_is_clean(self):
        repo = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
        rc, out = run("--root", repo)
        self.assertEqual(rc, 0, out)


if __name__ == "__main__":
    unittest.main(verbosity=2)
