// Dashboard: engine status, speed-limit presets, live speed, active tasks, transfer totals and a year of activity.
// Everything is derived from the download list (no extra storage); colours come from the current theme.
import 'package:flutter/material.dart';

import 'state.dart';
import 'ui.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override
  State<DashboardPage> createState() => _DashboardState();
}

class _DashboardState extends State<DashboardPage> {
  bool allTime = false;

  // 🐇 unlimited, 🐢 slow, 🐿️ medium (bytes per second; 0 = unlimited in the engine)
  static const _modes = [('🐇', 'Unlimited', 0), ('🐢', 'Slow  -  256 KB/s', 262144), ('🐿️', 'Medium  -  1 MB/s', 1048576)];

  Widget _card(String title, Widget body, {Widget? trailing, required double height}) => Container(
        height: height,
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: surfaceOf(context), borderRadius: BorderRadius.circular(20), border: Border.all(color: borderOf(context))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(title, style: TextStyle(color: dimOf(context), fontSize: 11.5, fontWeight: FontWeight.w700, letterSpacing: 1))),
            if (trailing != null) trailing,
          ]),
          const SizedBox(height: 6),
          Expanded(child: body),
        ]),
      );

  Widget _big(String text, [String unit = '']) => Row(crossAxisAlignment: CrossAxisAlignment.baseline, textBaseline: TextBaseline.alphabetic, children: [
        Text(text, style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w700)),
        if (unit.isNotEmpty) Padding(padding: const EdgeInsets.only(left: 6), child: Text(unit, style: TextStyle(fontSize: 14, color: dimOf(context)))),
      ]);

  (String, String) _parts(num b, {bool perSec = false}) {
    if (b <= 0) return ('0', perSec ? 'B/s' : 'B');
    final s = humanSize(b).split(' ');
    return (s[0], perSec ? '${s[1]}/s' : s[1]);
  }

  Widget _stat(String n, String label) => Expanded(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(n, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
          Text(label, style: TextStyle(fontSize: 11, color: dimOf(context), letterSpacing: 0.6)),
        ]),
      );

  Widget _seg(String t, bool on, VoidCallback f) => Hover(
        onTap: f,
        builder: (_) => Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
          decoration: BoxDecoration(color: on ? surface2Of(context) : Colors.transparent, borderRadius: BorderRadius.circular(8)),
          child: Text(t, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: on ? null : dimOf(context))),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final a = accentOf(context);
    final ds = app.downloads;
    final running = ds.where((d) => d.status == 'running').length;
    final queued = ds.where((d) => d.status == 'queued').length;
    final paused = ds.where((d) => d.status == 'paused').length;

    final now = DateTime.now();
    bool isToday(Dl d) {
      if (d.date <= 0) return false;
      final t = DateTime.fromMillisecondsSinceEpoch(d.date * 1000);
      return t.year == now.year && t.month == now.month && t.day == now.day;
    }

    int bytes(Dl d) => d.status == 'completed' ? d.total : d.downloaded;
    final pool = allTime ? ds : ds.where(isToday).toList();
    final sum = pool.fold<int>(0, (s, d) => s + bytes(d));
    final all = ds.fold<int>(0, (s, d) => s + bytes(d));
    final files = pool.where((d) => d.status == 'completed').length;

    final limit = (app.settings['global_speed_limit'] ?? 0) as int;
    final modeLabel = _modes.any((m) => m.$3 == limit) ? _modes.firstWhere((m) => m.$3 == limit).$2 : 'Custom  -  ${humanSize(limit)}/s';
    final sp = _parts(app.totalSpeed, perSec: true);
    final tr = _parts(sum);

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(26, 18, 26, 22),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Dashboard', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
        const SizedBox(height: 18),
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            child: _card(
              'ENGINE',
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(app.connected ? 'Ready' : 'Offline', style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w700)),
                const Spacer(),
                Row(children: [
                  Expanded(child: Text(app.connected && app.ipc.serverVersion.isNotEmpty ? 'pdmd v${app.ipc.serverVersion}' : 'pdmd', style: TextStyle(color: dimOf(context), fontSize: 12.5))),
                  Container(width: 10, height: 10, decoration: BoxDecoration(shape: BoxShape.circle, color: app.connected ? const Color(0xFF22C55E) : const Color(0xFFEF4444))),
                ]),
              ]),
              height: 160,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: _card(
              'SPEED LIMIT',
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const SizedBox(height: 6),
                Row(children: [
                  for (final m in _modes)
                    Padding(
                      padding: const EdgeInsets.only(right: 10),
                      child: Hover(
                        onTap: () async {
                          final e = await app.act('settings.set', {'global_speed_limit': m.$3});
                          if (e != null && context.mounted) toast(context, e);
                        },
                        builder: (h) => Container(
                          width: 46,
                          height: 46,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), color: limit == m.$3 ? surface2Of(context) : (h ? surface2Of(context).withAlpha(110) : Colors.transparent), border: Border.all(color: limit == m.$3 ? a : Colors.transparent)),
                          child: Text(m.$1, style: const TextStyle(fontSize: 24)),
                        ),
                      ),
                    ),
                ]),
                const Spacer(),
                Text(modeLabel, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
              ]),
              trailing: Hover(onTap: () => app.setPage(2), builder: (_) => Icon(Icons.settings_outlined, size: 18, color: dimOf(context))),
              height: 160,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: _card(
              'DOWNLOAD',
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                _big(sp.$1, sp.$2),
                const Spacer(),
                Sparkline(app.speedHist, a, height: 46),
              ]),
              height: 160,
            ),
          ),
        ]),
        const SizedBox(height: 16),
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            child: _card(
              'ACTIVE TASKS',
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                _big('${running + queued}'),
                const Spacer(),
                Row(children: [_stat('$running', 'DOWNLOADING'), _stat('$queued', 'WAITING'), _stat('$paused', 'PAUSED')]),
              ]),
              trailing: Container(width: 10, height: 10, decoration: BoxDecoration(shape: BoxShape.circle, color: running > 0 ? const Color(0xFF22C55E) : dimOf(context).withAlpha(120))),
              height: 200,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: _card(
              'TRANSFER',
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                _big(tr.$1, tr.$2),
                const Spacer(),
                Row(children: [
                  _stat('$files', 'FILES'),
                  Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                    Text(humanSize(sum) == '--' ? '0 B' : humanSize(sum), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                    Text('DOWNLOADED', style: TextStyle(fontSize: 11, color: dimOf(context), letterSpacing: 0.6)),
                  ]),
                ]),
                const SizedBox(height: 8),
                Bar(allTime ? (all > 0 ? 1.0 : 0.0) : (all > 0 ? sum / all : 0.0), height: 22, color: a),
              ]),
              trailing: Container(
                decoration: BoxDecoration(color: Colors.black.withAlpha(60), borderRadius: BorderRadius.circular(10)),
                child: Row(mainAxisSize: MainAxisSize.min, children: [_seg('Today', !allTime, () => setState(() => allTime = false)), _seg('All Time', allTime, () => setState(() => allTime = true))]),
              ),
              height: 200,
            ),
          ),
        ]),
        const SizedBox(height: 16),
        _card('ACTIVITY', _Heat(ds.where((d) => d.status == 'completed').map((d) => d.date).toList()), height: 236),
      ]),
    );
  }
}

/// A year of finished downloads, one square per day (GitHub style), Monday on the first row.
class _Heat extends StatelessWidget {
  final List<int> stamps;
  const _Heat(this.stamps);

  static const _months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  @override
  Widget build(BuildContext context) {
    final a = accentOf(context);
    final n = DateTime.now();
    final today = DateTime(n.year, n.month, n.day);
    final perDay = <DateTime, int>{};
    for (final s in stamps) {
      if (s <= 0) continue;
      final t = DateTime.fromMillisecondsSinceEpoch(s * 1000);
      final k = DateTime(t.year, t.month, t.day);
      perDay[k] = (perDay[k] ?? 0) + 1;
    }
    final most = perDay.values.fold<int>(1, (m, v) => v > m ? v : m);
    const weeks = 53;
    final start = today.subtract(Duration(days: (weeks - 1) * 7 + today.weekday - 1));
    Color level(int l) => l == 0 ? surface2Of(context) : a.withAlpha(60 + l * 48);

    return LayoutBuilder(builder: (context, box) {
      const gap = 3.0, labelW = 34.0;
      final cell = ((box.maxWidth - labelW - weeks * gap) / weeks).clamp(5.0, 14.0).toDouble();
      DateTime day(int c, int r) => DateTime(start.year, start.month, start.day + c * 7 + r);
      return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(
          height: 16,
          child: Stack(children: [
            for (var c = 0; c < weeks; c++)
              if (c == 0 || day(c, 0).month != day(c - 1, 0).month) Positioned(left: labelW + c * (cell + gap), child: Text(_months[day(c, 0).month - 1], style: TextStyle(fontSize: 11, color: dimOf(context)))),
          ]),
        ),
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(
            width: labelW,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              for (var r = 0; r < 7; r++) SizedBox(height: cell + gap, child: Text(r == 0 ? 'Mon' : (r == 2 ? 'Wed' : (r == 4 ? 'Fri' : '')), style: TextStyle(fontSize: 10.5, color: dimOf(context), height: 1))),
            ]),
          ),
          for (var c = 0; c < weeks; c++)
            Padding(
              padding: const EdgeInsets.only(right: gap),
              child: Column(children: [
                for (var r = 0; r < 7; r++)
                  Container(
                    width: cell,
                    height: cell,
                    margin: const EdgeInsets.only(bottom: gap),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(2),
                      color: day(c, r).isAfter(today) ? Colors.transparent : level(((perDay[day(c, r)] ?? 0) * 4 / most).ceil()),
                    ),
                  ),
              ]),
            ),
        ]),
        const Spacer(),
        Align(
          alignment: Alignment.centerRight,
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Text('Less ', style: TextStyle(fontSize: 11, color: dimOf(context))),
            for (var l = 0; l <= 4; l++) Container(width: 10, height: 10, margin: const EdgeInsets.only(left: 3), decoration: BoxDecoration(borderRadius: BorderRadius.circular(2), color: level(l))),
            Text('  More', style: TextStyle(fontSize: 11, color: dimOf(context))),
          ]),
        ),
      ]);
    });
  }
}
