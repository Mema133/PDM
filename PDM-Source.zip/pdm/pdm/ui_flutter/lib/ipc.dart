// Named-pipe client for pdmd (protocol v1: u32-LE length + JSON). Windows only, via kernel32 FFI.
// Blocking pipe I/O lives in a worker isolate so the UI thread never stalls.
import 'dart:async';
import 'dart:convert';
import 'dart:ffi';
import 'dart:io';
import 'dart:isolate';
import 'dart:typed_data';

import 'package:ffi/ffi.dart';

class IpcError implements Exception {
  final String message;
  IpcError(this.message);
  @override
  String toString() => message;
}

typedef _CreateFileN = IntPtr Function(Pointer<Utf16>, Uint32, Uint32, Pointer<Void>, Uint32, Uint32, IntPtr);
typedef _CreateFileD = int Function(Pointer<Utf16>, int, int, Pointer<Void>, int, int, int);
typedef _IoN = Int32 Function(IntPtr, Pointer<Uint8>, Uint32, Pointer<Uint32>, Pointer<Void>);
typedef _IoD = int Function(int, Pointer<Uint8>, int, Pointer<Uint32>, Pointer<Void>);

String pipeName() {
  String clean(String s) {
    final c = s.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_');
    final t = c.length > 32 ? c.substring(0, 32) : c;
    return t.isEmpty ? 'user' : t;
  }

  final env = Platform.environment['PDM_PIPE_NAME'] ?? '';
  return env.isNotEmpty ? clean(env) : 'pdm-v1-${clean(Platform.environment['USERNAME'] ?? '')}';
}

// ---- worker isolate -------------------------------------------------------------------------
void _worker(SendPort out) {
  final k32 = DynamicLibrary.open('kernel32.dll');
  final createFile = k32.lookupFunction<_CreateFileN, _CreateFileD>('CreateFileW');
  final readFile = k32.lookupFunction<_IoN, _IoD>('ReadFile');
  final writeFile = k32.lookupFunction<_IoN, _IoD>('WriteFile');
  final closeHandle = k32.lookupFunction<Int32 Function(IntPtr), int Function(int)>('CloseHandle');
  int h = -1;

  Uint8List readExact(int n) {
    final buf = calloc<Uint8>(n);
    final got = calloc<Uint32>();
    try {
      var off = 0;
      while (off < n) {
        if (readFile(h, buf + off, n - off, got, nullptr) == 0 || got.value == 0) throw IpcError('pipe read failed');
        off += got.value;
      }
      return Uint8List.fromList(buf.asTypedList(n));
    } finally {
      calloc.free(buf);
      calloc.free(got);
    }
  }

  void writeAll(Uint8List data) {
    final buf = calloc<Uint8>(data.length);
    final put = calloc<Uint32>();
    try {
      buf.asTypedList(data.length).setAll(0, data);
      var off = 0;
      while (off < data.length) {
        if (writeFile(h, buf + off, data.length - off, put, nullptr) == 0) throw IpcError('pipe write failed');
        off += put.value;
      }
    } finally {
      calloc.free(buf);
      calloc.free(put);
    }
  }

  final inbox = ReceivePort();
  out.send(inbox.sendPort);
  inbox.listen((m) {
    final msg = m as List;
    final reply = msg.last as SendPort;
    try {
      switch (msg[0] as String) {
        case 'open':
          final p = ('\\\\.\\pipe\\${msg[1]}').toNativeUtf16();
          // GENERIC_READ | GENERIC_WRITE, OPEN_EXISTING
          h = createFile(p, 0xC0000000, 0, nullptr, 3, 0, 0);
          calloc.free(p);
          if (h == -1) throw IpcError('engine pipe not available');
          reply.send([true, '']);
        case 'rpc':
          final body = utf8.encode(msg[1] as String);
          final frame = Uint8List(4 + body.length)
            ..buffer.asByteData().setUint32(0, body.length, Endian.little)
            ..setAll(4, body);
          writeAll(frame);
          final len = readExact(4).buffer.asByteData().getUint32(0, Endian.little);
          reply.send([true, utf8.decode(readExact(len))]);
        case 'close':
          if (h != -1) closeHandle(h);
          h = -1;
          reply.send([true, '']);
      }
    } catch (e) {
      if (h != -1) closeHandle(h);
      h = -1;
      reply.send([false, e.toString()]);
    }
  });
}

class Ipc {
  SendPort? _tx;
  Future<bool>? _connecting;
  bool connected = false;
  String serverVersion = '';
  int _n = 0;

  Future<List> _ask(List msg) async {
    final rp = ReceivePort();
    _tx!.send([...msg, rp.sendPort]);
    final r = await rp.first as List;
    rp.close();
    return r;
  }

  Future<bool> _open() async {
    if (_tx == null) {
      final rp = ReceivePort();
      await Isolate.spawn(_worker, rp.sendPort);
      _tx = await rp.first as SendPort;
    }
    if (!(await _ask(['open', pipeName()]))[0]) return false;
    final r = await _rpc('hello', {'client': 'pdm-ui/0.1.0'});
    serverVersion = (r?['server_version'] ?? '') as String;
    return r != null;
  }

  Future<Map<String, dynamic>?> _rpc(String method, Map<String, dynamic> params) async {
    final id = 'r${++_n}';
    final r = await _ask([
      'rpc',
      jsonEncode({'v': 1, 'id': id, 'type': 'request', 'method': method, 'params': params})
    ]);
    if (r[0] != true) {
      connected = false;
      throw IpcError(r[1] as String);
    }
    final m = jsonDecode(r[1] as String) as Map<String, dynamic>;
    if (m['type'] == 'error') throw IpcError((m['error'] as Map)['message'] as String);
    return ((m['result'] ?? {}) as Map).cast<String, dynamic>();
  }

  /// Connect, starting pdmd.exe (next to pdm.exe) if the pipe is missing.
  Future<bool> connect({bool startEngine = true}) {
    if (connected) return Future.value(true);
    return _connecting ??= () async {
      try {
        if (await _open()) return connected = true;
        if (!startEngine) return false;
        final exe = '${File(Platform.resolvedExecutable).parent.path}\\pdmd.exe';
        await Process.start(exe, [], mode: ProcessStartMode.detached);
        for (var i = 0; i < 50; i++) {
          await Future<void>.delayed(const Duration(milliseconds: 100));
          if (await _open()) return connected = true;
        }
        return false;
      } catch (_) {
        return false;
      } finally {
        _connecting = null;
      }
    }();
  }

  Future<Map<String, dynamic>> call(String method, [Map<String, dynamic> params = const {}]) async {
    if (!await connect()) throw IpcError('PDM engine is not running');
    return (await _rpc(method, params))!;
  }
}
