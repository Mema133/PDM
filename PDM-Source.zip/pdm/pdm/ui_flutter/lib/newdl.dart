// "New download" confirmation window: address, file name, category, save folder, size, segments.
// Opened by the New button and for every single download the browser extension sends.
import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';

import 'state.dart';
import 'ui.dart';
import 'ytdlp.dart';

final _httpUrl = RegExp(r'^https?://\S+$', caseSensitive: false);
final _absDir = RegExp(r'^([A-Za-z]:\\|\\\\)');
const _cats = [('documents', 'Documents'), ('compressed', 'Compressed'), ('music', 'Music'), ('video', 'Video'), ('programs', 'Programs'), ('other', 'Other')];
const _segments = [1, 2, 4, 8, 16, 32];
// Which extension feature sent the request: shown in the window so a surprise window can be traced.
const _sources = {'capture': '  -  a browser download was captured', 'menu': '  -  right-click menu', 'button': '  -  video button', 'grabber': '  -  link list', 'page': '  -  browser extension'};

Future<void> showNewDownload(BuildContext context, {String url = '', String referer = '', String name = '', String cookie = '', String cookies = '', String source = '', bool ytdlp = false}) =>
    showDialog<void>(context: context, barrierDismissible: false, builder: (_) => NewDownloadDialog(url: url, referer: referer, name: name, cookie: cookie, cookies: cookies, source: source, ytdlp: ytdlp));

String? _dispName(String? h) {
  if (h == null) return null;
  final star = RegExp(r"filename\*\s*=\s*[^']*'[^']*'([^;]+)", caseSensitive: false).firstMatch(h);
  if (star != null) {
    try {
      return Uri.decodeComponent(star.group(1)!.trim());
    } catch (_) {}
  }
  return RegExp(r'filename\s*=\s*"?([^";]+)"?', caseSensitive: false).firstMatch(h)?.group(1)?.trim();
}

String _nameFor(String url, String? disposition) {
  final d = _dispName(disposition);
  if (d != null && d.isNotEmpty) return d;
  final seg = Uri.tryParse(url)?.pathSegments.where((s) => s.isNotEmpty).toList() ?? [];
  if (seg.isEmpty) return '';
  try {
    return Uri.decodeComponent(seg.last);
  } catch (_) {
    return seg.last;
  }
}

/// Size and name the server reports for [url]; null if it cannot be reached (the download may still work).
Future<({int size, String name})?> _probe(String url, String referer, String cookie) async {
  final c = HttpClient()
    ..connectionTimeout = const Duration(seconds: 8)
    ..userAgent = 'Mozilla/5.0 PDM';
  try {
    final rq = await c.getUrl(Uri.parse(url));
    rq.headers.set('range', 'bytes=0-0');
    if (referer.isNotEmpty) rq.headers.set('referer', referer);
    if (cookie.isNotEmpty) rq.headers.set('cookie', cookie);
    final rs = await rq.close().timeout(const Duration(seconds: 10));
    if (rs.statusCode >= 400) return null;
    var size = rs.contentLength;
    final total = RegExp(r'/(\d+)\s*$').firstMatch(rs.headers.value('content-range') ?? '');
    if (rs.statusCode == 206 && total != null) size = int.parse(total.group(1)!);
    return (size: size < 0 ? 0 : size, name: _nameFor(url, rs.headers.value('content-disposition')));
  } catch (_) {
    return null;
  } finally {
    c.close(force: true); // headers are enough: never read the body
  }
}

class NewDownloadDialog extends StatefulWidget {
  /// cookie: the browser's Cookie header for [url] (direct downloads). cookies: cookies.txt text for yt-dlp.
  /// ytdlp: [url] is a web page that yt-dlp should handle, not a file.
  final String url, referer, name, cookie, cookies, source; // source: which extension feature sent it
  final bool ytdlp;
  const NewDownloadDialog({super.key, this.url = '', this.referer = '', this.name = '', this.cookie = '', this.cookies = '', this.source = '', this.ytdlp = false});
  @override
  State<NewDownloadDialog> createState() => _NewDownloadState();
}

class _NewDownloadState extends State<NewDownloadDialog> {
  late final addr = TextEditingController(text: widget.url);
  late final file = TextEditingController(text: widget.name);
  final dir = TextEditingController();
  String cat = 'other';
  int segs = 8, size = 0, quality = 0; // quality: index into ytQualities (YouTube only)
  String suggested = ''; // last name we filled in ourselves; sent to the engine only when the user changed it
  bool fileEdited = false, catEdited = false, dirEdited = false, busy = false, installing = false;
  String toolMsg = '';
  int waiting = 0; // more browser requests queued behind this window
  String? _cookieFile; // cookies.txt for yt-dlp; handed to the job on Download, otherwise deleted
  String? error;
  Timer? _debounce;
  int _gen = 0;

  @override
  void initState() {
    super.initState();
    waiting = app.pendingCount();
    fileEdited = widget.name.isNotEmpty;
    final s = app.settings['max_conns'];
    if (s is int && _segments.contains(s)) segs = s;
    if (widget.cookies.isNotEmpty && _ytFor(widget.url)) _cookieFile = writeCookies(widget.cookies);
    if (!fileEdited && !_ytFor(widget.url)) file.text = suggested = _nameFor(widget.url, null);
    _setCat(fileType(file.text));
    if (_httpUrl.hasMatch(widget.url)) _probeNow();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    addr.dispose();
    file.dispose();
    dir.dispose();
    deleteQuietly(_cookieFile);
    super.dispose();
  }

  String _dirFor(String t) {
    final base = app.downloadDir.replaceAll(RegExp(r'\\+$'), '');
    return t == 'other' ? app.downloadDir : '$base\\${_cats.firstWhere((c) => c.$1 == t).$2}';
  }

  void _setCat(String t) {
    cat = t;
    if (!dirEdited) dir.text = _dirFor(t);
  }

  // The page address the extension sent, or any YouTube link, goes through yt-dlp; everything else is a plain file.
  bool _ytFor(String v) => (widget.ytdlp && v.trim() == widget.url) || isYoutube(v);
  bool get yt => _ytFor(addr.text);
  String get _cookie => addr.text.trim() == widget.url ? widget.cookie : ''; // never send a site's cookies to another URL

  Future<void> _install() async {
    setState(() {
      installing = true;
      toolMsg = 'Starting…';
      error = null;
    });
    final e = await installVideoTools((m) {
      if (mounted) setState(() => toolMsg = m);
    });
    if (!mounted) return;
    setState(() {
      installing = false;
      error = e;
    });
    if (e == null && yt) _ytProbe();
  }

  /// YouTube page: the title comes from yt-dlp; there is no file size until it runs.
  Future<void> _ytProbe() async {
    final gen = ++_gen;
    final t = await ytTitle(addr.text.trim(), cookies: _cookieFile);
    if (!mounted || gen != _gen || t == null) return;
    setState(() {
      size = 0;
      if (!fileEdited) file.text = t;
      if (!catEdited) _setCat('video');
    });
  }

  Future<void> _probeNow() async {
    if (yt) return _ytProbe();
    final gen = ++_gen;
    final r = await _probe(addr.text.trim(), widget.referer, _cookie);
    if (!mounted || gen != _gen || r == null) return;
    setState(() {
      size = r.size;
      if (r.name.isNotEmpty && !fileEdited) {
        file.text = suggested = r.name;
        if (!catEdited) _setCat(fileType(r.name));
      }
    });
  }

  void _addrChanged(String v) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 600), () {
      if (_httpUrl.hasMatch(addr.text.trim())) _probeNow();
    });
    if (!fileEdited) {
      setState(() {
        file.text = suggested = _ytFor(v) ? '' : _nameFor(v.trim(), null);
        if (!catEdited) _setCat(fileType(file.text));
      });
    }
  }

  Future<void> _submit(bool start) async {
    final url = addr.text.trim(), folder = dir.text.trim(), name = file.text.trim();
    String? err;
    if (!_httpUrl.hasMatch(url)) {
      err = 'Enter a valid http:// or https:// address.';
    } else if (!_absDir.hasMatch(folder)) {
      err = r'Choose an absolute save folder, like C:\Users\you\Downloads.';
    }
    if (err == null && yt && !ytdlpFound) err = 'yt-dlp is not installed yet. Press Download tools first.';
    if (err != null) return setState(() => error = err);
    if (yt) {
      final q = ytQualities[quality];
      app.addYoutube(url, folder, name.isEmpty ? 'video' : name, q.$2, q.$1 == 'Audio only', cookies: _cookieFile);
      _cookieFile = null; // the job owns (and deletes) it now
      if (mounted) Navigator.pop(context);
      return;
    }
    setState(() {
      busy = true;
      error = null;
    });
    final e = await app.act('downloads.add', {
      'url': url,
      'dest_dir': folder,
      'start': start,
      'max_conns': segs,
      if (_cookie.isNotEmpty) 'cookie': _cookie,
      if (name.isNotEmpty && name != suggested) 'filename': name,
      if (_httpUrl.hasMatch(widget.referer)) 'referer': widget.referer,
    });
    if (!mounted) return;
    if (e != null) return setState(() {
      error = e;
      busy = false;
    });
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    const dense = InputDecoration(isDense: true);
    Widget row(String label, Widget field) => Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Row(children: [
            SizedBox(width: 86, child: Text(label, textAlign: TextAlign.right, style: TextStyle(color: dimOf(context)))),
            const SizedBox(width: 14),
            Expanded(child: field),
          ]),
        );
    final t = yt ? (ytQualities[quality].$1 == 'Audio only' ? 'music' : 'video') : fileType(file.text);
    return Dialog(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 700),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Padding(
            padding: const EdgeInsets.only(top: 14),
            child: Text(
              'New download${_sources[widget.source] ?? ''}',
              style: TextStyle(color: dimOf(context), fontWeight: FontWeight.w600),
            ),
          ),
          if (waiting > 0)
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 10, 24, 0),
              child: Row(children: [
                Expanded(child: Text('$waiting more waiting from the browser', style: TextStyle(color: dimOf(context), fontSize: 12.5))),
                PBtn('Discard them', onTap: () {
                  app.discardPending();
                  setState(() => waiting = 0);
                }),
              ]),
            ),
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 22, 24, 6),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(
                child: Column(children: [
                  row('Address', TextField(controller: addr, autofocus: widget.url.isEmpty, onChanged: _addrChanged, decoration: dense)),
                  row('File', TextField(controller: file, decoration: yt ? const InputDecoration(isDense: true, hintText: 'Reading the video title…') : dense, onChanged: (_) {
                    fileEdited = true;
                    if (!catEdited) setState(() => _setCat(fileType(file.text)));
                  })),
                  row(
                    'Category',
                    DropdownButtonFormField<String>(
                      key: ValueKey(cat), // rebuilt when the category is picked automatically
                      initialValue: cat,
                      isDense: true,
                      items: [for (final c in _cats) DropdownMenuItem(value: c.$1, child: Text(c.$2))],
                      onChanged: (v) => setState(() {
                        catEdited = true;
                        _setCat(v ?? cat);
                      }),
                    ),
                  ),
                  if (yt)
                    row(
                      'Quality',
                      DropdownButtonFormField<int>(
                        initialValue: quality,
                        isDense: true,
                        items: [for (var i = 0; i < ytQualities.length; i++) DropdownMenuItem(value: i, child: Text(ytQualities[i].$1))],
                        onChanged: (v) => setState(() {
                          quality = v ?? 0;
                          if (!catEdited) _setCat(ytQualities[quality].$1 == 'Audio only' ? 'music' : 'video');
                        }),
                      ),
                    ),
                  row('Save to', TextField(controller: dir, decoration: dense, onChanged: (_) => dirEdited = true)),
                ]),
              ),
              SizedBox(
                width: 130,
                child: Column(children: [
                  const SizedBox(height: 4),
                  Icon(typeIcon(t), size: 54, color: typeColor(t)),
                  const SizedBox(height: 8),
                  Text(humanSize(size), style: const TextStyle(fontWeight: FontWeight.w600)),
                ]),
              ),
            ]),
          ),
          if (yt && !ytdlpFound)
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 10),
              child: Row(children: [
                Expanded(child: Text(installing ? toolMsg : 'Video downloads need yt-dlp, ffmpeg and deno (about 150 MB, from their official sites). They are not bundled; download them once?', style: TextStyle(color: dimOf(context), fontSize: 12.5))),
                const SizedBox(width: 12),
                PBtn(installing ? 'Downloading…' : 'Download tools', onTap: installing ? null : _install),
              ]),
            ),
          if (error != null) Padding(padding: const EdgeInsets.fromLTRB(24, 0, 24, 8), child: Text(error!, style: const TextStyle(color: Color(0xFFEF4444)))),
          Container(
            padding: const EdgeInsets.fromLTRB(24, 14, 24, 14),
            decoration: BoxDecoration(color: Colors.black.withAlpha(60), borderRadius: const BorderRadius.vertical(bottom: Radius.circular(20))),
            child: Row(children: [
              if (!yt) ...[
                Text('Segments', style: TextStyle(color: dimOf(context))),
                const SizedBox(width: 12),
                SizedBox(
                  width: 84,
                  child: DropdownButtonFormField<int>(
                    initialValue: segs,
                    isDense: true,
                    items: [for (final s in _segments) DropdownMenuItem(value: s, child: Text('$s'))],
                    onChanged: (v) => segs = v ?? segs,
                  ),
                ),
              ],
              const Spacer(),
              PBtn('Cancel', onTap: busy ? null : () => Navigator.pop(context)),
              const SizedBox(width: 10),
              if (!yt) ...[
                PBtn('Download Later', onTap: busy ? null : () => _submit(false)),
                const SizedBox(width: 10),
              ],
              PBtn('Download', primary: true, onTap: busy ? null : () => _submit(true)),
            ]),
          ),
        ]),
      ),
    );
  }
}
