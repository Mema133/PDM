import 'dart:io';

import 'package:flutter/material.dart';

import 'state.dart';
import 'ui.dart';

final _absPath = RegExp(r'^([A-Za-z]:\\|\\\\)');

Widget _title(String t, [Widget? trailing]) => Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(children: [Text(t, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)), const Spacer(), if (trailing != null) trailing]),
    );

Widget _label(BuildContext c, String t) => Padding(padding: const EdgeInsets.only(top: 14, bottom: 8), child: Text(t, style: TextStyle(color: dimOf(c), fontSize: 11.5, fontWeight: FontWeight.w800, letterSpacing: 1)));

// ---- Queues ---------------------------------------------------------------------------------
class QueuesPage extends StatelessWidget {
  const QueuesPage({super.key});

  Future<void> _newQueue(BuildContext context) async {
    final c = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('New queue'),
        content: TextField(controller: c, autofocus: true, decoration: const InputDecoration(hintText: 'Name'), onSubmitted: (v) => Navigator.pop(ctx, v)),
        actions: [PBtn('Cancel', onTap: () => Navigator.pop(ctx)), PBtn('Create', primary: true, onTap: () => Navigator.pop(ctx, c.text))],
      ),
    );
    if (name == null || name.trim().isEmpty) return;
    final e = await app.act('queues.set', {'name': name.trim(), 'max_active': 2});
    if (e != null && context.mounted) toast(context, e);
  }

  @override
  Widget build(BuildContext context) => SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(26, 22, 26, 22),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _title('Queues and scheduler', PBtn('New queue', icon: Icons.add_rounded, primary: true, onTap: () => _newQueue(context))),
          if (app.queues.isEmpty) Text('Waiting for the engine…', style: TextStyle(color: dimOf(context))),
          for (final q in app.queues) Padding(padding: const EdgeInsets.only(bottom: 12), child: _QueueCard(q)),
        ]),
      );
}

class _QueueCard extends StatelessWidget {
  final Map<String, dynamic> q;
  const _QueueCard(this.q);

  String get name => q['name'] as String;
  Future<void> _set(BuildContext c, Map<String, dynamic> p) async {
    final e = await app.act('queues.set', {'name': name, ...p});
    if (e != null && c.mounted) toast(c, e);
  }

  String _fmt(int? s) {
    if (s == null) return 'Not set';
    final d = DateTime.fromMillisecondsSinceEpoch(s * 1000);
    String t(int n) => n.toString().padLeft(2, '0');
    return '${d.year}-${t(d.month)}-${t(d.day)} ${t(d.hour)}:${t(d.minute)}';
  }

  Future<void> _pick(BuildContext c, String key) async {
    final now = DateTime.now();
    final d = await showDatePicker(context: c, firstDate: now, lastDate: now.add(const Duration(days: 365)), initialDate: now);
    if (d == null || !c.mounted) return;
    final t = await showTimePicker(context: c, initialTime: TimeOfDay.fromDateTime(now.add(const Duration(minutes: 5))));
    if (t == null || !c.mounted) return;
    final at = DateTime(d.year, d.month, d.day, t.hour, t.minute);
    if (!at.isAfter(now)) return toast(c, 'Pick a time in the future.');
    await _set(c, {key: at.millisecondsSinceEpoch ~/ 1000});
  }

  @override
  Widget build(BuildContext context) {
    final running = q['running'] == true;
    final isDefault = name == 'default';
    final maxA = (q['max_active'] ?? 2) as int;
    final n = app.downloads.where((d) => d.queue == name).length;
    Widget sched(String label, String key) => Row(children: [
          SizedBox(width: 90, child: Text(label, style: TextStyle(color: dimOf(context)))),
          Text(_fmt(q[key] as int?)),
          const Spacer(),
          PBtn('Set', onTap: () => _pick(context, key)),
          if (q[key] != null) IBtn(Icons.close_rounded, 'Clear', () => _set(context, {key: null})),
        ]);
    return Panel(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Text(name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(width: 10),
          Chip2(running ? 'Running' : 'Stopped', running ? const Color(0xFF22C55E) : const Color(0xFFF59E0B)),
          const SizedBox(width: 8),
          Text('$n item${n == 1 ? '' : 's'}', style: TextStyle(color: dimOf(context))),
          const Spacer(),
          running
              ? PBtn('Stop', icon: Icons.stop_rounded, onTap: () => app.act('queues.stop', {'name': name}))
              : PBtn('Start', icon: Icons.play_arrow_rounded, primary: true, onTap: () => app.act('queues.start', {'name': name})),
        ]),
        const SizedBox(height: 12),
        Row(children: [
          SizedBox(width: 90, child: Text('Parallel', style: TextStyle(color: dimOf(context)))),
          IBtn(Icons.remove_rounded, 'Fewer', maxA > 1 ? () => _set(context, {'max_active': maxA - 1}) : null),
          Text('$maxA', style: const TextStyle(fontWeight: FontWeight.w700)),
          IBtn(Icons.add_rounded, 'More', maxA < 16 ? () => _set(context, {'max_active': maxA + 1}) : null),
          const SizedBox(width: 24),
          Text('Speed limit', style: TextStyle(color: dimOf(context))),
          const SizedBox(width: 10),
          SizedBox(width: 110, child: TextFormField(key: ValueKey('lim$name${q['speed_limit']}'), initialValue: '${((q['speed_limit'] ?? 0) as int) ~/ 1024}', keyboardType: TextInputType.number, decoration: const InputDecoration(isDense: true, suffixText: 'KB/s', hintText: '0'), onFieldSubmitted: (v) => _set(context, {'speed_limit': (int.tryParse(v) ?? 0) * 1024}))),
          const SizedBox(width: 6),
          Text('0 = unlimited', style: TextStyle(color: dimOf(context), fontSize: 12)),
        ]),
        const SizedBox(height: 8),
        sched('Start at', 'start_at'),
        sched('Stop at', 'stop_at'),
        if (!isDefault)
          Row(children: [
            SizedBox(width: 90, child: Text('When done', style: TextStyle(color: dimOf(context)))),
            DropdownButton<String>(
              value: (q['post_action'] ?? 'none') as String,
              underline: const SizedBox(),
              items: const [DropdownMenuItem(value: 'none', child: Text('Do nothing')), DropdownMenuItem(value: 'exit', child: Text('Stop the engine')), DropdownMenuItem(value: 'shutdown', child: Text('Shut down the computer'))],
              onChanged: (v) => _set(context, {'post_action': v}),
            ),
          ]),
      ]),
    );
  }
}

// ---- Settings -------------------------------------------------------------------------------
class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsState();
}

class _SettingsState extends State<SettingsPage> {
  final speed = TextEditingController(), conns = TextEditingController(), total = TextEditingController();
  final dir = TextEditingController(text: app.downloadDir);
  final phost = TextEditingController(), pport = TextEditingController(), puser = TextEditingController(), ppass = TextEditingController();
  String pmode = 'system', pkind = 'http';
  bool hasPass = false, filled = false;
  Widget _field(String label, TextEditingController c, String suffix) => SizedBox(width: 200, child: TextField(controller: c, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: label, suffixText: suffix)));

  Future<void> _apply() async {
    final e = await app.act('settings.set', {
      'global_speed_limit': (int.tryParse(speed.text) ?? 0) * 1024,
      'max_conns': (int.tryParse(conns.text) ?? 4).clamp(1, 32),
      'max_total_active': (int.tryParse(total.text) ?? 4).clamp(1, 32),
    });
    if (mounted) toast(context, e ?? 'Saved');
  }

  Future<void> _applyProxy() async {
    final manual = pmode == 'manual';
    final e = await app.act('settings.set', {
      'proxy': {
        'mode': pmode,
        if (manual) ...{
          'kind': pkind,
          'host': phost.text.trim(),
          'port': int.tryParse(pport.text.trim()) ?? 0,
          'username': puser.text.trim(),
          if (ppass.text.isNotEmpty) 'password': ppass.text, // blank = keep the stored one
        },
      },
    });
    if (e == null) ppass.clear();
    if (mounted) toast(context, e ?? 'Proxy saved. It applies to downloads started or resumed from now on.');
  }

  Future<void> _installHost() async {
    final exe = '${File(Platform.resolvedExecutable).parent.path}\\pdm-host.exe';
    try {
      final r = await Process.run(exe, ['--install']);
      if (mounted) toast(context, r.exitCode == 0 ? 'Browser integration installed for Chrome, Edge and Brave.' : 'Install failed: ${r.stderr}');
    } on ProcessException {
      if (mounted) toast(context, 'pdm-host.exe not found next to pdm.exe.');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!filled && app.settings.isNotEmpty) {
      filled = true;
      speed.text = '${((app.settings['global_speed_limit'] ?? 0) as int) ~/ 1024}';
      conns.text = '${app.settings['max_conns'] ?? 4}';
      total.text = '${app.settings['max_total_active'] ?? 4}';
      final px = (app.settings['proxy'] ?? const {}) as Map;
      pmode = (px['mode'] ?? 'system') as String;
      pkind = (px['kind'] ?? 'http') as String;
      phost.text = (px['host'] ?? '') as String;
      final pp = (px['port'] ?? 0) as int;
      pport.text = pp == 0 ? '' : '$pp';
      puser.text = (px['username'] ?? '') as String;
      hasPass = px['has_password'] == true;
    }
    final a = accentOf(context);
    final extDir = '${File(Platform.resolvedExecutable).parent.path}\\extension';
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(26, 22, 26, 22),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _title('Settings'),
        Panel(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Appearance', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
            _label(context, 'THEME'),
            Wrap(spacing: 12, runSpacing: 12, children: [for (final t in themes) _ThemeTile(t)]),
            _label(context, 'ACCENT'),
            Wrap(spacing: 10, crossAxisAlignment: WrapCrossAlignment.center, children: [
              for (final c in accentPresets)
                Hover(
                  onTap: () { app.accent = c; app.savePrefs(); },
                  builder: (h) => AnimatedContainer(duration: const Duration(milliseconds: 150), width: h ? 34 : 30, height: h ? 34 : 30, decoration: BoxDecoration(color: c, shape: BoxShape.circle, border: Border.all(color: app.accent == c ? Colors.white : Colors.transparent, width: 3))),
                ),
              PBtn('Use theme accent', onTap: () { app.accent = null; app.savePrefs(); }),
            ]),
            SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Compact density'), subtitle: const Text('Tighter rows, more downloads on screen'), value: app.compact, onChanged: (v) { app.compact = v; app.savePrefs(); }),
          ]),
        ),
        const SizedBox(height: 14),
        Panel(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Connections', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
            const SizedBox(height: 14),
            Wrap(spacing: 12, runSpacing: 12, crossAxisAlignment: WrapCrossAlignment.center, children: [
              _field('Global speed limit', speed, 'KB/s'),
              _field('Connections per file', conns, ''),
              _field('Simultaneous downloads', total, ''),
              PBtn('Apply', primary: true, onTap: _apply),
            ]),
            const SizedBox(height: 6),
            Text('Speed limit 0 = unlimited. Shutdown after downloads is set per queue.', style: TextStyle(color: dimOf(context), fontSize: 12)),
          ]),
        ),
        const SizedBox(height: 14),
        Panel(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Proxy', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            Wrap(spacing: 8, runSpacing: 8, children: [
              Pill('No proxy', pmode == 'none', () => setState(() => pmode = 'none')),
              Pill('Use system proxy', pmode == 'system', () => setState(() => pmode = 'system')),
              Pill('Manual', pmode == 'manual', () => setState(() => pmode = 'manual')),
            ]),
            AnimatedSize(
              duration: const Duration(milliseconds: 220),
              curve: Curves.easeOutCubic,
              alignment: Alignment.topCenter,
              child: pmode != 'manual'
                  ? const SizedBox(width: double.infinity)
                  : Padding(
                      padding: const EdgeInsets.only(top: 14),
                      child: Wrap(spacing: 12, runSpacing: 12, crossAxisAlignment: WrapCrossAlignment.center, children: [
                        Pill('HTTP', pkind == 'http', () => setState(() => pkind = 'http')),
                        Pill('SOCKS5', pkind == 'socks5', () => setState(() => pkind = 'socks5')),
                        SizedBox(width: 240, child: TextField(controller: phost, decoration: const InputDecoration(labelText: 'Address', hintText: '127.0.0.1'))),
                        SizedBox(width: 110, child: TextField(controller: pport, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Port', hintText: '1080'))),
                        SizedBox(width: 170, child: TextField(controller: puser, decoration: const InputDecoration(labelText: 'User name (optional)'))),
                        SizedBox(width: 170, child: TextField(controller: ppass, obscureText: true, decoration: InputDecoration(labelText: 'Password (optional)', hintText: hasPass ? 'unchanged' : null))),
                      ]),
                    ),
            ),
            const SizedBox(height: 12),
            PBtn('Save proxy', primary: true, onTap: _applyProxy),
            const SizedBox(height: 8),
            Text('System proxy follows the Windows proxy settings. SOCKS5 lets the proxy resolve host names. Changes apply to downloads started or resumed afterwards. The password is stored unencrypted in PDM\'s data folder.', style: TextStyle(color: dimOf(context), fontSize: 12)),
          ]),
        ),
        const SizedBox(height: 14),
        Panel(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Browser and folders', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
            const SizedBox(height: 14),
            SizedBox(width: 460, child: TextField(controller: dir, decoration: const InputDecoration(labelText: 'Default save folder'), onSubmitted: (v) { if (_absPath.hasMatch(v.trim())) { app.downloadDir = v.trim(); app.savePrefs(); } })),
            const SizedBox(height: 12),
            const SizedBox(height: 14),
            Wrap(spacing: 10, children: [
              PBtn('Install browser integration', icon: Icons.extension_rounded, onTap: _installHost),
              PBtn('Open extension folder', icon: Icons.folder_open_rounded, onTap: () => openPath(extDir)),
            ]),
            const SizedBox(height: 8),
            SelectableText('Then open chrome://extensions, turn on Developer mode, choose “Load unpacked” and select the extension folder.', style: TextStyle(color: a.withAlpha(220), fontSize: 12)),
          ]),
        ),
      ]),
    );
  }
}

class _ThemeTile extends StatelessWidget {
  final ThemeDef t;
  const _ThemeTile(this.t);
  @override
  Widget build(BuildContext context) {
    final on = app.themeName == t.name;
    return Hover(
      onTap: () { app.themeName = t.name; app.savePrefs(); },
      builder: (h) => AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        width: 150,
        height: 92,
        padding: const EdgeInsets.all(10),
        transform: Matrix4.identity()..scale(h ? 1.04 : 1.0),
        transformAlignment: Alignment.center,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: t.gradient == null ? t.bg : null,
          gradient: t.gradient == null ? null : LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: t.gradient!),
          border: Border.all(color: on ? t.accent : t.border, width: on ? 2.5 : 1),
          boxShadow: on ? [BoxShadow(color: t.accent.withAlpha(90), blurRadius: 16)] : const [],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Container(width: 14, height: 14, decoration: BoxDecoration(color: t.accent, shape: BoxShape.circle)), const SizedBox(width: 6), Container(width: 40, height: 6, decoration: BoxDecoration(color: t.surface2, borderRadius: BorderRadius.circular(3)))]),
          const SizedBox(height: 8),
          Expanded(child: Container(decoration: BoxDecoration(color: t.surface, borderRadius: BorderRadius.circular(8)))),
          const SizedBox(height: 6),
          Text(t.name, style: TextStyle(color: t.text, fontSize: 12, fontWeight: FontWeight.w700)),
        ]),
      ),
    );
  }
}
