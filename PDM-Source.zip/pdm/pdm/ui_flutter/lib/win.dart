// Single-instance guard and "bring PDM to the front" (kernel32/user32 via FFI, Windows only).
import 'dart:ffi';

import 'package:ffi/ffi.dart';

const _title = 'Pervert Download Manager'; // set in windows/runner/main.cpp by scripts/build.ps1

/// True for the first PDM. The browser host starts pdm.exe for every download; a later copy raises the
/// running window and gets false, so the caller should exit.
bool claimSingleInstance() {
  final k32 = DynamicLibrary.open('kernel32.dll');
  final open = k32.lookupFunction<IntPtr Function(Uint32, Int32, Pointer<Utf16>), int Function(int, int, Pointer<Utf16>)>('OpenMutexW');
  final create = k32.lookupFunction<IntPtr Function(Pointer<Void>, Int32, Pointer<Utf16>), int Function(Pointer<Void>, int, Pointer<Utf16>)>('CreateMutexW');
  final name = r'Local\PDM-single-instance'.toNativeUtf16();
  try {
    if (open(0x00100000, 0, name) != 0) { // SYNCHRONIZE: the mutex already exists
      _raise();
      return false;
    }
    create(nullptr, 0, name); // the handle stays open until the process exits
    return true;
  } finally {
    calloc.free(name);
  }
}

void _raise() {
  final u32 = DynamicLibrary.open('user32.dll');
  final find = u32.lookupFunction<IntPtr Function(Pointer<Utf16>, Pointer<Utf16>), int Function(Pointer<Utf16>, Pointer<Utf16>)>('FindWindowW');
  final iconic = u32.lookupFunction<Int32 Function(IntPtr), int Function(int)>('IsIconic');
  final show = u32.lookupFunction<Int32 Function(IntPtr, Int32), int Function(int, int)>('ShowWindow');
  final pos = u32.lookupFunction<Int32 Function(IntPtr, IntPtr, Int32, Int32, Int32, Int32, Uint32), int Function(int, int, int, int, int, int, int)>('SetWindowPos');
  final front = u32.lookupFunction<Int32 Function(IntPtr), int Function(int)>('SetForegroundWindow');
  final t = _title.toNativeUtf16();
  final h = find(nullptr, t);
  calloc.free(t);
  if (h == 0) return;
  if (iconic(h) != 0) show(h, 9); // SW_RESTORE, only when minimized (it would un-maximize otherwise)
  pos(h, -1, 0, 0, 0, 0, 3); // HWND_TOPMOST + NOMOVE|NOSIZE: surfaces the window even where Windows refuses to give it focus
  pos(h, -2, 0, 0, 0, 0, 3); // back to HWND_NOTOPMOST
  front(h);
}
