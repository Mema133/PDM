// YouTube (and other page-URL videos) through yt-dlp + ffmpeg + deno.
// Their streams are signed and chunked, so no plain HTTP downloader can save them. The tools are NOT part of the build:
// PDM downloads them into %APPDATA%\PDM\tools only when the user asks (the "Download tools" button), like QDM does.
import 'dart:convert';
import 'dart:io';

final _ytHost = RegExp(r'^(www\.|m\.|music\.)?youtube\.com$');

bool isYoutube(String url) {
  final u = Uri.tryParse(url.trim());
  return u != null && (u.scheme == 'http' || u.scheme == 'https') && (_ytHost.hasMatch(u.host) || u.host == 'youtu.be');
}

/// Bytes per second from the engine's global speed limit (0 = unlimited); applied when a download starts.
int ytRateLimit = 0;

String get _exeDir => File(Platform.resolvedExecutable).parent.path;
String get toolsDir => '${Platform.environment['APPDATA'] ?? _exeDir}\\PDM\\tools';
String get ytdlpExe => File('$toolsDir\\yt-dlp.exe').existsSync() ? '$toolsDir\\yt-dlp.exe' : '$_exeDir\\yt-dlp.exe'; // a copy next to pdm.exe also works
bool get ytdlpFound => File(ytdlpExe).existsSync();

/// yt-dlp looks for ffmpeg and the deno JS runtime (YouTube needs one) next to itself or on PATH.
Map<String, String> get _env => {'PATH': '$toolsDir;$_exeDir;${Platform.environment['PATH'] ?? ''}'};

String _mb(int b) => '${(b / 1048576).toStringAsFixed(1)} MB';

Future<void> _download(String url, File dest, String label, void Function(String) status) async {
  final c = HttpClient()..userAgent = 'PDM';
  try {
    final rs = await (await c.getUrl(Uri.parse(url))).close(); // follows redirects
    if (rs.statusCode != 200) throw 'HTTP ${rs.statusCode} from ${Uri.parse(url).host}';
    final part = File('${dest.path}.part');
    final sink = part.openWrite();
    var got = 0;
    final clock = Stopwatch()..start();
    await for (final chunk in rs) {
      sink.add(chunk);
      got += chunk.length;
      if (clock.elapsedMilliseconds > 250) {
        clock.reset();
        status('$label ${_mb(got)}${rs.contentLength > 0 ? ' / ${_mb(rs.contentLength)}' : ''}');
      }
    }
    await sink.close();
    if (dest.existsSync()) dest.deleteSync();
    part.renameSync(dest.path);
  } finally {
    c.close();
  }
}

Future<void> _unzip(File zip, Directory to) async {
  final r = await Process.run('powershell', ['-NoProfile', '-Command', 'Expand-Archive -LiteralPath "${zip.path}" -DestinationPath "${to.path}" -Force']);
  if (r.exitCode != 0) throw 'unzip failed: ${r.stderr}'.trim();
}

/// Downloads whatever of yt-dlp, ffmpeg and deno is missing into [toolsDir]; started by the user's click.
/// Returns an error message, or null when everything is in place.
Future<String?> installVideoTools(void Function(String) status) async {
  final dir = Directory(toolsDir)..createSync(recursive: true);
  final tmp = Directory('${Directory.systemTemp.path}\\pdm-tools')..createSync(recursive: true);
  try {
    if (!File('${dir.path}\\yt-dlp.exe').existsSync()) {
      await _download('https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe', File('${dir.path}\\yt-dlp.exe'), 'Downloading yt-dlp', status);
    }
    if (!File('${dir.path}\\deno.exe').existsSync()) {
      final z = File('${tmp.path}\\deno.zip');
      await _download('https://github.com/denoland/deno/releases/latest/download/deno-x86_64-pc-windows-msvc.zip', z, 'Downloading deno', status);
      status('Unpacking deno…');
      await _unzip(z, dir);
    }
    if (!File('${dir.path}\\ffmpeg.exe').existsSync()) {
      final z = File('${tmp.path}\\ffmpeg.zip');
      await _download('https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip', z, 'Downloading ffmpeg', status);
      status('Unpacking ffmpeg…');
      final out = Directory('${tmp.path}\\ffmpeg')..createSync(recursive: true);
      await _unzip(z, out);
      for (final f in out.listSync(recursive: true).whereType<File>()) {
        final n = f.uri.pathSegments.last.toLowerCase();
        if (n == 'ffmpeg.exe' || n == 'ffprobe.exe') f.copySync('${dir.path}\\$n');
      }
      if (!File('${dir.path}\\ffmpeg.exe').existsSync()) throw 'ffmpeg.exe was not in the downloaded archive';
    }
    return null;
  } catch (e) {
    return 'Could not download the video tools: $e';
  } finally {
    try {
      tmp.deleteSync(recursive: true);
    } catch (_) {}
  }
}

/// Quality choices of the dialog -> yt-dlp format selector. null = audio only.
const ytQualities = <(String, String)>[
  ('Best', 'bv*+ba/b'),
  ('1080p', 'bv*[height<=1080]+ba/b[height<=1080]'),
  ('720p', 'bv*[height<=720]+ba/b[height<=720]'),
  ('480p', 'bv*[height<=480]+ba/b[height<=480]'),
  ('360p', 'bv*[height<=360]+ba/b[height<=360]'),
  ('Audio only', 'ba/b'),
];

/// yt-dlp reads cookies from a file (the browser session the extension sent); deleted when the download ends.
String? writeCookies(String text) {
  if (text.isEmpty) return null;
  try {
    final f = File('${Directory.systemTemp.path}\\pdm-cookies-${DateTime.now().microsecondsSinceEpoch}.txt');
    f.writeAsStringSync(text);
    return f.path;
  } catch (_) {
    return null;
  }
}

void deleteQuietly(String? path) {
  if (path == null) return;
  try {
    File(path).deleteSync();
  } catch (_) {}
}

/// Video title for the dialog; null when yt-dlp is missing or fails.
Future<String?> ytTitle(String url, {String? cookies}) async {
  if (!ytdlpFound) return null;
  try {
    final r = await Process.run(ytdlpExe, [if (cookies != null) ...['--cookies', cookies], '--no-playlist', '--no-warnings', '--skip-download', '--print', 'title', url], environment: _env, stdoutEncoding: utf8).timeout(const Duration(seconds: 40));
    final t = (r.stdout as String).trim();
    return r.exitCode == 0 && t.isNotEmpty ? t.split('\n').first.trim() : null;
  } catch (_) {
    return null;
  }
}

/// Keeps yt-dlp current in the background: YouTube changes break old versions every few weeks.
void ytdlpSelfUpdate() {
  if (ytdlpFound) Process.run(ytdlpExe, ['-U'], environment: _env).catchError((_) => ProcessResult(0, 1, '', ''));
}

class YtJob {
  final int id; // negative: never collides with engine ids
  final String url, dir, name, format;
  final bool audioOnly;
  final int addedAt;
  String status = 'queued'; // queued, running, paused, completed, failed, cancelled
  int downloaded = 0, total = 0;
  double speed = 0;
  String? finalPath, error;
  int? finishedAt;
  String? cookies; // path of a cookies.txt for this download (not persisted: it is a credential)
  Process? _proc;
  bool _stopping = false;
  final void Function() onChange;

  YtJob(this.id, this.url, this.dir, this.name, this.format, this.audioOnly, this.onChange, {int? added}) : addedAt = added ?? DateTime.now().millisecondsSinceEpoch ~/ 1000;

  factory YtJob.fromJson(Map<String, dynamic> j, void Function() onChange) => YtJob(j['id'] as int, j['url'] as String, j['dir'] as String, j['name'] as String, j['format'] as String, (j['audio'] ?? false) as bool, onChange, added: (j['added'] ?? 0) as int)
    ..status = j['status'] as String
    ..total = (j['total'] ?? 0) as int
    ..downloaded = (j['total'] ?? 0) as int
    ..finalPath = j['path'] as String?
    ..error = j['error'] as String?
    ..finishedAt = j['finished'] as int?;

  Map<String, dynamic> toJson() => {'id': id, 'url': url, 'dir': dir, 'name': name, 'format': format, 'audio': audioOnly, 'added': addedAt, 'status': status, 'total': total, 'path': finalPath, 'error': error, 'finished': finishedAt};

  /// The shape Dl() reads, so these rows sit in the same list as engine downloads.
  Map<String, dynamic> asEngineJson() => {
        'id': id,
        'url': url,
        'status': status,
        'queue': 'yt-dlp',
        'dest_dir': dir,
        'filename': finalPath == null ? '$name.$_ext' : null,
        'final_path': finalPath,
        'error': error,
        'downloaded': downloaded,
        'total': total,
        'added_at': addedAt,
        'finished_at': finishedAt,
      };

  bool get running => status == 'running';
  String get _ext => audioOnly ? 'm4a' : 'mp4';

  Future<void> start() async {
    if (running) return;
    if (!ytdlpFound) return _fail('yt-dlp is not installed. Open New download and press Download tools.');
    status = 'running';
    error = null;
    _stopping = false;
    onChange();
    final safe = name.replaceAll(RegExp(r'[<>:"/\\|?*]'), '_');
    final args = [
      if (ytRateLimit > 0) ...['--limit-rate', '$ytRateLimit'],
      if (cookies != null) ...['--cookies', cookies!],
      '-f', format, '--no-playlist', '--no-warnings', '--newline', '--progress', '-c',
      if (audioOnly) ...['-x', '--audio-format', 'm4a'] else ...['--merge-output-format', 'mp4'],
      '-P', dir,
      '-o', '$safe.%(ext)s',
      '--progress-template', 'download:PDM|%(progress.downloaded_bytes)s|%(progress.total_bytes)s|%(progress.total_bytes_estimate)s|%(progress.speed)s',
      '--print', 'after_move:PDMFILE|%(filepath)s',
      url,
    ];
    try {
      final p = _proc = await Process.start(ytdlpExe, args, environment: _env);
      final err = <String>[];
      // Wait for both streams to drain before reading them: exitCode can complete first and the error text would be lost.
      final drained = Future.wait([
        p.stderr.transform(utf8.decoder).transform(const LineSplitter()).forEach(err.add),
        p.stdout.transform(utf8.decoder).transform(const LineSplitter()).forEach((l) {
          if (!l.startsWith('PDM')) err.add(l); // keep yt-dlp's own messages too
          _line(l);
        }),
      ]);
      final code = await p.exitCode;
      await drained;
      _proc = null;
      if (_stopping) return; // pause / cancel / remove already set the status
      if (code == 0) {
        status = 'completed';
        downloaded = total > 0 ? total : downloaded;
        finishedAt = DateTime.now().millisecondsSinceEpoch ~/ 1000;
        dropCookies();
      } else {
        final lines = err.where((l) => l.trim().isNotEmpty).toList();
        final errs = lines.where((l) => l.contains('ERROR')).toList();
        var msg = (errs.isNotEmpty ? errs.last : lines.isNotEmpty ? lines.last : 'no message from yt-dlp').replaceFirst(RegExp(r'^.*?ERROR:\s*'), '');
        if (msg.contains('Sign in to confirm') && cookies == null) msg += ' (start the download from the browser extension so PDM gets your cookies)';
        _fail('$msg [yt-dlp exit code $code]');
        return;
      }
    } catch (e) {
      return _fail('Cannot start yt-dlp: $e');
    }
    onChange();
  }

  void _line(String l) {
    if (l.startsWith('PDMFILE|')) {
      finalPath = l.substring(8).trim();
    } else if (l.startsWith('PDM|')) {
      final f = l.split('|');
      int n(int i) => i < f.length ? (double.tryParse(f[i])?.round() ?? 0) : 0;
      downloaded = n(1);
      total = n(2) > 0 ? n(2) : n(3);
      speed = f.length > 4 ? (double.tryParse(f[4]) ?? 0) : 0;
      onChange();
    }
  }

  void dropCookies() {
    deleteQuietly(cookies);
    cookies = null;
  }

  void _fail(String m) {
    dropCookies();
    status = 'failed';
    error = m;
    speed = 0;
    finishedAt = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    onChange();
  }

  /// Stops the process; yt-dlp resumes from its .part file on the next start().
  void stop(String as) {
    _stopping = true;
    _proc?.kill();
    status = as;
    speed = 0;
    if (as == 'cancelled') {
      finishedAt = DateTime.now().millisecondsSinceEpoch ~/ 1000;
      dropCookies();
    }
    onChange();
  }
}
