// Runs extension/background.js against a stubbed chrome API: media sniffing, HLS expansion, referer pass-through.
const fs = require("fs"), vm = require("vm"), assert = require("assert");
const store = {}, handlers = {}, sent = [];
const ev = (name) => ({ addListener: (f) => { handlers[name] = f; } });
const chrome = {
  runtime: { sendNativeMessage: (h, m, cb) => { sent.push(m); cb({ ok: true, added: m.urls.length }); }, lastError: null, onInstalled: ev("inst"), onMessage: ev("msg") },
  contextMenus: { removeAll: (cb) => cb(), create() {}, onClicked: ev("click") },
  action: { setBadgeText() {}, setBadgeBackgroundColor() {} },
  downloads: { onCreated: ev("dl"), cancel() {}, erase() {} },
  storage: { local: { get: async (d) => d }, session: {
    get: async (k) => ({ [k]: store[k] }), set: async (o) => Object.assign(store, o), remove: async (k) => { delete store[k]; } } },
  webRequest: { onHeadersReceived: ev("wr") },
  tabs: { onRemoved: ev("rm"), onUpdated: ev("upd") },
  scripting: {}, windows: {},
};
const playlists = {
  "https://cdn/master.m3u8": "#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=312000,RESOLUTION=854x480,CODECS=\"a,b\"\nlow.m3u8\n#EXT-X-STREAM-INF:BANDWIDTH=2800000,RESOLUTION=1920x1080\nhigh.m3u8\n",
  "https://cdn/enc.m3u8": "#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI=\"k\"\n#EXTINF:4,\na.ts\n#EXT-X-ENDLIST\n",
  "https://cdn/live.m3u8": "#EXTM3U\n#EXTINF:4,\na.ts\n",
  "https://cdn/one.m3u8": "#EXTM3U\n#EXT-X-MAP:URI=\"i.mp4\"\n#EXTINF:4.5,\na.m4s\n#EXTINF:5.5,\nb.m4s\n#EXT-X-ENDLIST\n",
};
const ctx = { chrome, setTimeout, console, Promise, URL, AbortSignal: { timeout: () => undefined },
  fetch: async (u) => ({ ok: u in playlists, status: u in playlists ? 200 : 404, text: async () => playlists[u] }) };
vm.runInNewContext(fs.readFileSync(__dirname + "/../extension/background.js", "utf8"), ctx);
const hdr = (o) => Object.entries(o).map(([name, value]) => ({ name, value }));
const wait = (ms = 30) => new Promise((r) => setTimeout(r, ms));
const J = (x) => JSON.parse(JSON.stringify(x)); // the script runs in another vm realm
(async () => {
  const wr = handlers.wr;
  const ok = (url, h, extra = {}) => wr({ tabId: 5, statusCode: 200, url, responseHeaders: hdr(h), ...extra });
  ok("https://cdn/v.php?id=1", { "Content-Type": "video/mp4", "Content-Length": "9000000" });            // php endpoint serving video
  ok("https://cdn/v.php?id=1", { "Content-Type": "video/mp4", "Content-Range": "bytes 0-9/12345678" }, { statusCode: 206 });
  ok("https://cdn/ping.mp3", { "Content-Type": "audio/mpeg", "Content-Length": "900" });                  // too small
  ok("https://cdn/song.bin", { "Content-Type": "application/octet-stream" });                             // unknown binary: not media
  ok("https://cdn/clip.mp4", { "Content-Type": "application/octet-stream", "Content-Length": "700000" }); // octet-stream with media extension
  ok("https://cdn/seg1.ts", { "Content-Type": "video/mp2t", "Content-Length": "999999" });                // HLS segment
  ok("https://r1.googlevideo.com/videoplayback?x=1", { "Content-Type": "video/mp4", "Content-Length": "999999" }); // youtube chunk
  ok("https://cdn/manifest.mpd", { "Content-Type": "application/dash+xml" });                             // DASH
  ok("https://cdn/page.html", { "Content-Type": "text/html", "Content-Length": "99999" });
  ok("https://cdn/master.m3u8", { "Content-Type": "application/vnd.apple.mpegurl" });
  ok("https://cdn/enc.m3u8", { "Content-Type": "application/x-mpegURL" });
  ok("https://cdn/live.m3u8", { "Content-Type": "application/octet-stream" });
  wr({ tabId: -1, statusCode: 200, url: "https://cdn/sw.mp4", responseHeaders: hdr({ "Content-Type": "video/mp4", "Content-Length": "999999" }) });
  await wait(80);
  const stored = J(store.media5).map((m) => m.url);
  assert.deepStrictEqual(stored, ["https://cdn/v.php?id=1", "https://cdn/clip.mp4", "https://cdn/master.m3u8", "https://cdn/enc.m3u8", "https://cdn/live.m3u8"]);
  assert.strictEqual(J(store.media5)[0].size, 12345678); // size from Content-Range, mime kept for labelling

  let list;
  handlers.msg({ type: "media-list", dom: ["https://cdn/one.m3u8", "https://cdn/clip.mp4"] }, { tab: { id: 5 } }, (r) => (list = J(r.list)));
  await wait(60);
  const by = (u) => list.find((x) => x.url === u);
  assert.strictEqual(by("https://cdn/v.php?id=1").mime, "video/mp4");
  assert.deepStrictEqual([by("https://cdn/low.m3u8").h, by("https://cdn/low.m3u8").bw], [480, 312000]);
  assert.deepStrictEqual([by("https://cdn/high.m3u8").h, by("https://cdn/high.m3u8").bw], [1080, 2800000]);
  assert.ok(by("https://cdn/enc.m3u8").error.includes("encrypted"));
  assert.ok(by("https://cdn/live.m3u8").error.includes("live"));
  assert.deepStrictEqual([by("https://cdn/one.m3u8").ext, by("https://cdn/one.m3u8").dur], ["mp4", 10]); // from the page's own element
  assert.strictEqual(list.filter((x) => x.url === "https://cdn/clip.mp4").length, 1); // sniffed + DOM merged

  let res;
  handlers.msg({ type: "send", urls: ["https://cdn/v.php?id=1"], referer: "https://site/page" }, {}, (r) => (res = r));
  await wait();
  assert.strictEqual(sent[0].referer, "https://site/page");
  assert.ok(res.ok);
  handlers.upd(5, { status: "loading", url: "https://other" });
  await wait();
  assert.strictEqual(store.media5, undefined);

  // YouTube: chunked range requests of one stream collapse into one whole-stream URL; SABR/POST are skipped.
  const yt = (q, extra = {}) => wr({ tabId: 6, statusCode: 206, method: "GET", url: "https://rr1.googlevideo.com/videoplayback?" + q, responseHeaders: hdr({ "Content-Type": "video/mp4" }), ...extra });
  yt("itag=137&mime=video%2Fmp4&clen=50000000&dur=300&range=0-999999&rn=1&sig=A");
  yt("itag=137&mime=video%2Fmp4&clen=50000000&dur=300&range=1000000-1999999&rn=2&sig=A");
  yt("itag=140&mime=audio%2Fmp4&clen=4000000&dur=300&range=0-99&sig=B");
  yt("itag=137&mime=video%2Fmp4&clen=50000000&sabr=1&sig=C");
  yt("itag=137&mime=video%2Fmp4&clen=50000000&sig=D", { method: "POST" });
  await wait(80);
  const y = J(store.media6);
  assert.deepStrictEqual(y.map((m) => m.url), ["https://rr1.googlevideo.com/videoplayback?itag=137&mime=video%2Fmp4&clen=50000000&dur=300&sig=A", "https://rr1.googlevideo.com/videoplayback?itag=140&mime=audio%2Fmp4&clen=4000000&dur=300&sig=B"]);
  assert.deepStrictEqual([y[0].h, y[0].only, y[0].size, y[1].only], [1080, "video only", 50000000, "audio only"]);
  console.log("extension background: sniffing, HLS expansion, YouTube streams, referer pass-through OK");
})().catch((e) => { console.error(e); process.exit(1); });
