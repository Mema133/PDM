import 'dart:async';
import 'dart:io' show exit;
import 'dart:ui' show AppExitResponse;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'newdl.dart';
import 'pages.dart';
import 'state.dart';
import 'ui.dart';
import 'win.dart';

final navKey = GlobalKey<NavigatorState>();

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  if (!claimSingleInstance()) exit(0); // a copy is already running and was just brought to the front
  // A failing widget shows its error instead of the default grey box, so bug reports carry the cause.
  ErrorWidget.builder = (d) => Padding(padding: const EdgeInsets.all(8), child: Text(d.exceptionAsString(), style: const TextStyle(color: Color(0xFFEF4444), fontSize: 11)));
  // Release builds paint a build error as a big gray box; show the message instead.
  ErrorWidget.builder = (d) => Padding(padding: const EdgeInsets.all(8), child: Text('UI error: ${d.exceptionAsString()}', style: const TextStyle(color: Color(0xFFEF4444), fontSize: 11)));
  app.loadPrefs();
  app.start();
  // Downloads sent by the browser wait for the user's OK: one confirmation window at a time.
  var asking = false;
  Timer.periodic(const Duration(milliseconds: 700), (_) async {
    final ctx = navKey.currentContext;
    if (asking || ctx == null) return;
    final p = app.takePending();
    if (p == null) return;
    asking = true;
    await showNewDownload(ctx, url: p['url'] as String, referer: (p['referer'] ?? '') as String, name: (p['name'] ?? '') as String);
    asking = false;
  });
  // Closing PDM must not leave an invisible engine downloading: ask, then stop it.
  AppLifecycleListener(onExitRequested: () async {
    final active = app.downloads.where((d) => d.status == 'running' || d.status == 'queued').length;
    final ctx = navKey.currentContext;
    if (active > 0 && ctx != null) {
      final r = await showDialog<String>(
        context: ctx,
        builder: (c) => AlertDialog(
          title: Text('$active download${active == 1 ? '' : 's'} in progress'),
          content: const Text('Stop them and quit, or keep downloading in the background? The background engine keeps using your internet until you finish them or reopen PDM and quit.'),
          actions: [
            PBtn('Cancel', onTap: () => Navigator.pop(c, 'cancel')),
            PBtn('Keep downloading', onTap: () => Navigator.pop(c, 'keep')),
            PBtn('Stop and quit', primary: true, onTap: () => Navigator.pop(c, 'quit')),
          ],
        ),
      );
      if (r == null || r == 'cancel') return AppExitResponse.cancel;
      if (r == 'keep') return AppExitResponse.exit;
    }
    try {
      await app.ipc.call('app.shutdown');
    } catch (_) {} // engine already gone
    return AppExitResponse.exit;
  });
  runApp(const PdmApp());
}

class PdmApp extends StatelessWidget {
  const PdmApp({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: app,
        builder: (_, __) {
          final t = app.theme;
          return MaterialApp(
            title: 'PDM',
            navigatorKey: navKey,
            debugShowCheckedModeBanner: false,
            theme: app.themeData,
            // The gradient (Aurora/Ocean) or flat colour sits behind every page.
            builder: (_, child) => AnimatedContainer(
              duration: const Duration(milliseconds: 350),
              decoration: BoxDecoration(
                color: t.gradient == null ? t.bg : null,
                gradient: t.gradient == null ? null : LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: t.gradient!),
              ),
              child: child,
            ),
            home: const Shell(),
          );
        },
      );
}

class Shell extends StatelessWidget {
  const Shell({super.key});

  @override
  Widget build(BuildContext context) {
    // Not const on purpose: a const page would be skipped when AppState notifies.
    return ListenableBuilder(
      listenable: app,
      builder: (_, __) {
        final pages = [DownloadsPage(), QueuesPage(), SettingsPage()];
        return Scaffold(
          body: Row(children: [
            _Sidebar(),
            Expanded(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 260),
                transitionBuilder: (w, a) => FadeTransition(opacity: a, child: SlideTransition(position: Tween(begin: const Offset(0, 0.02), end: Offset.zero).animate(a), child: w)),
                child: KeyedSubtree(key: ValueKey(app.page), child: pages[app.page]),
              ),
            ),
          ]),
        );
      },
    );
  }
}

// ---- Sidebar: Library + File types ------------------------------------------------------------
class _Sidebar extends StatelessWidget {
  static const _library = [
    ('all', 'All Downloads', Icons.arrow_circle_down_rounded),
    ('incomplete', 'Incomplete', Icons.pie_chart_outline_rounded),
    ('completed', 'Completed', Icons.check_circle_outline_rounded),
  ];

  int _libCount(String f) => app.downloads.where((d) => f == 'all' || (f == 'completed') == (d.status == 'completed')).length;
  int _typeCount(String t) => t == 'all' ? app.downloads.length : app.downloads.where((d) => fileType(d.name) == t).length;

  Widget _label(BuildContext c, String t) => Padding(padding: const EdgeInsets.fromLTRB(12, 18, 0, 8), child: Text(t, style: TextStyle(color: dimOf(c), fontSize: 11.5, fontWeight: FontWeight.w700, letterSpacing: 1.2)));

  @override
  Widget build(BuildContext context) {
    final a = accentOf(context);
    return Container(
      width: 240,
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 14),
      decoration: BoxDecoration(color: surfaceOf(context).withAlpha(200), border: Border(right: BorderSide(color: borderOf(context)))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _label(context, 'LIBRARY'),
        for (final l in _library)
          _SideItem(Icon(l.$3, size: 20, color: app.page == 0 && app.filter == l.$1 ? a : dimOf(context)), l.$2, _libCount(l.$1), app.page == 0 && app.filter == l.$1, () {
            app.setFilter(l.$1);
            app.setPage(0);
          }),
        _label(context, 'FILE TYPES'),
        for (final t in fileTypes)
          _SideItem(Container(width: 9, height: 9, decoration: BoxDecoration(shape: BoxShape.circle, color: t.$3)), t.$2, _typeCount(t.$1), app.page == 0 && app.type == t.$1, () {
            app.setType(t.$1);
            app.setPage(0);
          }),
        const Spacer(),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 0, 8, 4),
          child: Row(children: [
            AnimatedContainer(duration: const Duration(milliseconds: 300), width: 9, height: 9, decoration: BoxDecoration(shape: BoxShape.circle, color: app.connected ? const Color(0xFF22C55E) : const Color(0xFFEF4444))),
            const SizedBox(width: 8),
            Expanded(child: Text(app.connected ? 'Engine connected' : 'Engine offline', style: TextStyle(fontSize: 12, color: dimOf(context)))),
            if (app.totalSpeed > 0) Text('${humanSize(app.totalSpeed)}/s', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
          ]),
        ),
      ]),
    );
  }
}

class _SideItem extends StatelessWidget {
  final Widget lead;
  final String label;
  final int count;
  final bool on;
  final VoidCallback onTap;
  const _SideItem(this.lead, this.label, this.count, this.on, this.onTap);
  @override
  Widget build(BuildContext context) => Hover(
        onTap: onTap,
        builder: (h) => AnimatedContainer(
          duration: const Duration(milliseconds: 140),
          margin: const EdgeInsets.only(bottom: 2),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), color: on ? surface2Of(context) : (h ? surface2Of(context).withAlpha(90) : Colors.transparent)),
          child: Row(children: [
            SizedBox(width: 22, child: Center(child: lead)),
            const SizedBox(width: 12),
            Expanded(child: Text(label, style: TextStyle(fontSize: 14.5, fontWeight: on ? FontWeight.w700 : FontWeight.w500))),
            Text('$count', style: TextStyle(fontSize: 13, color: dimOf(context))),
          ]),
        ),
      );
}

// ---- Downloads page ---------------------------------------------------------------------------
class DownloadsPage extends StatelessWidget {
  DownloadsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final rows = app.visible;
    Dl? sel;
    for (final d in app.downloads) {
      if (d.id == app.selected) sel = d;
    }
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 14, 16, 12),
      child: Column(children: [
        const _Toolbar(),
        const SizedBox(height: 10),
        Expanded(
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(child: rows.isEmpty ? _Empty() : ListView.builder(itemCount: rows.length, itemBuilder: (_, i) => _Row(rows[i]))),
            AnimatedSize(
              duration: const Duration(milliseconds: 260),
              curve: Curves.easeOutCubic,
              alignment: Alignment.centerLeft,
              child: sel == null ? const SizedBox(width: 0) : Padding(padding: const EdgeInsets.only(left: 14), child: SizedBox(width: 340, child: _Details(sel))),
            ),
          ]),
        ),
      ]),
    );
  }
}

class _TBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  const _TBtn(this.icon, this.label, this.onTap);
  @override
  Widget build(BuildContext context) => Hover(
        onTap: onTap,
        builder: (h) => Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 20, color: h ? null : dimOf(context)),
            const SizedBox(width: 8),
            Text(label, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500, color: h ? null : Theme.of(context).colorScheme.onSurface.withAlpha(220))),
          ]),
        ),
      );
}

class _Toolbar extends StatelessWidget {
  const _Toolbar();

  static const _sorts = [('date', 'Date'), ('name', 'Name'), ('size', 'Size'), ('status', 'Status')];

  Future<void> _bulk(BuildContext context, String v) async {
    bool done(Dl d) => d.status == 'completed';
    bool bad(Dl d) => d.status == 'failed' || d.status == 'cancelled';
    final e = switch (v) {
      'pause' => await app.bulk('downloads.pause', (d) => d.status == 'running' || d.status == 'queued'),
      'resume' => await app.bulk('downloads.resume', (d) => d.status == 'paused'),
      'bad' => await app.bulk('downloads.remove', bad),
      _ => await app.bulk('downloads.remove', (d) => done(d) || bad(d)), // 'clear': history only, files stay on disk
    };
    if (e != null && context.mounted) toast(context, e);
  }

  @override
  Widget build(BuildContext context) => Row(children: [
        _TBtn(Icons.add_rounded, 'New', () => showNewDownload(context)),
        _TBtn(Icons.delete_outline_rounded, 'Clear', () => _bulk(context, 'clear')),
        PopupMenuButton<String>(
          tooltip: 'Sort',
          onSelected: app.setSort,
          itemBuilder: (_) => [for (final s in _sorts) CheckedPopupMenuItem(value: s.$1, checked: app.sortKey == s.$1, child: Text(s.$2 + (app.sortKey == s.$1 ? (app.sortAsc ? '  ↑' : '  ↓') : '')))],
          child: const _TBtn(Icons.swap_vert_rounded, 'Sort', null),
        ),
        _TBtn(Icons.settings_outlined, 'Settings', () => app.setPage(2)),
        const Spacer(),
        SizedBox(
          width: 230,
          child: TextField(
            onChanged: app.setSearch,
            decoration: InputDecoration(hintText: 'Search', suffixIcon: const Icon(Icons.search_rounded, size: 20), isDense: true, contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: borderOf(context)))),
          ),
        ),
        PopupMenuButton<String>(
          icon: const Icon(Icons.menu_rounded),
          onSelected: (v) {
            if (v == 'queues') {
              app.setPage(1);
            } else if (v == 'advanced') {
              showAddDialog(context);
            } else {
              _bulk(context, v);
            }
          },
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'pause', child: Text('Pause all')),
            PopupMenuItem(value: 'resume', child: Text('Resume all paused')),
            PopupMenuDivider(),
            PopupMenuItem(value: 'bad', child: Text('Clear failed and cancelled')),
            PopupMenuItem(value: 'queues', child: Text('Queues and scheduler')),
            PopupMenuItem(value: 'advanced', child: Text('Add several URLs, checksum, queue…')),
          ],
        ),
      ]);
}

class _Empty extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(app.connected ? Icons.cloud_download_outlined : Icons.power_off_rounded, size: 54, color: dimOf(context)),
          const SizedBox(height: 12),
          Text(app.connected ? 'No downloads here yet' : 'Starting the PDM engine…', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          Text(app.connected ? 'Click “New” or use the browser extension.' : 'If this stays, make sure pdmd.exe is next to pdm.exe.', style: TextStyle(color: dimOf(context))),
        ]),
      );
}

String _short(int secs) {
  if (secs <= 0) return '--';
  const m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  final d = DateTime.fromMillisecondsSinceEpoch(secs * 1000);
  return '${m[d.month - 1]} ${d.day}';
}

class _Row extends StatelessWidget {
  final Dl d;
  const _Row(this.d);

  Future<void> _menu(BuildContext context, Offset p) async {
    final done = d.status == 'completed';
    final overlay = Overlay.of(context).context.findRenderObject()! as RenderBox;
    final v = await showMenu<String>(
      context: context,
      position: RelativeRect.fromRect(Rect.fromPoints(p, p), Offset.zero & overlay.size),
      items: [
        if (done) const PopupMenuItem(value: 'file', child: Text('Open file')),
        if (d.status == 'running' || d.status == 'queued') const PopupMenuItem(value: 'pause', child: Text('Pause')),
        if (d.status == 'paused' || d.status == 'failed' || d.status == 'cancelled') const PopupMenuItem(value: 'resume', child: Text('Resume')),
        const PopupMenuItem(value: 'folder', child: Text('Open folder')),
        const PopupMenuItem(value: 'copy', child: Text('Copy URL')),
        if (d.active) const PopupMenuItem(value: 'cancel', child: Text('Cancel and delete partial data')),
        const PopupMenuItem(value: 'remove', child: Text('Remove from list')),
      ],
    );
    if (v == null) return;
    switch (v) {
      case 'pause' || 'resume' || 'cancel' || 'remove':
        final e = await app.act('downloads.$v', {'id': d.id});
        if (e != null && context.mounted) toast(context, e);
      case 'file':
        openPath(d.finalPath ?? '');
      case 'folder':
        d.finalPath != null ? openPath(d.finalPath!, select: true) : openPath(d.dir);
      case 'copy':
        Clipboard.setData(ClipboardData(text: d.url));
    }
  }

  @override
  Widget build(BuildContext context) {
    final sel = app.selected == d.id;
    final a = accentOf(context);
    final t = fileType(d.name);
    final tc = typeColor(t);
    final run = d.status == 'running';
    final size = d.total > 0 ? '  -  ${humanSize(d.total)}' : '';
    final sub = switch (d.status) {
      'running' => '${(d.progress * 100).round()}%  -  ${humanSize(d.speed)}/s  -  ${humanEta(d.eta)} left$size',
      'failed' => d.error ?? 'Failed',
      _ => '${_short(d.date)}$size',
    };
    final pill = switch (d.status) {
      'paused' => 'Paused',
      'queued' => 'Queued',
      'failed' => 'Failed',
      'cancelled' => 'Cancelled',
      _ => null,
    };
    return Hover(
      onTap: () => app.select(sel ? null : d.id),
      onSecondary: (p) => _menu(context, p),
      builder: (h) => AnimatedContainer(
        duration: const Duration(milliseconds: 140),
        margin: const EdgeInsets.symmetric(vertical: 1),
        padding: const EdgeInsets.fromLTRB(10, 9, 8, 9),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), color: sel ? a.withAlpha(30) : (h ? surface2Of(context).withAlpha(120) : Colors.transparent)),
        child: Row(children: [
          Container(width: 46, height: 46, decoration: BoxDecoration(shape: BoxShape.circle, color: tc.withAlpha(40)), child: Icon(typeIcon(t), size: 21, color: tc)),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
              Text(d.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.w500)),
              const SizedBox(height: 3),
              Text(sub, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12.5, color: d.status == 'failed' ? const Color(0xFFEF4444) : dimOf(context))),
              if (run || (d.active && d.progress > 0)) Padding(padding: const EdgeInsets.only(top: 6), child: Bar(d.total > 0 ? d.progress : null, height: 4, color: statusColor(d.status))),
            ]),
          ),
          if (pill != null) Padding(padding: const EdgeInsets.only(left: 10, right: 6), child: Chip2(pill, statusColor(d.status))),
          if (run || d.status == 'queued') IBtn(Icons.pause_circle_outline_rounded, 'Pause', () => app.act('downloads.pause', {'id': d.id})),
          if (d.status == 'paused' || d.status == 'failed' || d.status == 'cancelled') IBtn(Icons.play_circle_outline_rounded, 'Resume', () => app.act('downloads.resume', {'id': d.id})),
          if (d.status == 'completed') IBtn(Icons.folder_open_rounded, 'Show in folder', () => openPath(d.finalPath ?? d.dir, select: d.finalPath != null)),
          IBtn(Icons.delete_outline_rounded, 'Remove from list (the file stays on disk)', () => app.act('downloads.remove', {'id': d.id})),
          Builder(
            builder: (c) => IBtn(Icons.more_vert_rounded, 'More', () {
              final b = c.findRenderObject()! as RenderBox;
              _menu(context, b.localToGlobal(b.size.center(Offset.zero)));
            }),
          ),
        ]),
      ),
    );
  }
}

class _Details extends StatelessWidget {
  final Dl d;
  const _Details(this.d);
  @override
  Widget build(BuildContext context) {
    final c = statusColor(d.status);
    Widget kv(String k, String v) => Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Row(children: [Expanded(child: Text(k, style: TextStyle(color: dimOf(context)))), Text(v, style: const TextStyle(fontWeight: FontWeight.w600))]));
    Widget head(String t) => Padding(padding: const EdgeInsets.only(top: 14, bottom: 4), child: Text(t, style: TextStyle(color: dimOf(context), fontSize: 11, fontWeight: FontWeight.w700)));
    final done = d.status == 'completed';
    return Panel(
      child: SingleChildScrollView(
        // The desktop scrollbar draws over the content; keep text clear of it.
        child: Padding(
          padding: const EdgeInsets.only(right: 14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Expanded(child: Text(d.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))), IBtn(Icons.close_rounded, 'Close', () => app.select(null))]),
            const SizedBox(height: 8),
            Chip2(d.status.toUpperCase(), c),
            const SizedBox(height: 12),
            Wrap(spacing: 8, runSpacing: 8, children: [
              if (done) PBtn('Run', icon: Icons.play_arrow_rounded, primary: true, onTap: () => openPath(d.finalPath ?? '')),
              if (d.status == 'running' || d.status == 'queued') PBtn('Pause', icon: Icons.pause_rounded, onTap: () => app.act('downloads.pause', {'id': d.id})),
              if (d.status == 'paused' || d.status == 'failed' || d.status == 'cancelled') PBtn('Resume', icon: Icons.play_arrow_rounded, primary: true, onTap: () => app.act('downloads.resume', {'id': d.id})),
              PBtn('Folder', icon: Icons.folder_open_rounded, onTap: () => openPath(d.finalPath ?? d.dir, select: d.finalPath != null)),
            ]),
            const SizedBox(height: 14),
            Bar(d.total > 0 || done ? d.progress : null, height: 12, color: c),
            const SizedBox(height: 14),
            kv('Downloaded', '${humanSize(d.downloaded)} / ${humanSize(d.total)}'),
            kv('Speed', d.status == 'running' ? '${humanSize(d.speed)}/s' : '--'),
            kv('Time left', d.status == 'running' ? humanEta(d.eta) : '--'),
            kv('Connections', '${d.conns}${d.segmented ? '' : ' (single stream)'}'),
            kv('Retries', '${d.retries}'),
            kv('Queue', d.queue),
            kv('Last try', fmtDate(d.date)),
            if (d.error != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(d.error!, style: const TextStyle(color: Color(0xFFEF4444)))),
            head('SPEED'),
            Sparkline(app.histOf(d.id), c, height: 70),
            if (d.segs.isNotEmpty) ...[head('CONNECTIONS'), SegmentBars(d.segs, c)],
            head('URL'),
            SelectableText(d.url, style: const TextStyle(fontSize: 12)),
            head('SAVED TO'),
            SelectableText(d.finalPath ?? d.dir, style: const TextStyle(fontSize: 12)),
          ]),
        ),
      ),
    );
  }
}

// ---- Add download dialog ---------------------------------------------------------------------
Future<void> showAddDialog(BuildContext context) => showDialog<void>(context: context, builder: (_) => const _AddDialog());

class _AddDialog extends StatefulWidget {
  const _AddDialog();
  @override
  State<_AddDialog> createState() => _AddDialogState();
}

class _AddDialogState extends State<_AddDialog> {
  final url = TextEditingController(), dir = TextEditingController(text: app.downloadDir), sha = TextEditingController(), conns = TextEditingController();
  String queue = 'default';
  bool start = true;
  String? error;
  bool busy = false;

  Future<void> submit() async {
    final urls = url.text.split(RegExp(r'\s+')).where((s) => s.isNotEmpty).toList();
    final shaT = sha.text.trim();
    String? err;
    if (urls.isEmpty || urls.any((u) => !RegExp(r'^https?://\S+$', caseSensitive: false).hasMatch(u))) {
      err = 'Enter valid http:// or https:// URLs (one per line).';
    } else if (!RegExp(r'^([A-Za-z]:\\|\\\\)').hasMatch(dir.text.trim())) {
      err = 'Choose an absolute destination folder.';
    } else if (shaT.isNotEmpty && !RegExp(r'^[0-9a-fA-F]{64}$').hasMatch(shaT)) {
      err = 'Checksum must be 64 hexadecimal characters.';
    }
    if (err != null) return setState(() => error = err);
    setState(() => busy = true);
    final n = int.tryParse(conns.text.trim()) ?? 0;
    for (final u in urls) {
      final e = await app.act('downloads.add', {
        'url': u,
        'dest_dir': dir.text.trim(),
        'queue': queue,
        'start': start,
        if (shaT.isNotEmpty && urls.length == 1) 'sha256': shaT,
        if (n > 0) 'max_conns': n,
      });
      if (e != null) {
        if (mounted) setState(() { error = e; busy = false; });
        return;
      }
    }
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final names = app.queues.isEmpty ? ['default'] : [for (final q in app.queues) q['name'] as String];
    return Dialog(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 560),
        child: Padding(
          padding: const EdgeInsets.all(26),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Add download', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 18),
            TextField(controller: url, autofocus: true, minLines: 1, maxLines: 4, decoration: const InputDecoration(labelText: 'URL (one per line)', hintText: 'https://example.com/file.zip')),
            const SizedBox(height: 12),
            TextField(controller: dir, decoration: const InputDecoration(labelText: 'Save to')),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: DropdownButtonFormField<String>(initialValue: names.contains(queue) ? queue : names.first, decoration: const InputDecoration(labelText: 'Queue'), items: [for (final n in names) DropdownMenuItem(value: n, child: Text(n))], onChanged: (v) => queue = v ?? 'default')),
              const SizedBox(width: 12),
              Expanded(child: TextField(controller: conns, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Connections', hintText: 'Default'))),
            ]),
            const SizedBox(height: 12),
            TextField(controller: sha, decoration: const InputDecoration(labelText: 'SHA-256 (optional, single URL only)')),
            const SizedBox(height: 6),
            SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Start immediately'), value: start, onChanged: (v) => setState(() => start = v)),
            if (error != null) Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(error!, style: const TextStyle(color: Color(0xFFEF4444)))),
            Row(mainAxisAlignment: MainAxisAlignment.end, children: [
              PBtn('Cancel', onTap: () => Navigator.pop(context)),
              const SizedBox(width: 10),
              PBtn(busy ? 'Adding…' : 'Add', primary: true, onTap: busy ? null : submit),
            ]),
          ]),
        ),
      ),
    );
  }
}
