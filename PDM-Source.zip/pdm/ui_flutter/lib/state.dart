import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'ipc.dart';
import 'ui.dart' show fileType;
import 'ytdlp.dart';

// ---- themes (same six palettes as the old Qt UI) ---------------------------------------------
class ThemeDef {
  final String name;
  final Color bg, surface, surface2, text, dim, border, accent;
  final List<Color>? gradient;
  const ThemeDef(this.name, this.bg, this.surface, this.surface2, this.text, this.dim, this.border, this.accent, [this.gradient]);
}

const themes = <ThemeDef>[
  ThemeDef('Light', Color(0xFFF3F5F9), Color(0xFFFFFFFF), Color(0xFFEDF0F6), Color(0xFF1B1F2A), Color(0xFF6B7385), Color(0xFFDDE2EC), Color(0xFF3B82F6)),
  ThemeDef('Dark', Color(0xFF14161B), Color(0xFF1C1F26), Color(0xFF252932), Color(0xFFE6E8EE), Color(0xFF8E95A5), Color(0xFF2E333F), Color(0xFF5B9DFF)),
  ThemeDef('Midnight', Color(0xFF0B1020), Color(0xFF121A33), Color(0xFF1A2548), Color(0xFFDCE3FF), Color(0xFF8390BD), Color(0xFF26335E), Color(0xFF7C8CFF)),
  ThemeDef('Graphite', Color(0xFF1E1E20), Color(0xFF2A2A2D), Color(0xFF343438), Color(0xFFE4E4E6), Color(0xFF9A9AA1), Color(0xFF3F3F44), Color(0xFF8AB4F8)),
  ThemeDef('Aurora', Color(0xFF0E1A1C), Color(0xFF142A2C), Color(0xFF1C3A3C), Color(0xFFDFF7EE), Color(0xFF86B5A8), Color(0xFF24484A), Color(0xFF2DD4BF),
      [Color(0xFF0B2B2E), Color(0xFF17304A), Color(0xFF2A1B4D)]),
  ThemeDef('Ocean', Color(0xFF0A1A2A), Color(0xFF0F2A44), Color(0xFF16385A), Color(0xFFD9ECFF), Color(0xFF7FA6C9), Color(0xFF1E4468), Color(0xFF38BDF8),
      [Color(0xFF06304F), Color(0xFF0A1A2A)]),
];

const accentPresets = <Color>[Color(0xFF3B82F6), Color(0xFF7C8CFF), Color(0xFF2DD4BF), Color(0xFF22C55E), Color(0xFFF59E0B), Color(0xFFF43F5E), Color(0xFFEC4899), Color(0xFFA78BFA)];

ThemeData buildTheme(ThemeDef t, Color accent, bool compact) {
  final dark = t.bg.computeLuminance() < 0.4;
  final cs = ColorScheme.fromSeed(seedColor: accent, brightness: dark ? Brightness.dark : Brightness.light).copyWith(
    primary: accent,
    onPrimary: accent.computeLuminance() > 0.5 ? const Color(0xFF101418) : Colors.white,
    surface: t.surface,
    onSurface: t.text,
    onSurfaceVariant: t.dim,
    outline: t.border,
    outlineVariant: t.border,
    surfaceContainerHighest: t.surface2,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: cs,
    fontFamily: 'Segoe UI',
    scaffoldBackgroundColor: Colors.transparent,
    visualDensity: compact ? VisualDensity.compact : VisualDensity.standard,
    dialogTheme: DialogThemeData(backgroundColor: t.surface, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: t.surface2,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: accent, width: 1.4)),
    ),
    popupMenuTheme: PopupMenuThemeData(color: t.surface2, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
  );
}

// ---- formatting ------------------------------------------------------------------------------
String humanSize(num b) {
  if (b <= 0) return '--';
  const u = ['B', 'KB', 'MB', 'GB', 'TB'];
  var i = 0;
  var v = b.toDouble();
  while (v >= 1024 && i < u.length - 1) {
    v /= 1024;
    i++;
  }
  return '${v.toStringAsFixed(i == 0 ? 0 : 1)} ${u[i]}';
}

String fmtDate(int secs) {
  if (secs <= 0) return '--';
  final d = DateTime.fromMillisecondsSinceEpoch(secs * 1000);
  String t(int n) => n.toString().padLeft(2, '0');
  return '${d.year}-${t(d.month)}-${t(d.day)} ${t(d.hour)}:${t(d.minute)}';
}

String humanEta(double secs) {
  if (secs.isNaN || secs.isInfinite || secs <= 0) return '--';
  final s = secs.round();
  if (s >= 3600) return '${s ~/ 3600}h ${(s % 3600) ~/ 60}m';
  if (s >= 60) return '${s ~/ 60}m ${s % 60}s';
  return '${s}s';
}

// ---- model -----------------------------------------------------------------------------------
class Dl {
  final int id, downloaded, total, conns, retries, addedAt;
  final int? finishedAt;
  final String url, status, queue, dir;
  final String? filename, finalPath, error;
  final bool segmented;
  final List<List<int>> segs;
  double speed = 0;

  Dl(Map<String, dynamic> j)
      : id = j['id'] as int,
        url = j['url'] as String,
        status = j['status'] as String,
        queue = (j['queue'] ?? 'default') as String,
        dir = (j['dest_dir'] ?? '') as String,
        filename = j['filename'] as String?,
        finalPath = j['final_path'] as String?,
        error = j['error'] as String?,
        downloaded = (j['downloaded'] ?? 0) as int,
        total = (j['total'] ?? 0) as int,
        conns = (j['conns'] ?? 0) as int,
        retries = (j['retries'] ?? 0) as int,
        addedAt = (j['added_at'] ?? 0) as int,
        finishedAt = j['finished_at'] as int?,
        segmented = (j['segmented'] ?? false) as bool,
        segs = [
          for (final s in (j['segments'] ?? const []) as List) [(s as Map)['start'] as int, s['end'] as int, s['done'] as int]
        ];

  String get name {
    final p = finalPath;
    if (filename != null && filename!.isNotEmpty) return filename!;
    if (p != null && p.isNotEmpty) return p.split(RegExp(r'[\\/]')).last;
    final seg = Uri.tryParse(url)?.pathSegments.where((s) => s.isNotEmpty).toList() ?? [];
    if (seg.isEmpty) return url;
    try {
      return Uri.decodeComponent(seg.last);
    } catch (_) {
      return seg.last; // malformed %-escape: must never break the whole list
    }
  }

  /// "Last try": when it finished or failed, else when it was added.
  int get date => finishedAt ?? addedAt;
  double get progress => status == 'completed' ? 1 : (total > 0 ? (downloaded / total).clamp(0, 1).toDouble() : 0);
  bool get active => status == 'running' || status == 'queued' || status == 'paused';
  double get eta => speed > 1 && total > downloaded ? (total - downloaded) / speed : 0;
}

class _Sample {
  final int bytes;
  final DateTime at;
  final double speed;
  _Sample(this.bytes, this.at, this.speed);
}

// ---- app state -------------------------------------------------------------------------------
class AppState extends ChangeNotifier {
  final ipc = Ipc();
  List<Dl> downloads = [];
  List<Dl> _engineList = [];
  final yt = <YtJob>[]; // yt-dlp downloads (negative ids), shown in the same list
  int _ytNext = -1;
  List<Map<String, dynamic>> queues = [];
  Map<String, dynamic> settings = {};
  final speedHist = List<double>.filled(60, 0, growable: true);
  final _perHist = <int, List<double>>{};
  final _last = <int, _Sample>{};
  double totalSpeed = 0;
  bool connected = false;
  int page = 0;
  int? selected;
  String filter = 'all'; // all, incomplete, completed (also active, queued, failed)
  String type = 'all'; // all, documents, compressed, music, video, programs
  String search = '';
  String sortKey = 'date';
  bool sortAsc = false; // newest first

  String themeName = 'Dark';
  Color? accent;
  bool compact = false;
  String downloadDir = '${Platform.environment['USERPROFILE'] ?? 'C:\\'}\\Downloads';

  Timer? _timer;
  bool _busy = false;
  int _tick = 0;

  ThemeDef get theme => themes.firstWhere((t) => t.name == themeName, orElse: () => themes[1]);
  Color get effectiveAccent => accent ?? theme.accent;
  String? _tdKey;
  ThemeData? _td;
  /// Cached: rebuilding ThemeData on every 700 ms poll would restart theme animations.
  ThemeData get themeData {
    final k = '$themeName/${accent?.toARGB32()}/$compact';
    if (k != _tdKey) {
      _tdKey = k;
      _td = buildTheme(theme, effectiveAccent, compact);
    }
    return _td!;
  }

  void _rebuild() {
    downloads = [..._engineList, for (final j in yt) Dl(j.asEngineJson())..speed = j.running ? j.speed : 0];
    notifyListeners();
  }

  static File get _ytFile => File('${Platform.environment['APPDATA'] ?? '.'}\\PDM\\yt.json');

  void _ytChanged() {
    _rebuild();
    if (yt.any((j) => j.running)) return; // progress ticks are not worth a disk write
    try {
      _ytFile.parent.createSync(recursive: true);
      _ytFile.writeAsStringSync(jsonEncode([for (final j in yt) if (j.status != 'queued') j.toJson()]));
    } catch (_) {}
  }

  /// Starts a yt-dlp download; [format] is a yt-dlp selector from ytQualities.
  void addYoutube(String url, String dir, String name, String format, bool audioOnly) {
    final j = YtJob(_ytNext--, url, dir, name, format, audioOnly, _ytChanged);
    yt.add(j);
    j.start();
  }

  List<double> histOf(int id) => _perHist[id] ?? const [];

  static File get _file => File('${Platform.environment['APPDATA'] ?? '.'}\\PDM\\ui.json');

  void loadPrefs() {
    try {
      final j = jsonDecode(_file.readAsStringSync()) as Map<String, dynamic>;
      themeName = (j['theme'] ?? themeName) as String;
      accent = j['accent'] == null ? null : Color(j['accent'] as int);
      compact = (j['compact'] ?? false) as bool;
      downloadDir = (j['dir'] ?? downloadDir) as String;
    } catch (_) {} // first run or unreadable file: keep defaults
    try {
      for (final j in jsonDecode(_ytFile.readAsStringSync()) as List) {
        final job = YtJob.fromJson((j as Map).cast<String, dynamic>(), _ytChanged);
        yt.add(job);
        if (job.id <= _ytNext) _ytNext = job.id - 1;
      }
    } catch (_) {}
  }

  void savePrefs() {
    try {
      _file.parent.createSync(recursive: true);
      _file.writeAsStringSync(jsonEncode({'theme': themeName, 'accent': accent?.toARGB32(), 'compact': compact, 'dir': downloadDir}));
    } catch (_) {}
    notifyListeners();
  }

  void start() {
    // Idempotent: registers the browser host for the PDM extension (HKCU only).
    Process.run('${File(Platform.resolvedExecutable).parent.path}\\pdm-host.exe', ['--install']).catchError((_) => ProcessResult(0, 1, '', ''));
    ytdlpSelfUpdate();
    _timer = Timer.periodic(const Duration(milliseconds: 700), (_) => _poll());
    _poll();
  }

  Future<void> _poll() async {
    if (_busy) return;
    _busy = true;
    try {
      final r = await ipc.call('downloads.list');
      final now = DateTime.now();
      final list = [for (final e in r['downloads'] as List) Dl((e as Map).cast<String, dynamic>())];
      var total = 0.0;
      for (final d in list) {
        final p = _last[d.id];
        var sp = 0.0;
        if (d.status == 'running' && p != null) {
          final dt = now.difference(p.at).inMilliseconds / 1000.0;
          if (dt > 0) sp = p.speed * 0.6 + math.max(0, d.downloaded - p.bytes) / dt * 0.4;
        }
        d.speed = sp;
        total += sp;
        _last[d.id] = _Sample(d.downloaded, now, sp);
        final h = _perHist.putIfAbsent(d.id, () => []);
        h.add(sp);
        if (h.length > 60) h.removeAt(0);
      }
      _last.removeWhere((k, _) => !list.any((d) => d.id == k));
      _perHist.removeWhere((k, _) => !list.any((d) => d.id == k));
      speedHist
        ..add(total)
        ..removeAt(0);
      totalSpeed = total;
      _engineList = list;
      connected = true;
      if (_tick++ % 5 == 0) {
        queues = [for (final q in (await ipc.call('queues.list'))['queues'] as List) (q as Map).cast<String, dynamic>()];
        settings = await ipc.call('settings.get');
        ytRateLimit = (settings['global_speed_limit'] ?? 0) as int;
      }
    } catch (_) {
      connected = false;
    } finally {
      _busy = false;
      _rebuild();
    }
  }

  /// Engine downloads go to pdmd; yt-dlp downloads (negative ids) are handled here.
  Future<void> _route(String method, Map<String, dynamic> params) async {
    final id = params['id'];
    if (id is! int || id >= 0) {
      await ipc.call(method, params);
      return;
    }
    final j = yt.firstWhere((j) => j.id == id, orElse: () => throw IpcError('no such download'));
    switch (method) {
      case 'downloads.pause':
        j.stop('paused');
      case 'downloads.resume':
        j.start();
      case 'downloads.cancel':
        j.stop('cancelled');
      case 'downloads.remove':
        if (j.running) j.stop('cancelled');
        yt.remove(j);
        _ytChanged();
    }
  }

  /// Runs an engine call and refreshes; returns an error message or null.
  Future<String?> act(String method, [Map<String, dynamic> params = const {}]) async {
    try {
      await _route(method, params);
      _tick = 0;
      await _poll();
      return null;
    } catch (e) {
      return e.toString();
    }
  }

  /// Applies [method] to every matching download, then refreshes once. Returns the first error.
  Future<String?> bulk(String method, bool Function(Dl) pick) async {
    String? err;
    for (final d in List.of(downloads).where(pick)) {
      try {
        await _route(method, {'id': d.id});
      } catch (e) {
        err ??= e.toString();
      }
    }
    _tick = 0;
    await _poll();
    return err;
  }

  static Directory get _pendingDir => Directory('${Platform.environment['APPDATA'] ?? '.'}\\PDM\\pending');

  /// Oldest browser download waiting for the user's confirmation ({url, referer, name}), or null.
  /// pdm-host drops one file per click; requests older than 10 minutes (PDM never started) are discarded.
  Map<String, dynamic>? takePending() {
    try {
      final d = _pendingDir;
      if (!d.existsSync()) return null;
      final files = d.listSync().whereType<File>().where((f) => f.path.endsWith('.json')).toList()..sort((a, b) => a.path.compareTo(b.path));
      for (final f in files) {
        try {
          final fresh = DateTime.now().difference(f.lastModifiedSync()).inMinutes < 10;
          final j = jsonDecode(f.readAsStringSync());
          f.deleteSync();
          if (fresh && j is Map<String, dynamic> && j['url'] is String) return j;
        } catch (_) {
          try {
            f.deleteSync(); // unreadable: drop it so it cannot block the ones behind it
          } catch (_) {}
        }
      }
    } catch (_) {}
    return null;
  }

  void setPage(int p) {
    page = p;
    notifyListeners();
  }

  void select(int? id) {
    selected = id;
    notifyListeners();
  }

  void setFilter(String f) {
    filter = f;
    notifyListeners();
  }

  void setType(String t) {
    type = t;
    notifyListeners();
  }

  void setSort(String key) {
    if (sortKey == key) {
      sortAsc = !sortAsc;
    } else {
      sortKey = key;
      sortAsc = key == 'name' || key == 'queue' || key == 'status'; // text columns A-Z first, numbers largest first
    }
    notifyListeners();
  }

  void setSearch(String s) {
    search = s;
    notifyListeners();
  }

  List<Dl> get visible {
    final q = search.trim().toLowerCase();
    final rows = downloads.where((d) {
      final ok = switch (filter) {
        'active' => d.status == 'running' || d.status == 'paused',
        'queued' => d.status == 'queued',
        'incomplete' => d.status != 'completed',
        'completed' => d.status == 'completed',
        'failed' => d.status == 'failed' || d.status == 'cancelled',
        _ => true,
      };
      return ok && (type == 'all' || fileType(d.name) == type) && (q.isEmpty || d.name.toLowerCase().contains(q) || d.url.toLowerCase().contains(q));
    }).toList();
    int cmp(Dl a, Dl b) => switch (sortKey) {
          'name' => a.name.toLowerCase().compareTo(b.name.toLowerCase()),
          'queue' => a.queue.toLowerCase().compareTo(b.queue.toLowerCase()),
          'size' => a.total.compareTo(b.total),
          'status' => a.status.compareTo(b.status),
          'progress' => a.progress.compareTo(b.progress),
          'speed' => a.speed.compareTo(b.speed),
          'left' => a.eta.compareTo(b.eta),
          _ => a.date.compareTo(b.date),
        };
    rows.sort((a, b) => sortAsc ? cmp(a, b) : cmp(b, a));
    return rows;
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}

final app = AppState();
