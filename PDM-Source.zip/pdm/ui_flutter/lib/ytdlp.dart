// YouTube (and other page-URL videos) through yt-dlp + ffmpeg, which sit next to pdm.exe.
// Their streams are signed and chunked, so no plain HTTP downloader can save them: this is what XDM bundles too.
import 'dart:convert';
import 'dart:io';

final _ytHost = RegExp(r'^(www\.|m\.|music\.)?youtube\.com$');

bool isYoutube(String url) {
  final u = Uri.tryParse(url.trim());
  return u != null && (u.scheme == 'http' || u.scheme == 'https') && (_ytHost.hasMatch(u.host) || u.host == 'youtu.be');
}

/// Bytes per second from the engine's global speed limit (0 = unlimited); applied when a download starts.
int ytRateLimit = 0;

String get _exeDir => File(Platform.resolvedExecutable).parent.path;
String get ytdlpExe => '$_exeDir\\yt-dlp.exe';
bool get ytdlpFound => File(ytdlpExe).existsSync();

/// yt-dlp looks for ffmpeg and the deno JS runtime (YouTube needs one) next to itself or on PATH.
Map<String, String> get _env => {'PATH': '$_exeDir;${Platform.environment['PATH'] ?? ''}'};

/// Quality choices of the dialog -> yt-dlp format selector. null = audio only.
const ytQualities = <(String, String)>[
  ('Best', 'bv*+ba/b'),
  ('1080p', 'bv*[height<=1080]+ba/b[height<=1080]'),
  ('720p', 'bv*[height<=720]+ba/b[height<=720]'),
  ('480p', 'bv*[height<=480]+ba/b[height<=480]'),
  ('360p', 'bv*[height<=360]+ba/b[height<=360]'),
  ('Audio only', 'ba/b'),
];

/// Video title for the dialog; null when yt-dlp is missing or fails.
Future<String?> ytTitle(String url) async {
  if (!ytdlpFound) return null;
  try {
    final r = await Process.run(ytdlpExe, ['--no-playlist', '--no-warnings', '--skip-download', '--print', 'title', url], environment: _env, stdoutEncoding: utf8).timeout(const Duration(seconds: 40));
    final t = (r.stdout as String).trim();
    return r.exitCode == 0 && t.isNotEmpty ? t.split('\n').first.trim() : null;
  } catch (_) {
    return null;
  }
}

/// Keeps yt-dlp current in the background: YouTube changes break old versions every few weeks.
void ytdlpSelfUpdate() {
  if (ytdlpFound) Process.run(ytdlpExe, ['-U'], environment: _env).catchError((_) => ProcessResult(0, 1, '', ''));
}

class YtJob {
  final int id; // negative: never collides with engine ids
  final String url, dir, name, format;
  final bool audioOnly;
  final int addedAt;
  String status = 'queued'; // queued, running, paused, completed, failed, cancelled
  int downloaded = 0, total = 0;
  double speed = 0;
  String? finalPath, error;
  int? finishedAt;
  Process? _proc;
  bool _stopping = false;
  final void Function() onChange;

  YtJob(this.id, this.url, this.dir, this.name, this.format, this.audioOnly, this.onChange, {int? added}) : addedAt = added ?? DateTime.now().millisecondsSinceEpoch ~/ 1000;

  factory YtJob.fromJson(Map<String, dynamic> j, void Function() onChange) => YtJob(j['id'] as int, j['url'] as String, j['dir'] as String, j['name'] as String, j['format'] as String, (j['audio'] ?? false) as bool, onChange, added: (j['added'] ?? 0) as int)
    ..status = j['status'] as String
    ..total = (j['total'] ?? 0) as int
    ..downloaded = (j['total'] ?? 0) as int
    ..finalPath = j['path'] as String?
    ..error = j['error'] as String?
    ..finishedAt = j['finished'] as int?;

  Map<String, dynamic> toJson() => {'id': id, 'url': url, 'dir': dir, 'name': name, 'format': format, 'audio': audioOnly, 'added': addedAt, 'status': status, 'total': total, 'path': finalPath, 'error': error, 'finished': finishedAt};

  /// The shape Dl() reads, so these rows sit in the same list as engine downloads.
  Map<String, dynamic> asEngineJson() => {
        'id': id,
        'url': url,
        'status': status,
        'queue': 'YouTube',
        'dest_dir': dir,
        'filename': finalPath == null ? '$name.$_ext' : null,
        'final_path': finalPath,
        'error': error,
        'downloaded': downloaded,
        'total': total,
        'added_at': addedAt,
        'finished_at': finishedAt,
      };

  bool get running => status == 'running';
  String get _ext => audioOnly ? 'm4a' : 'mp4';

  Future<void> start() async {
    if (running) return;
    if (!ytdlpFound) return _fail('yt-dlp.exe was not found next to pdm.exe.');
    status = 'running';
    error = null;
    _stopping = false;
    onChange();
    final safe = name.replaceAll(RegExp(r'[<>:"/\\|?*]'), '_');
    final args = [
      if (ytRateLimit > 0) ...['--limit-rate', '$ytRateLimit'],
      '-f', format, '--no-playlist', '--no-warnings', '--newline', '--progress', '--no-colors', '-c',
      if (audioOnly) ...['-x', '--audio-format', 'm4a'] else ...['--merge-output-format', 'mp4'],
      '-P', dir,
      '-o', '$safe.%(ext)s',
      '--progress-template', 'download:PDM|%(progress.downloaded_bytes)s|%(progress.total_bytes)s|%(progress.total_bytes_estimate)s|%(progress.speed)s',
      '--print', 'after_move:PDMFILE|%(filepath)s',
      url,
    ];
    try {
      final p = _proc = await Process.start(ytdlpExe, args, environment: _env);
      final err = StringBuffer();
      p.stderr.transform(utf8.decoder).listen(err.write);
      p.stdout.transform(utf8.decoder).transform(const LineSplitter()).listen(_line);
      final code = await p.exitCode;
      _proc = null;
      if (_stopping) return; // pause / cancel / remove already set the status
      if (code == 0) {
        status = 'completed';
        downloaded = total > 0 ? total : downloaded;
        finishedAt = DateTime.now().millisecondsSinceEpoch ~/ 1000;
      } else {
        final lines = err.toString().trim().split('\n').where((l) => l.trim().isNotEmpty).toList();
        _fail(lines.isEmpty ? 'yt-dlp failed (exit code $code)' : lines.last.replaceFirst('ERROR: ', ''));
        return;
      }
    } catch (e) {
      return _fail('Cannot start yt-dlp: $e');
    }
    onChange();
  }

  void _line(String l) {
    if (l.startsWith('PDMFILE|')) {
      finalPath = l.substring(8).trim();
    } else if (l.startsWith('PDM|')) {
      final f = l.split('|');
      int n(int i) => i < f.length ? (double.tryParse(f[i])?.round() ?? 0) : 0;
      downloaded = n(1);
      total = n(2) > 0 ? n(2) : n(3);
      speed = f.length > 4 ? (double.tryParse(f[4]) ?? 0) : 0;
      onChange();
    }
  }

  void _fail(String m) {
    status = 'failed';
    error = m;
    speed = 0;
    finishedAt = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    onChange();
  }

  /// Stops the process; yt-dlp resumes from its .part file on the next start().
  void stop(String as) {
    _stopping = true;
    _proc?.kill();
    status = as;
    speed = 0;
    if (as == 'cancelled') finishedAt = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    onChange();
  }
}
